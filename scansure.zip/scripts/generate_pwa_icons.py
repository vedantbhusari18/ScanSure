import zlib
import struct
import math
import os

def create_png(width, height, get_pixel_func):
    """
    Creates a valid RGBA PNG file in pure Python without external dependencies.
    """
    raw_data = bytearray()
    for y in range(height):
        raw_data.append(0)  # Filter type 0 (None)
        for x in range(width):
            r, g, b, a = get_pixel_func(x, y, width, height)
            raw_data.extend([
                max(0, min(255, int(r))),
                max(0, min(255, int(g))),
                max(0, min(255, int(b))),
                max(0, min(255, int(a)))
            ])

    def chunk(tag, data):
        length = struct.pack('>I', len(data))
        crc = struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
        return length + tag + data + crc

    png_bytes = bytearray(b'\x89PNG\r\n\x1a\n')
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    png_bytes.extend(chunk(b'IHDR', ihdr))
    compressed = zlib.compress(bytes(raw_data), 9)
    png_bytes.extend(chunk(b'IDAT', compressed))
    png_bytes.extend(chunk(b'IEND', b''))
    return bytes(png_bytes)

def render_scansure_icon(x, y, w, h, maskable=False):
    # Normalized coordinates 0.0 to 1.0
    nx = x / float(w)
    ny = y / float(h)
    
    # Center distance
    cx = nx - 0.5
    cy = ny - 0.5
    
    # Background gradient: from #090d16 (top-left) to #0f172a (mid) to #064e3b (bottom-right)
    t = (nx + ny) / 2.0
    bg_r = int(9 * (1.0 - t) + 6 * t)
    bg_g = int(13 * (1.0 - t) + 78 * t)
    bg_b = int(22 * (1.0 - t) + 59 * t)
    
    # Corner rounding check for non-maskable icons (squircle radius ~ 0.22)
    alpha = 255
    if not maskable:
        # Distance from squircle
        rx = abs(cx) - 0.26
        ry = abs(cy) - 0.26
        corner_dist = 0
        if rx > 0 and ry > 0:
            corner_dist = math.sqrt(rx * rx + ry * ry) - 0.20
        elif rx > 0.20 or ry > 0.20:
            corner_dist = max(rx, ry) - 0.20
        
        if corner_dist > 0.005:
            return (0, 0, 0, 0)
        elif corner_dist > 0:
            # Antialiasing
            alpha = int(255 * (1.0 - corner_dist / 0.005))

    # Base background color
    cur_r, cur_g, cur_b = bg_r, bg_g, bg_b

    # Scanning beam band around center y: 0.42 to 0.58
    if 0.40 <= ny <= 0.60:
        beam_t = 1.0 - abs(ny - 0.50) / 0.10
        cur_r = int(cur_r * (1 - beam_t * 0.25) + 16 * beam_t * 0.25)
        cur_g = int(cur_g * (1 - beam_t * 0.35) + 185 * beam_t * 0.35)
        cur_b = int(cur_b * (1 - beam_t * 0.25) + 129 * beam_t * 0.25)

    # Viewfinder corners (size scale depending on maskable)
    scale = 0.72 if maskable else 0.82
    vx = abs(cx) / scale
    vy = abs(cy) / scale
    
    # Check if (vx, vy) is near the border corner
    # Outer bound 0.38, inner 0.32, corner span from 0.18 to 0.38
    is_corner_x = (0.18 <= vx <= 0.38) and (0.31 <= vy <= 0.38)
    is_corner_y = (0.18 <= vy <= 0.38) and (0.31 <= vx <= 0.38)
    
    if is_corner_x or is_corner_y:
        # Emerald reticle
        grad_v = (nx + ny) / 2.0
        ret_r = int(52 * grad_v + 5 * (1 - grad_v))
        ret_g = int(211 * grad_v + 150 * (1 - grad_v))
        ret_b = int(153 * grad_v + 105 * (1 - grad_v))
        cur_r, cur_g, cur_b = ret_r, ret_g, ret_b

    # Barcode vertical slits in center (cy in -0.15 .. +0.15)
    if abs(cy) <= 0.12 and abs(cx) <= 0.24:
        # Check specific slit bands
        slits = [(-0.20, 0.015), (-0.14, 0.010), (-0.08, 0.018), (-0.02, 0.010),
                 (0.04, 0.015), (0.10, 0.012), (0.16, 0.018), (0.21, 0.012)]
        for spos, swidth in slits:
            if abs(cx - spos) < swidth:
                # Sky blue barcode lines
                cur_r = int(cur_r * 0.3 + 56 * 0.7)
                cur_g = int(cur_g * 0.3 + 189 * 0.7)
                cur_b = int(cur_b * 0.3 + 248 * 0.7)
                break

    # Laser Checkmark beam (line from (-0.14, 0.02) to (-0.02, 0.14) to (0.22, -0.12))
    # Segment 1: p1 = (-0.14, 0.02), p2 = (-0.02, 0.14)
    def dist_to_segment(px, py, x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        l2 = dx*dx + dy*dy
        if l2 == 0:
            return math.hypot(px - x1, py - y1)
        t = max(0.0, min(1.0, ((px - x1)*dx + (py - y1)*dy) / l2))
        proj_x = x1 + t * dx
        proj_y = y1 + t * dy
        return math.hypot(px - proj_x, py - proj_y)

    d1 = dist_to_segment(cx, cy, -0.14, 0.02, -0.02, 0.14)
    d2 = dist_to_segment(cx, cy, -0.02, 0.14, 0.20, -0.12)
    min_laser_dist = min(d1, d2)
    
    laser_radius = 0.032
    if min_laser_dist < laser_radius:
        glow_factor = 1.0 - (min_laser_dist / laser_radius)
        # Golden amber laser
        cur_r = int(cur_r * (1 - glow_factor) + 251 * glow_factor)
        cur_g = int(cur_g * (1 - glow_factor) + 191 * glow_factor)
        cur_b = int(cur_b * (1 - glow_factor) + 36 * glow_factor)
    elif min_laser_dist < laser_radius * 1.8:
        glow_factor = (1.0 - (min_laser_dist - laser_radius) / (laser_radius * 0.8)) * 0.4
        cur_r = int(cur_r * (1 - glow_factor) + 245 * glow_factor)
        cur_g = int(cur_g * (1 - glow_factor) + 158 * glow_factor)
        cur_b = int(cur_b * (1 - glow_factor) + 11 * glow_factor)

    return (cur_r, cur_g, cur_b, alpha)

def main():
    os.makedirs('public', exist_ok=True)
    
    # 1. 192x192
    print("Generating public/pwa-192x192.png...")
    png_192 = create_png(192, 192, lambda x, y, w, h: render_scansure_icon(x, y, w, h, maskable=False))
    with open('public/pwa-192x192.png', 'wb') as f:
        f.write(png_192)

    # 2. 512x512
    print("Generating public/pwa-512x512.png...")
    png_512 = create_png(512, 512, lambda x, y, w, h: render_scansure_icon(x, y, w, h, maskable=False))
    with open('public/pwa-512x512.png', 'wb') as f:
        f.write(png_512)

    # 3. 512x512 maskable (full bleed)
    print("Generating public/pwa-maskable-512x512.png...")
    png_maskable = create_png(512, 512, lambda x, y, w, h: render_scansure_icon(x, y, w, h, maskable=True))
    with open('public/pwa-maskable-512x512.png', 'wb') as f:
        f.write(png_maskable)

    # 4. apple-touch-icon.png (180x180)
    print("Generating public/apple-touch-icon.png...")
    png_apple = create_png(180, 180, lambda x, y, w, h: render_scansure_icon(x, y, w, h, maskable=False))
    with open('public/apple-touch-icon.png', 'wb') as f:
        f.write(png_apple)

    # 5. favicon.ico / favicon png (64x64)
    print("Generating public/favicon.png...")
    png_fav = create_png(64, 64, lambda x, y, w, h: render_scansure_icon(x, y, w, h, maskable=False))
    with open('public/favicon.png', 'wb') as f:
        f.write(png_fav)

    print("All PWA icons generated successfully!")

if __name__ == '__main__':
    main()
