import { InspectionRecord, ExtractedField, MVPFieldKey, OverallVerdict, BatchStatus } from '../types/inspection';
import { SUPERMARKET_CATALOG } from './supermarketProducts';

// Additional products to give full 100 realistic Indian FMCG & retail packaged commodities
const ADDITIONAL_PRODUCTS = [
  { name: 'Kissan Fresh Tomato Ketchup', brand: 'Kissan', category: 'Sauces & Condiments', barcode: '8901030654120', mrp: '₹120.00', usp: '₹0.13 / g', netQty: '950 g', mfg: '08/2026', exp: '08/2027', mfr: 'Hindustan Unilever Ltd., Unilever House, B. D. Sawant Marg, Chakala, Andheri East, Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Aashirvaad Superior MP Sharbati Atta', brand: 'Aashirvaad', category: 'Atta & Flours', barcode: '8901725181214', mrp: '₹295.00', usp: '₹59.00 / kg', netQty: '5 kg', mfg: '09/2026', exp: '12/2026', mfr: 'ITC Limited, 37, J.L. Nehru Road, Kolkata - 700071', care: '1800-425-44444 | itccares@itc.in' },
  { name: 'Fortune Sunlite Refined Sunflower Oil', brand: 'Fortune', category: 'Edible Oils', barcode: '8906007281412', mrp: '₹145.00', usp: '₹145.00 / L', netQty: '1 L', mfg: '08/2026', exp: '05/2027', mfr: 'Adani Wilmar Limited, Fortune House, Near Navrangpura Rly. Crossing, Ahmedabad - 380009', care: '1800-233-9999 | care@adaniwilmar.in' },
  { name: 'Dabur Honey 100% Pure', brand: 'Dabur', category: 'Health & Nutrition', barcode: '8901207008123', mrp: '₹199.00', usp: '₹0.50 / g', netQty: '400 g', mfg: '07/2026', exp: '07/2028', mfr: 'Dabur India Limited, 8/3, Asaf Ali Road, New Delhi - 110002', care: '1800-103-1644 | daburcares@dabur.com' },
  { name: 'Saffola Gold Pro Healthy Lifestyle Oil', brand: 'Saffola', category: 'Edible Oils', barcode: '8901088004121', mrp: '₹185.00', usp: '₹185.00 / L', netQty: '1 L', mfg: '08/2026', exp: '04/2027', mfr: 'Marico Limited, Grande Palladium, 175 CST Road, Kalina, Santacruz East, Mumbai - 400098', care: '1800-222-248 | ccc@marico.com' },
  { name: 'Haldiram\'s Nagpur Aloo Bhujia', brand: 'Haldiram\'s', category: 'Snacks & Namkeen', barcode: '8904004401243', mrp: '₹55.00', usp: '₹0.28 / g', netQty: '200 g', mfg: '08/2026', exp: '02/2027', mfr: 'Haldiram Foods International Pvt. Ltd., 20 Km Stone, Bhandara Road, Nagpur - 441104', care: '0712-2681123 | customercare@haldirams.com' },
  { name: 'Britannia Good Day Butter Cookies', brand: 'Britannia', category: 'Biscuits & Cookies', barcode: '8901063102148', mrp: '₹35.00', usp: '₹0.29 / g', netQty: '120 g', mfg: '08/2026', exp: '02/2027', mfr: 'Britannia Industries Ltd., 5/1A Hungerford Street, Kolkata - 700017', care: '1800-425-4449 | feedback@britindia.com' },
  { name: 'Tata Tea Gold Premium Blend', brand: 'Tata Tea', category: 'Tea & Coffee', barcode: '8901052002138', mrp: '₹160.00', usp: '₹0.64 / g', netQty: '250 g', mfg: '07/2026', exp: '07/2027', mfr: 'Tata Consumer Products Ltd., 1 Bishop Lefroy Road, Kolkata - 700020', care: '1800-345-1720 | customercare@tataconsumer.com' },
  { name: 'Red Label Natural Care Tea', brand: 'Brooke Bond', category: 'Tea & Coffee', barcode: '8901030741210', mrp: '₹175.00', usp: '₹0.70 / g', netQty: '250 g', mfg: '08/2026', exp: '08/2027', mfr: 'Hindustan Unilever Ltd., Unilever House, B. D. Sawant Marg, Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Bru Instant Coffee Chicory Mix', brand: 'Bru', category: 'Tea & Coffee', barcode: '8901030821415', mrp: '₹95.00', usp: '₹0.95 / g', netQty: '100 g', mfg: '07/2026', exp: '07/2028', mfr: 'Hindustan Unilever Ltd., Unilever House, Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Everest Chana Masala Spice Blend', brand: 'Everest', category: 'Spices & Masalas', barcode: '8901786101211', mrp: '₹42.00', usp: '₹0.42 / g', netQty: '100 g', mfg: '08/2026', exp: '08/2027', mfr: 'S. Narendrakumar & Co., 5th Floor, Krushal Commercial Complex, Chembur West, Mumbai - 400089', care: '022-25259999 | customercare@everestspices.com' },
  { name: 'MDH Deggi Mirch Red Pepper Powder', brand: 'MDH', category: 'Spices & Masalas', barcode: '8901243102145', mrp: '₹88.00', usp: '₹0.88 / g', netQty: '100 g', mfg: '08/2026', exp: '08/2027', mfr: 'Mahashian Di Hatti Pvt. Ltd., MDH House, 9/44, Industrial Area, Kirti Nagar, New Delhi - 110015', care: '011-41425106 | customercare@mdhspices.in' },
  { name: 'Catch Table Salt Sprinkler', brand: 'Catch', category: 'Salt & Seasoning', barcode: '8901025001211', mrp: '₹35.00', usp: '₹0.18 / g', netQty: '200 g', mfg: '08/2026', exp: '08/2028', mfr: 'DS Spiceco Pvt. Ltd., 4828/24, Prahlad Lane, Ansari Road, Daryaganj, New Delhi - 110002', care: '0120-4032200 | customercare@dsgroup.com' },
  { name: 'Mother Dairy Full Cream Milk Poly Pack', brand: 'Mother Dairy', category: 'Dairy & Refrigerated', barcode: '8901648001214', mrp: '₹34.00', usp: '₹68.00 / L', netQty: '500 ml', mfg: '09/2026', exp: 'Within 48 hours', mfr: 'Mother Dairy Fruit & Vegetable Pvt. Ltd., Patparganj, Delhi - 110092', care: '1800-180-1018 | consumer.services@motherdairy.com' },
  { name: 'Dettol Original Liquid Handwash Refill', brand: 'Dettol', category: 'Personal Care', barcode: '8901396321451', mrp: '₹99.00', usp: '₹0.14 / ml', netQty: '675 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Reckitt Benckiser (India) Pvt. Ltd., DLF Cyber Park, Sector 20, Gurugram - 122016', care: '1800-102-2720 | consumerhealth_in@reckitt.com' },
  { name: 'Lifebuoy Total Germ Protection Soap (Pack of 4)', brand: 'Lifebuoy', category: 'Personal Care', barcode: '8901030712348', mrp: '₹140.00', usp: '₹0.28 / g', netQty: '500 g', mfg: '07/2026', exp: '07/2028', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Colgate Total Advanced Health Toothpaste', brand: 'Colgate', category: 'Oral Care', barcode: '8901314010521', mrp: '₹115.00', usp: '₹0.96 / g', netQty: '120 g', mfg: '08/2026', exp: '08/2028', mfr: 'Colgate-Palmolive (India) Ltd., Colgate Research Centre, Main Street, Powai, Mumbai - 400076', care: '1800-225-599 | consumeraffairs_india@colpal.com' },
  { name: 'Sensodyne Fresh Mint Toothpaste', brand: 'Sensodyne', category: 'Oral Care', barcode: '8901571004128', mrp: '₹175.00', usp: '₹1.75 / g', netQty: '100 g', mfg: '07/2026', exp: '07/2028', mfr: 'Haleon India Ltd., 4th Floor, DLF Downtown, Gurugram - 122002', care: '1800-222-204 | consumer.relations@haleon.com' },
  { name: 'Surf Excel Matic Front Load Liquid Detergent', brand: 'Surf Excel', category: 'Home Care', barcode: '8901030881234', mrp: '₹240.00', usp: '₹240.00 / L', netQty: '1 L', mfg: '08/2026', exp: '08/2028', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Ariel Matic Complete Liquid Detergent', brand: 'Ariel', category: 'Home Care', barcode: '8901314502124', mrp: '₹250.00', usp: '₹250.00 / L', netQty: '1 L', mfg: '08/2026', exp: '08/2028', mfr: 'Procter & Gamble Home Products Pvt. Ltd., P&G Plaza, Cardinal Gracias Road, Chakala, Mumbai - 400099', care: '1800-202-1364 | intouch.im@pg.com' },
  { name: 'Vim Dishwash Gel Lemon Anti-Germ', brand: 'Vim', category: 'Home Care', barcode: '8901030514128', mrp: '₹60.00', usp: '₹0.24 / ml', netQty: '250 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Lizol Surface Disinfectant Citrus Floor Cleaner', brand: 'Lizol', category: 'Home Care', barcode: '8901396201248', mrp: '₹115.00', usp: '₹0.23 / ml', netQty: '500 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Reckitt Benckiser (India) Pvt. Ltd., Gurugram - 122016', care: '1800-102-2720 | consumerhealth_in@reckitt.com' },
  { name: 'Harpic Power Plus Original Disinfectant Toilet Cleaner', brand: 'Harpic', category: 'Home Care', barcode: '8901396112014', mrp: '₹93.00', usp: '₹0.19 / ml', netQty: '500 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Reckitt Benckiser (India) Pvt. Ltd., Gurugram - 122016', care: '1800-102-2720 | consumerhealth_in@reckitt.com' },
  { name: 'Bournvita Chocolate Nutrition Drink Pouch', brand: 'Cadbury', category: 'Health Drinks', barcode: '7622201712458', mrp: '₹245.00', usp: '₹0.49 / g', netQty: '500 g', mfg: '07/2026', exp: '07/2027', mfr: 'Mondelez India Foods Pvt. Ltd., Unit No. 2001, 20th Floor, Tower-3, Indiabulls Finance Centre, Mumbai - 400013', care: '1800-227-080 | suggestions@mdlz.com' },
  { name: 'Horlicks Classic Malt Health Drink', brand: 'Horlicks', category: 'Health Drinks', barcode: '8901030914120', mrp: '₹270.00', usp: '₹0.54 / g', netQty: '500 g', mfg: '08/2026', exp: '08/2027', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
];

function generateSvgThumbnail(name: string, brand: string, color: string): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="400" height="300">
  <rect width="400" height="300" fill="#0f172a" rx="16"/>
  <rect x="20" y="20" width="360" height="260" rx="12" fill="${color}" fill-opacity="0.12" stroke="${color}" stroke-width="2"/>
  <rect x="40" y="40" width="120" height="24" rx="6" fill="${color}" fill-opacity="0.3"/>
  <text x="50" y="56" fill="#f8fafc" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">${brand.toUpperCase()}</text>
  <text x="40" y="110" fill="#ffffff" font-family="system-ui, sans-serif" font-size="16" font-weight="900">${name.slice(0, 24)}</text>
  <rect x="40" y="135" width="320" height="110" rx="8" fill="#ffffff" fill-opacity="0.08"/>
  <text x="55" y="165" fill="#94a3b8" font-family="monospace" font-size="11">PCR 2011 STATUTORY PANEL</text>
  <text x="55" y="195" fill="#38bdf8" font-family="monospace" font-size="12">NET QTY | MRP | MFG DATE | USP</text>
  <text x="55" y="225" fill="#10b981" font-family="monospace" font-size="11">LEGAL METROLOGY VERIFIED</text>
</svg>
`)}`;
}

export function generate100DemoInspections(): InspectionRecord[] {
  // Combine all items
  const allCatalog = [
    ...SUPERMARKET_CATALOG.map((p) => ({
      name: p.productName,
      brand: p.brand,
      category: p.category,
      barcode: p.barcode,
      mrp: p.mrp,
      usp: p.unitSalePrice,
      netQty: p.netQuantity,
      mfg: p.mfgDate,
      exp: p.expiryDate,
      mfr: p.manufacturer,
      care: p.consumerCare,
    })),
    ...ADDITIONAL_PRODUCTS,
  ];

  const records: InspectionRecord[] = [];

  // Target distribution summing to exactly 100:
  // Compliant: 76
  // Review Queue (Needs Review): 16
  // Violations (Non-Compliant): 8
  const TARGET_COMPLIANT = 76;
  const TARGET_REVIEW = 16;
  const TARGET_VIOLATIONS = 8;
  const TOTAL = TARGET_COMPLIANT + TARGET_REVIEW + TARGET_VIOLATIONS; // 100

  for (let i = 0; i < TOTAL; i++) {
    const itemIndex = i % allCatalog.length;
    const baseItem = allCatalog[itemIndex];
    const sequenceNum = String(i + 1).padStart(3, '0');
    const id = `insp-demo-${sequenceNum}`;
    const batchNumber = `B-2026-${sequenceNum}`;

    let overallVerdict: OverallVerdict = 'COMPLIANT';
    let batchStatus: BatchStatus = 'RELEASED';
    let complianceScore = 96;
    let category = baseItem.category;
    let commodityName = baseItem.name;
    let brandName = baseItem.brand;

    if (i >= TARGET_COMPLIANT && i < TARGET_COMPLIANT + TARGET_REVIEW) {
      // Review Queue (16 records)
      overallVerdict = 'NEEDS_REVIEW';
      batchStatus = 'HOLD';
      complianceScore = 78;
    } else if (i >= TARGET_COMPLIANT + TARGET_REVIEW) {
      // Violations (8 records)
      overallVerdict = 'NON_COMPLIANT';
      batchStatus = 'RECALLED';
      complianceScore = 44;
    }

    // Spread timestamps across the last 14 days
    const dayOffset = Math.floor((100 - i) / 7.5);
    const hourOffset = (i * 3) % 24;
    const minuteOffset = (i * 17) % 60;
    const recordDate = new Date(2026, 8, 23 - dayOffset, hourOffset, minuteOffset);
    const scannedAt = recordDate.toISOString();

    // Create field extraction mock
    const isViolation = overallVerdict === 'NON_COMPLIANT';
    const isReview = overallVerdict === 'NEEDS_REVIEW';

    const fields: Record<MVPFieldKey, ExtractedField> = {
      mrp: {
        fieldKey: 'mrp',
        fieldName: 'Maximum Retail Price (MRP)',
        rawValue: baseItem.mrp,
        cleanedValue: baseItem.mrp,
        status: isViolation && (i % 3 === 0) ? 'MISSING' : 'FOUND',
        confidence: isViolation && (i % 3 === 0) ? 0.2 : 0.98,
        evidenceSnippet: isViolation && (i % 3 === 0) ? 'MRP not printed or illegible' : `MRP ${baseItem.mrp} (incl. of all taxes)`,
        ruleReference: 'PCR 2011 Rule 6(1)(e)',
        ruleExplanation: 'Every package must bear the retail sale price inclusive of all taxes.',
        boundingBox: { x: 50, y: 55, width: 35, height: 8 },
      },
      netQuantity: {
        fieldKey: 'netQuantity',
        fieldName: 'Net Quantity Declaration',
        rawValue: isViolation && (i % 4 === 0) ? `${baseItem.netQty} approx` : baseItem.netQty,
        cleanedValue: baseItem.netQty,
        status: isViolation && (i % 4 === 0) ? 'MISSING' : 'FOUND',
        confidence: isViolation && (i % 4 === 0) ? 0.35 : 0.97,
        evidenceSnippet: `Net Qty: ${baseItem.netQty}`,
        ruleReference: 'PCR 2011 Rule 6(1)(b) & Schedule II',
        ruleExplanation: 'Standard units of mass or measure (g, kg, ml, L) without qualifying expressions.',
        boundingBox: { x: 15, y: 55, width: 30, height: 8 },
      },
      manufacturer: {
        fieldKey: 'manufacturer',
        fieldName: 'Manufacturer / Packer Identity',
        rawValue: baseItem.mfr,
        cleanedValue: baseItem.mfr,
        status: isReview && (i % 3 === 0) ? 'REVIEW' : 'FOUND',
        confidence: isReview && (i % 3 === 0) ? 0.72 : 0.95,
        evidenceSnippet: baseItem.mfr,
        ruleReference: 'PCR 2011 Rule 6(1)(a)',
        ruleExplanation: 'Name and complete address of the manufacturer or packer must be stated.',
        boundingBox: { x: 15, y: 65, width: 70, height: 9 },
      },
      genericName: {
        fieldKey: 'genericName',
        fieldName: 'Generic / Common Name of Commodity',
        rawValue: baseItem.name,
        cleanedValue: baseItem.name,
        status: 'FOUND',
        confidence: 0.96,
        evidenceSnippet: baseItem.name,
        ruleReference: 'PCR 2011 Rule 6(1)(c)',
        ruleExplanation: 'Common or generic name of commodity contained in the package.',
        boundingBox: { x: 15, y: 25, width: 70, height: 12 },
      },
      dateInfo: {
        fieldKey: 'dateInfo',
        fieldName: 'Month & Year of Manufacture / Packing',
        rawValue: baseItem.mfg,
        cleanedValue: baseItem.mfg,
        status: isViolation && (i % 3 === 1) ? 'MISSING' : isReview && (i % 3 === 1) ? 'REVIEW' : 'FOUND',
        confidence: isViolation && (i % 3 === 1) ? 0.15 : isReview && (i % 3 === 1) ? 0.68 : 0.94,
        evidenceSnippet: `Mfg Date: ${baseItem.mfg} | Best Before: ${baseItem.exp}`,
        ruleReference: 'PCR 2011 Rule 6(1)(d)',
        ruleExplanation: 'Month and year of manufacture or pre-packing must be prominently displayed.',
        boundingBox: { x: 15, y: 75, width: 35, height: 7 },
      },
      consumerCare: {
        fieldKey: 'consumerCare',
        fieldName: 'Consumer Care Cell Details',
        rawValue: isViolation && (i % 3 === 2) ? 'Write to our office' : baseItem.care,
        cleanedValue: baseItem.care,
        status: isViolation && (i % 3 === 2) ? 'MISSING' : isReview && (i % 3 === 2) ? 'REVIEW' : 'FOUND',
        confidence: isViolation && (i % 3 === 2) ? 0.25 : isReview && (i % 3 === 2) ? 0.74 : 0.95,
        evidenceSnippet: baseItem.care,
        ruleReference: 'PCR 2011 Rule 6(1)(g)',
        ruleExplanation: 'Name, address, telephone number and email of person or officer handling complaints.',
        boundingBox: { x: 15, y: 84, width: 70, height: 9 },
      },
      unitSalePrice: {
        fieldKey: 'unitSalePrice',
        fieldName: 'Unit Sale Price (USP)',
        rawValue: isViolation ? '[NOT PRINTED]' : baseItem.usp,
        cleanedValue: isViolation ? '' : baseItem.usp,
        status: isViolation ? 'MISSING' : 'FOUND',
        confidence: isViolation ? 0.1 : 0.96,
        evidenceSnippet: isViolation ? 'Omission: Unit Sale Price mandatory under Rule 6(1)(h)' : `Unit Sale Price: ${baseItem.usp}`,
        ruleReference: 'PCR 2011 Rule 6(1)(h)',
        ruleExplanation: 'Unit Sale Price in Rupees per g, kg, ml or L must be declared on packages > 100g/ml.',
        boundingBox: { x: 50, y: 75, width: 35, height: 7 },
      },
    };

    const color = overallVerdict === 'COMPLIANT' ? '#10b981' : overallVerdict === 'NEEDS_REVIEW' ? '#f59e0b' : '#ef4444';
    const thumbnail = generateSvgThumbnail(commodityName, brandName, color);

    records.push({
      id,
      commodityName,
      brandName,
      batchNumber,
      batchStatus,
      category,
      scannedAt,
      imageUrl: thumbnail,
      imageQuality: {
        score: isReview ? 72 : 96,
        blurScore: isReview ? 'MODERATE_BLUR' : 'SHARP',
        lightingQuality: 'GOOD',
        resolutionScore: 'PASS',
        framingScore: 'CENTERED',
        isReadable: true,
        warnings: isReview ? ['Low contrast text detected on declaration boundary'] : [],
      },
      fields,
      overallVerdict,
      complianceScore,
      officerRemarks:
        overallVerdict === 'COMPLIANT'
          ? 'Full statutory compliance verified under Packaged Commodities Rules, 2011.'
          : overallVerdict === 'NEEDS_REVIEW'
          ? 'Mandatory declaration requires visual verification due to partial font contrast.'
          : 'Statutory non-compliance: Mandatory declarations omitted or non-compliant under PCR 2011.',
      officerName: 'J. Sharma, Metrologist',
      officerDesignation: 'Legal Metrology Inspector, Grade I',
      location: 'Central Depot Terminal, Gate 4',
      barcodeData: {
        rawValue: baseItem.barcode,
        format: 'EAN_13',
        type: 'FMCG_PACKAGED_GOODS',
        productName: baseItem.name,
        brandName: baseItem.brand,
        category: baseItem.category,
        mrp: baseItem.mrp,
        netQuantity: baseItem.netQty,
        unitSalePrice: baseItem.usp,
        lotNumber: batchNumber,
        countryOfOrigin: 'India',
        manufacturerName: baseItem.mfr,
        isRealDatabaseLookup: true,
      },
      status: overallVerdict === 'COMPLIANT' ? 'REPORT_ISSUED' : 'ANALYZED',
      createdAt: scannedAt,
      updatedAt: scannedAt,
    });
  }

  return records;
}
