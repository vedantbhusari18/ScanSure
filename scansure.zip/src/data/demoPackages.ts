import { ExtractedField, MVPFieldKey } from '../types/inspection';

export interface DemoPackagePreset {
  id: string;
  name: string;
  brand: string;
  category: string;
  batch: string;
  description: string;
  svgImage: string; // Base64 or inline SVG for high-fidelity render
  presetQualityIssue?: 'BLUR' | 'GLARE' | 'LOW_RES' | 'NONE';
  mockFields: Record<MVPFieldKey, {
    rawValue: string;
    cleanedValue: string;
    isReadable: boolean;
    found: boolean;
    confidence: number;
    boundingBox: { x: number; y: number; width: number; height: number };
    evidenceSnippet: string;
    notes?: string;
  }>;
}

// Generate high-resolution SVG package artwork with clear declaration panels
function generateDemoSvg(productName: string, brand: string, hasUnclearCare: boolean, hasMissingUSP: boolean): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 850" width="700" height="850">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="50%" stop-color="#1e293b" />
      <stop offset="100%" stop-color="#0f172a" />
    </linearGradient>
    <linearGradient id="goldBanner" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#f59e0b" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>
    <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000" flood-opacity="0.4" />
    </filter>
  </defs>

  <!-- Pouch Background -->
  <rect x="50" y="30" width="600" height="790" rx="36" fill="url(#bgGrad)" stroke="#334155" stroke-width="4" filter="url(#shadow)" />
  
  <!-- Metallic Seal Top & Bottom -->
  <path d="M50 70 Q350 90 650 70 L650 30 Q350 45 50 30 Z" fill="#334155" opacity="0.6" />
  <path d="M50 820 Q350 800 650 820 L650 780 Q350 795 50 780 Z" fill="#334155" opacity="0.6" />

  <!-- Brand Header -->
  <rect x="180" y="80" width="340" height="42" rx="10" fill="url(#goldBanner)" />
  <text x="350" y="108" fill="#ffffff" font-family="system-ui, sans-serif" font-weight="800" font-size="22" text-anchor="middle" letter-spacing="2">★ ${brand.toUpperCase()} ★</text>

  <!-- Product Title & Generic Name (Box 1) -->
  <text x="350" y="175" fill="#f8fafc" font-family="system-ui, sans-serif" font-weight="900" font-size="34" text-anchor="middle">${productName}</text>
  <rect x="190" y="195" width="320" height="28" rx="6" fill="#3b82f6" fill-opacity="0.18" stroke="#3b82f6" stroke-dasharray="4 2" />
  <text x="350" y="214" fill="#93c5fd" font-family="system-ui, sans-serif" font-weight="600" font-size="14" text-anchor="middle">GENERIC NAME: ROASTED SAVORY SNACK</text>

  <!-- Product Illustration Graphic -->
  <rect x="200" y="240" width="300" height="150" rx="20" fill="#1e1b4b" stroke="#4338ca" stroke-width="2" />
  <circle cx="350" cy="315" r="45" fill="#f59e0b" fill-opacity="0.2" />
  <text x="350" y="325" font-size="52" text-anchor="middle">🥨</text>
  <text x="350" y="375" fill="#a5b4fc" font-family="system-ui, sans-serif" font-size="12" text-anchor="middle" font-weight="bold">100% WHOLE GRAIN &amp; CRUNCHY</text>

  <!-- Statutory Legal Metrology Declaration Panel (White Box Backing) -->
  <rect x="90" y="415" width="520" height="360" rx="14" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
  <rect x="90" y="415" width="520" height="34" rx="14" fill="#e2e8f0" />
  <text x="350" y="438" fill="#1e293b" font-family="system-ui, sans-serif" font-size="13" font-weight="bold" text-anchor="middle" letter-spacing="1">MANDATORY STATUTORY DECLARATIONS (PCR 2011)</text>

  <!-- Declaration Section 1: Net Quantity -->
  <rect x="110" y="460" width="230" height="48" rx="6" fill="#f8fafc" stroke="#e2e8f0" />
  <text x="120" y="480" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">NET QUANTITY:</text>
  <text x="120" y="500" fill="#0f172a" font-family="system-ui, sans-serif" font-size="16" font-weight="800">100 g</text>

  <!-- Declaration Section 2: MRP -->
  <rect x="360" y="460" width="230" height="48" rx="6" fill="#f8fafc" stroke="#e2e8f0" />
  <text x="370" y="480" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">MAX RETAIL PRICE (MRP):</text>
  <text x="370" y="500" fill="#0f172a" font-family="system-ui, sans-serif" font-size="16" font-weight="800">₹ 50.00 <tspan font-size="11" font-weight="normal" fill="#64748b">(incl. of all taxes)</tspan></text>

  <!-- Declaration Section 3: Manufacturer -->
  <rect x="110" y="520" width="480" height="52" rx="6" fill="#f8fafc" stroke="#e2e8f0" />
  <text x="120" y="538" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">MANUFACTURED &amp; PACKED BY:</text>
  <text x="120" y="558" fill="#0f172a" font-family="system-ui, sans-serif" font-size="14" font-weight="700">ABC Foods Ltd., Plot 42, Food Park, Phase-1, New Delhi - 110020</text>

  <!-- Declaration Section 4: Date Info & Batch -->
  <rect x="110" y="584" width="230" height="52" rx="6" fill="#f8fafc" stroke="#e2e8f0" />
  <text x="120" y="602" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">MFG / PACKED DATE:</text>
  <text x="120" y="624" fill="#0f172a" font-family="system-ui, sans-serif" font-size="15" font-weight="800">Packed: Aug 2026</text>

  <!-- Declaration Section 5: Unit Sale Price (Missing or Found) -->
  <rect x="360" y="584" width="230" height="52" rx="6" fill="${hasMissingUSP ? '#fff1f2' : '#f8fafc'}" stroke="${hasMissingUSP ? '#fecdd3' : '#e2e8f0'}" />
  <text x="370" y="602" fill="${hasMissingUSP ? '#e11d48' : '#64748b'}" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">UNIT SALE PRICE (USP):</text>
  <text x="370" y="624" fill="${hasMissingUSP ? '#9f1239' : '#0f172a'}" font-family="system-ui, sans-serif" font-size="13" font-style="${hasMissingUSP ? 'italic' : 'normal'}" font-weight="${hasMissingUSP ? 'bold' : '800'}">
    ${hasMissingUSP ? '[NOT PRINTED / OMITTED]' : '₹ 0.50 / g'}
  </text>

  <!-- Declaration Section 6: Consumer Care (Clear vs Unclear) -->
  <rect x="110" y="648" width="480" height="60" rx="6" fill="${hasUnclearCare ? '#fffbeb' : '#f8fafc'}" stroke="${hasUnclearCare ? '#fef3c7' : '#e2e8f0'}" />
  <text x="120" y="666" fill="${hasUnclearCare ? '#b45309' : '#64748b'}" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">CONSUMER CARE EXECUTIVE:</text>
  ${hasUnclearCare
    ? `<text x="120" y="688" fill="#78716c" font-family="system-ui, monospace" font-size="12" letter-spacing="1" opacity="0.6">For feedback contact: care@ab... [PHONE SMUDGED/UNREADABLE]</text>
       <path d="M120 696 Q 280 690, 420 698" stroke="#d97706" stroke-width="1.5" fill="none" opacity="0.5" stroke-dasharray="3 3"/>`
    : `<text x="120" y="688" fill="#0f172a" font-family="system-ui, sans-serif" font-size="13" font-weight="600">Ph: 1800-111-2222 | Email: support@abcfoods.in | Addr: Same as Mfg</text>`
  }

  <!-- Barcode & FSSAI Footer -->
  <rect x="110" y="720" width="180" height="42" fill="#000000" opacity="0.04" rx="4" />
  <text x="120" y="746" fill="#475569" font-family="monospace" font-size="12">||| |||| || | ||||| | ||</text>
  <text x="350" y="746" fill="#475569" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">Lic No. 10019011000234</text>
</svg>
`)}`.trim();
}

export const DEMO_PRESETS: DemoPackagePreset[] = [
  {
    id: 'sih-demo-abc-foods',
    name: 'ABC Crunchy Bites (SIH Pitch Deck Demo)',
    brand: 'ABC Foods',
    category: 'Packaged Food & Snacks',
    batch: 'BATCH-AUG26-44B',
    description: 'Exact SIH26034 Pitch Deck input: ₹50 MRP, 100g Net Qty, ABC Foods Mfg, Aug 2026 Date, Unclear Consumer Care, Missing Unit Price.',
    presetQualityIssue: 'BLUR',
    svgImage: generateDemoSvg('Crunchy Wheat Bites', 'ABC Foods', true, true),
    mockFields: {
      mrp: {
        rawValue: 'MRP ₹50.00 (incl. of all taxes)',
        cleanedValue: '₹50.00',
        found: true,
        isReadable: true,
        confidence: 0.98,
        boundingBox: { x: 51.4, y: 54.1, width: 32.8, height: 5.6 },
        evidenceSnippet: 'MAX RETAIL PRICE (MRP): ₹ 50.00 (incl. of all taxes)',
      },
      netQuantity: {
        rawValue: 'NET QUANTITY: 100 g',
        cleanedValue: '100g',
        found: true,
        isReadable: true,
        confidence: 0.97,
        boundingBox: { x: 15.7, y: 54.1, width: 32.8, height: 5.6 },
        evidenceSnippet: 'NET QUANTITY: 100 g',
      },
      manufacturer: {
        rawValue: 'MANUFACTURED & PACKED BY: ABC Foods Ltd., Plot 42, Food Park, Phase-1, New Delhi - 110020',
        cleanedValue: 'ABC Foods Ltd., Plot 42, Food Park, Phase-1, New Delhi - 110020',
        found: true,
        isReadable: true,
        confidence: 0.95,
        boundingBox: { x: 15.7, y: 61.1, width: 68.5, height: 6.1 },
        evidenceSnippet: 'ABC Foods Ltd., Plot 42, Food Park, Phase-1, New Delhi',
      },
      genericName: {
        rawValue: 'GENERIC NAME: ROASTED SAVORY SNACK',
        cleanedValue: 'Roasted Savory Snack',
        found: true,
        isReadable: true,
        confidence: 0.94,
        boundingBox: { x: 27.1, y: 22.9, width: 45.7, height: 3.3 },
        evidenceSnippet: 'GENERIC NAME: ROASTED SAVORY SNACK',
      },
      dateInfo: {
        rawValue: 'MFG / PACKED DATE: Packed: Aug 2026',
        cleanedValue: 'Packed: Aug 2026',
        found: true,
        isReadable: true,
        confidence: 0.96,
        boundingBox: { x: 15.7, y: 68.7, width: 32.8, height: 6.1 },
        evidenceSnippet: 'Packed: Aug 2026',
      },
      consumerCare: {
        rawValue: 'For feedback contact: care@ab... [PHONE SMUDGED/UNREADABLE]',
        cleanedValue: 'care@ab... [unclear]',
        found: true,
        isReadable: false, // UNREADABLE -> TRUST RULE = "Unable to verify" (REVIEW)
        confidence: 0.42,
        boundingBox: { x: 15.7, y: 76.2, width: 68.5, height: 7.0 },
        evidenceSnippet: 'For feedback contact: care@ab... [PHONE SMUDGED]',
        notes: 'Consumer Care unclear / degraded print matrix',
      },
      unitSalePrice: {
        rawValue: '',
        cleanedValue: '',
        found: false,
        isReadable: true,
        confidence: 0.0,
        boundingBox: undefined,
        evidenceSnippet: 'No declaration matching Unit Sale Price found on label.',
        notes: 'Unit Sale Price missing from packaging',
      },
    },
  },
  {
    id: 'sih-compliant-dry-fruits',
    name: 'Himalayan Harvest Cashews (Fully Compliant)',
    brand: 'Himalayan Harvest',
    category: 'Dry Fruits & Nuts',
    batch: 'HH-2026-901',
    description: '100% compliant packaging with all 7 declarations present, including valid Unit Sale Price and sharp consumer helpline.',
    presetQualityIssue: 'NONE',
    svgImage: generateDemoSvg('Premium Cashew Nuts', 'Himalayan Harvest', false, false),
    mockFields: {
      mrp: {
        rawValue: 'MRP ₹280.00 (Incl. of all taxes)',
        cleanedValue: '₹280.00',
        found: true,
        isReadable: true,
        confidence: 0.99,
        boundingBox: { x: 51.4, y: 54.1, width: 32.8, height: 5.6 },
        evidenceSnippet: 'MRP ₹280.00 (Incl. of all taxes)',
      },
      netQuantity: {
        rawValue: 'Net Weight: 250 g',
        cleanedValue: '250g',
        found: true,
        isReadable: true,
        confidence: 0.98,
        boundingBox: { x: 15.7, y: 54.1, width: 32.8, height: 5.6 },
        evidenceSnippet: 'Net Weight: 250 g',
      },
      manufacturer: {
        rawValue: 'Packed by: Himalayan Harvest Agro Ltd, NH-44, Solan, HP - 173212',
        cleanedValue: 'Himalayan Harvest Agro Ltd, NH-44, Solan, HP - 173212',
        found: true,
        isReadable: true,
        confidence: 0.96,
        boundingBox: { x: 15.7, y: 61.1, width: 68.5, height: 6.1 },
        evidenceSnippet: 'Himalayan Harvest Agro Ltd, NH-44, Solan, HP',
      },
      genericName: {
        rawValue: 'Generic Name: Whole Cashew Kernels',
        cleanedValue: 'Whole Cashew Kernels',
        found: true,
        isReadable: true,
        confidence: 0.97,
        boundingBox: { x: 27.1, y: 22.9, width: 45.7, height: 3.3 },
        evidenceSnippet: 'Whole Cashew Kernels',
      },
      dateInfo: {
        rawValue: 'Date of Packing: 15/07/2026',
        cleanedValue: '15/07/2026',
        found: true,
        isReadable: true,
        confidence: 0.98,
        boundingBox: { x: 15.7, y: 68.7, width: 32.8, height: 6.1 },
        evidenceSnippet: 'Date of Packing: 15/07/2026',
      },
      consumerCare: {
        rawValue: 'Helpline: 1800-111-2222 | customercare@himalayanharvest.in',
        cleanedValue: '1800-111-2222 | customercare@himalayanharvest.in',
        found: true,
        isReadable: true,
        confidence: 0.94,
        boundingBox: { x: 15.7, y: 76.2, width: 68.5, height: 7.0 },
        evidenceSnippet: 'Helpline: 1800-111-2222',
      },
      unitSalePrice: {
        rawValue: 'Unit Sale Price: ₹ 1.12 / g',
        cleanedValue: '₹ 1.12 / g',
        found: true,
        isReadable: true,
        confidence: 0.96,
        boundingBox: { x: 51.4, y: 68.7, width: 32.8, height: 6.1 },
        evidenceSnippet: 'Unit Sale Price: ₹ 1.12 / g',
      },
    },
  },
];
