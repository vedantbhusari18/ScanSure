import { InspectionRecord, ExtractedField, MVPFieldKey, OverallVerdict, BatchStatus } from '../types/inspection';
import { SUPERMARKET_CATALOG } from './supermarketProducts';

// Product Catalog across all Indian packaged goods categories
const EXPANDED_CATALOG = [
  ...SUPERMARKET_CATALOG.map((p) => ({
    name: p.productName,
    brand: p.brand,
    category: p.category,
    barcode: p.barcode,
    mrp: p.mrp,
    usp: p.unitSalePrice,
    netQty: p.netQuantity,
    mfg: p.mfgDate,
    exp: p.expiryDate,
    mfr: p.manufacturer,
    care: p.consumerCare,
  })),
  { name: 'Kissan Fresh Tomato Ketchup', brand: 'Kissan', category: 'Sauces & Condiments', barcode: '8901030654120', mrp: '₹120.00', usp: '₹0.13 / g', netQty: '950 g', mfg: '08/2026', exp: '08/2027', mfr: 'Hindustan Unilever Ltd., Unilever House, B. D. Sawant Marg, Chakala, Andheri East, Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Aashirvaad Superior MP Sharbati Atta', brand: 'Aashirvaad', category: 'Atta & Flours', barcode: '8901725181214', mrp: '₹295.00', usp: '₹59.00 / kg', netQty: '5 kg', mfg: '09/2026', exp: '12/2026', mfr: 'ITC Limited, 37, J.L. Nehru Road, Kolkata - 700071', care: '1800-425-44444 | itccares@itc.in' },
  { name: 'Fortune Sunlite Refined Sunflower Oil', brand: 'Fortune', category: 'Edible Oils', barcode: '8906007281412', mrp: '₹145.00', usp: '₹145.00 / L', netQty: '1 L', mfg: '08/2026', exp: '05/2027', mfr: 'Adani Wilmar Limited, Fortune House, Ahmedabad - 380009', care: '1800-233-9999 | care@adaniwilmar.in' },
  { name: 'Dabur Honey 100% Pure & Indigenous', brand: 'Dabur', category: 'Health & Nutrition', barcode: '8901207008123', mrp: '₹199.00', usp: '₹0.50 / g', netQty: '400 g', mfg: '07/2026', exp: '07/2028', mfr: 'Dabur India Limited, 8/3, Asaf Ali Road, New Delhi - 110002', care: '1800-103-1644 | daburcares@dabur.com' },
  { name: 'Saffola Gold Pro Healthy Lifestyle Oil', brand: 'Saffola', category: 'Edible Oils', barcode: '8901088004121', mrp: '₹185.00', usp: '₹185.00 / L', netQty: '1 L', mfg: '08/2026', exp: '04/2027', mfr: 'Marico Limited, Grande Palladium, CST Road, Mumbai - 400098', care: '1800-222-248 | ccc@marico.com' },
  { name: 'Haldiram\'s Nagpur Aloo Bhujia Namkeen', brand: 'Haldiram\'s', category: 'Snacks & Namkeen', barcode: '8904004401243', mrp: '₹55.00', usp: '₹0.28 / g', netQty: '200 g', mfg: '08/2026', exp: '02/2027', mfr: 'Haldiram Foods International Pvt. Ltd., Bhandara Road, Nagpur - 441104', care: '0712-2681123 | customercare@haldirams.com' },
  { name: 'Britannia Good Day Butter Cookies', brand: 'Britannia', category: 'Biscuits & Cookies', barcode: '8901063102148', mrp: '₹35.00', usp: '₹0.29 / g', netQty: '120 g', mfg: '08/2026', exp: '02/2027', mfr: 'Britannia Industries Ltd., Hungerford Street, Kolkata - 700017', care: '1800-425-4449 | feedback@britindia.com' },
  { name: 'Tata Tea Gold Premium Blend Leaf', brand: 'Tata Tea', category: 'Tea & Coffee', barcode: '8901052002138', mrp: '₹160.00', usp: '₹0.64 / g', netQty: '250 g', mfg: '07/2026', exp: '07/2027', mfr: 'Tata Consumer Products Ltd., 1 Bishop Lefroy Road, Kolkata - 700020', care: '1800-345-1720 | customercare@tataconsumer.com' },
  { name: 'Red Label Natural Care Ayurvedic Tea', brand: 'Brooke Bond', category: 'Tea & Coffee', barcode: '8901030741210', mrp: '₹175.00', usp: '₹0.70 / g', netQty: '250 g', mfg: '08/2026', exp: '08/2027', mfr: 'Hindustan Unilever Ltd., Unilever House, Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Bru Instant Coffee Chicory Mix Jar', brand: 'Bru', category: 'Tea & Coffee', barcode: '8901030821415', mrp: '₹95.00', usp: '₹0.95 / g', netQty: '100 g', mfg: '07/2026', exp: '07/2028', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Everest Chana Masala Authentic Blend', brand: 'Everest', category: 'Spices & Masalas', barcode: '8901786101211', mrp: '₹42.00', usp: '₹0.42 / g', netQty: '100 g', mfg: '08/2026', exp: '08/2027', mfr: 'S. Narendrakumar & Co., Chembur West, Mumbai - 400089', care: '022-25259999 | customercare@everestspices.com' },
  { name: 'MDH Deggi Mirch Natural Red Pepper', brand: 'MDH', category: 'Spices & Masalas', barcode: '8901243102145', mrp: '₹88.00', usp: '₹0.88 / g', netQty: '100 g', mfg: '08/2026', exp: '08/2027', mfr: 'Mahashian Di Hatti Pvt. Ltd., Kirti Nagar, New Delhi - 110015', care: '011-41425106 | customercare@mdhspices.in' },
  { name: 'Catch Table Salt Fine Sprinkler Jar', brand: 'Catch', category: 'Salt & Seasoning', barcode: '8901025001211', mrp: '₹35.00', usp: '₹0.18 / g', netQty: '200 g', mfg: '08/2026', exp: '08/2028', mfr: 'DS Spiceco Pvt. Ltd., Daryaganj, New Delhi - 110002', care: '0120-4032200 | customercare@dsgroup.com' },
  { name: 'Mother Dairy Full Cream Milk Poly Pack', brand: 'Mother Dairy', category: 'Dairy & Refrigerated', barcode: '8901648001214', mrp: '₹34.00', usp: '₹68.00 / L', netQty: '500 ml', mfg: '09/2026', exp: 'Within 48 hours', mfr: 'Mother Dairy Fruit & Vegetable Pvt. Ltd., Patparganj, Delhi - 110092', care: '1800-180-1018 | consumer.services@motherdairy.com' },
  { name: 'Dettol Original Liquid Handwash Refill Pouch', brand: 'Dettol', category: 'Personal Care', barcode: '8901396321451', mrp: '₹99.00', usp: '₹0.14 / ml', netQty: '675 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Reckitt Benckiser (India) Pvt. Ltd., Gurugram - 122016', care: '1800-102-2720 | consumerhealth_in@reckitt.com' },
  { name: 'Lifebuoy Total Germ Protection Soap Bar', brand: 'Lifebuoy', category: 'Personal Care', barcode: '8901030712348', mrp: '₹140.00', usp: '₹0.28 / g', netQty: '500 g', mfg: '07/2026', exp: '07/2028', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Colgate Total Advanced Health Toothpaste', brand: 'Colgate', category: 'Oral Care', barcode: '8901314010521', mrp: '₹115.00', usp: '₹0.96 / g', netQty: '120 g', mfg: '08/2026', exp: '08/2028', mfr: 'Colgate-Palmolive (India) Ltd., Powai, Mumbai - 400076', care: '1800-225-599 | consumeraffairs_india@colpal.com' },
  { name: 'Sensodyne Fresh Mint Sensitive Toothpaste', brand: 'Sensodyne', category: 'Oral Care', barcode: '8901571004128', mrp: '₹175.00', usp: '₹1.75 / g', netQty: '100 g', mfg: '07/2026', exp: '07/2028', mfr: 'Haleon India Ltd., Gurugram - 122002', care: '1800-222-204 | consumer.relations@haleon.com' },
  { name: 'Surf Excel Matic Front Load Liquid Pouch', brand: 'Surf Excel', category: 'Home Care', barcode: '8901030881234', mrp: '₹240.00', usp: '₹240.00 / L', netQty: '1 L', mfg: '08/2026', exp: '08/2028', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Ariel Matic Complete Liquid Detergent Bottle', brand: 'Ariel', category: 'Home Care', barcode: '8901314502124', mrp: '₹250.00', usp: '₹250.00 / L', netQty: '1 L', mfg: '08/2026', exp: '08/2028', mfr: 'Procter & Gamble Home Products Pvt. Ltd., Mumbai - 400099', care: '1800-202-1364 | intouch.im@pg.com' },
  { name: 'Vim Dishwash Gel Lemon Anti-Germ Bottle', brand: 'Vim', category: 'Home Care', barcode: '8901030514128', mrp: '₹60.00', usp: '₹0.24 / ml', netQty: '250 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Lizol Surface Disinfectant Floor Cleaner Citrus', brand: 'Lizol', category: 'Home Care', barcode: '8901396201248', mrp: '₹115.00', usp: '₹0.23 / ml', netQty: '500 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Reckitt Benckiser (India) Pvt. Ltd., Gurugram - 122016', care: '1800-102-2720 | consumerhealth_in@reckitt.com' },
  { name: 'Harpic Power Plus Original Disinfectant', brand: 'Harpic', category: 'Home Care', barcode: '8901396112014', mrp: '₹93.00', usp: '₹0.19 / ml', netQty: '500 ml', mfg: '08/2026', exp: '08/2028', mfr: 'Reckitt Benckiser (India) Pvt. Ltd., Gurugram - 122016', care: '1800-102-2720 | consumerhealth_in@reckitt.com' },
  { name: 'Bournvita Chocolate Nutrition Drink Pouch', brand: 'Cadbury', category: 'Health Drinks', barcode: '7622201712458', mrp: '₹245.00', usp: '₹0.49 / g', netQty: '500 g', mfg: '07/2026', exp: '07/2027', mfr: 'Mondelez India Foods Pvt. Ltd., Mumbai - 400013', care: '1800-227-080 | suggestions@mdlz.com' },
  { name: 'Horlicks Classic Malt Health Drink Jar', brand: 'Horlicks', category: 'Health Drinks', barcode: '8901030914120', mrp: '₹270.00', usp: '₹0.54 / g', netQty: '500 g', mfg: '08/2026', exp: '08/2027', mfr: 'Hindustan Unilever Ltd., Mumbai - 400099', care: '1800-10-22-221 | lever.care@unilever.com' },
  { name: 'Sunfeast Dark Fantasy Choco Fills', brand: 'Sunfeast', category: 'Biscuits & Cookies', barcode: '8901725013584', mrp: '₹40.00', usp: '₹0.53 / g', netQty: '75 g', mfg: '08/2026', exp: '02/2027', mfr: 'ITC Limited, 37, J.L. Nehru Road, Kolkata - 700071', care: '1800-425-44444 | itccares@itc.in' },
  { name: 'Tata Sampann Unpolished Toor Dal', brand: 'Tata Sampann', category: 'Pulses & Staples', barcode: '8901052003890', mrp: '₹185.00', usp: '₹185.00 / kg', netQty: '1 kg', mfg: '08/2026', exp: '08/2027', mfr: 'Tata Consumer Products Ltd., Kolkata - 700020', care: '1800-345-1720 | customercare@tataconsumer.com' },
  { name: 'Bikaji Bhujia Sev Crispy Namkeen', brand: 'Bikaji', category: 'Snacks & Namkeen', barcode: '8906004452140', mrp: '₹50.00', usp: '₹0.25 / g', netQty: '200 g', mfg: '08/2026', exp: '02/2027', mfr: 'Bikaji Foods International Ltd., Bikaner - 334006', care: '0151-2259914 | customercare@bikaji.com' },
  { name: 'Paper Boat Aamras Mango Drink Tetra', brand: 'Paper Boat', category: 'Beverages', barcode: '8906080601249', mrp: '₹35.00', usp: '₹0.14 / ml', netQty: '250 ml', mfg: '08/2026', exp: '02/2027', mfr: 'Hector Beverages Pvt. Ltd., Bengaluru - 560068', care: '1800-425-4422 | thecaptain@paperboatdrinks.com' },
  { name: 'Real Fruit Power Mixed Fruit Juice', brand: 'Real', category: 'Beverages', barcode: '8901207003418', mrp: '₹120.00', usp: '₹120.00 / L', netQty: '1 L', mfg: '08/2026', exp: '04/2027', mfr: 'Dabur India Limited, Sahibabad, Ghaziabad - 201010', care: '1800-103-1644 | daburcares@dabur.com' },
  { name: 'Amul Cow Milk Tetra Fino Pack', brand: 'Amul', category: 'Dairy & Refrigerated', barcode: '8901262040120', mrp: '₹32.00', usp: '₹64.00 / L', netQty: '500 ml', mfg: '09/2026', exp: 'Best within 90 days', mfr: 'GCMMF Ltd., Amul Dairy Road, Anand - 388001', care: '1800-258-3333 | customercare@amul.coop' },
  { name: 'Kurkure Masala Munch Crunchy Snack', brand: 'Kurkure', category: 'Snacks & Namkeen', barcode: '8901491101254', mrp: '₹20.00', usp: '₹0.25 / g', netQty: '80 g', mfg: '08/2026', exp: '12/2026', mfr: 'PepsiCo India Holdings Pvt. Ltd., Gurugram - 122002', care: '1800-224-020 | consumer.feedback@pepsico.com' },
  { name: 'Lay\'s India\'s Magic Masala Potato Chips', brand: 'Lay\'s', category: 'Snacks & Namkeen', barcode: '8901491001240', mrp: '₹20.00', usp: '₹0.40 / g', netQty: '50 g', mfg: '08/2026', exp: '12/2026', mfr: 'PepsiCo India Holdings Pvt. Ltd., Gurugram - 122002', care: '1800-224-020 | consumer.feedback@pepsico.com' },
  { name: 'Cadbury Dairy Milk Silk Chocolate Bar', brand: 'Cadbury', category: 'Chocolates & Sweets', barcode: '7622201719822', mrp: '₹85.00', usp: '₹1.42 / g', netQty: '60 g', mfg: '08/2026', exp: '08/2027', mfr: 'Mondelez India Foods Pvt. Ltd., Mumbai - 400013', care: '1800-227-080 | suggestions@mdlz.com' },
  { name: 'Nestle KitKat 4-Finger Wafer Bar', brand: 'Nestle', category: 'Chocolates & Sweets', barcode: '8901058842103', mrp: '₹30.00', usp: '₹0.79 / g', netQty: '38 g', mfg: '08/2026', exp: '05/2027', mfr: 'Nestle India Limited, New Delhi - 110001', care: '1800-103-1947 | wecare@in.nestle.com' },
  { name: 'Tata Salt Lite Low Sodium Salt Pouch', brand: 'Tata Salt', category: 'Salt & Seasoning', barcode: '8901052001414', mrp: '₹45.00', usp: '₹45.00 / kg', netQty: '1 kg', mfg: '08/2026', exp: '08/2028', mfr: 'Tata Consumer Products Ltd., Mumbai - 400001', care: '1800-345-1720 | customercare@tataconsumer.com' },
];

/**
 * Generates an ultra-detailed SVG package evidence image (700x900)
 * with visible statutory declarations matching OCR bounding boxes.
 */
function generateEvidenceSvg(
  productName: string,
  brand: string,
  category: string,
  mrp: string,
  usp: string,
  netQty: string,
  mfg: string,
  exp: string,
  mfr: string,
  care: string,
  barcode: string,
  batchNumber: string,
  verdict: OverallVerdict
): string {
  const isViolation = verdict === 'NON_COMPLIANT';
  const isReview = verdict === 'NEEDS_REVIEW';

  const verdictBadgeColor = isViolation ? '#ef4444' : isReview ? '#f59e0b' : '#10b981';
  const verdictText = isViolation
    ? 'NON-COMPLIANT (PCR 2011 NOTICE)'
    : isReview
    ? 'UNDER AUDIT REVIEW (MANUAL CHECK)'
    : 'COMPLIANT & CERTIFIED (RULE 6 PCR 2011)';

  const displayedUsp = isViolation ? '[NOT PRINTED / STATUTORY OMISSION]' : usp;
  const uspColor = isViolation ? '#dc2626' : '#0f172a';
  const uspBg = isViolation ? '#fee2e2' : '#f8fafc';

  return `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 900" width="700" height="900">
  <defs>
    <linearGradient id="foilGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="40%" stop-color="#1e293b" />
      <stop offset="100%" stop-color="#090d16" />
    </linearGradient>
    <linearGradient id="headerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="100%" stop-color="#0369a1" />
    </linearGradient>
    <filter id="cardShadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="6" stdDeviation="10" flood-color="#000" flood-opacity="0.5" />
    </filter>
  </defs>

  <!-- Package Pouch Background -->
  <rect x="30" y="20" width="640" height="860" rx="32" fill="url(#foilGrad)" stroke="#334155" stroke-width="3" filter="url(#cardShadow)" />
  
  <!-- Heat Seals -->
  <path d="M30 65 Q350 85 670 65 L670 20 Q350 35 30 20 Z" fill="#334155" opacity="0.7" />
  <path d="M30 880 Q350 860 670 880 L670 835 Q350 850 30 835 Z" fill="#334155" opacity="0.7" />

  <!-- Top Brand Banner -->
  <rect x="160" y="75" width="380" height="42" rx="10" fill="url(#headerGrad)" />
  <text x="350" y="103" fill="#ffffff" font-family="system-ui, sans-serif" font-weight="900" font-size="20" text-anchor="middle" letter-spacing="2">★ ${brand.toUpperCase()} ★</text>

  <!-- Category & Batch Header Badge -->
  <rect x="230" y="125" width="240" height="24" rx="12" fill="#334155" opacity="0.8" />
  <text x="350" y="141" fill="#94a3b8" font-family="monospace" font-size="11" text-anchor="middle" font-weight="bold">CATEGORY: ${category.toUpperCase()} | ${batchNumber}</text>

  <!-- Commodity Title -->
  <text x="350" y="185" fill="#f8fafc" font-family="system-ui, sans-serif" font-weight="900" font-size="26" text-anchor="middle">${productName.slice(0, 32)}</text>
  
  <!-- Generic Name Pill -->
  <rect x="100" y="205" width="500" height="26" rx="6" fill="#0284c7" fill-opacity="0.2" stroke="#38bdf8" stroke-dasharray="4 2" />
  <text x="350" y="222" fill="#7dd3fc" font-family="system-ui, sans-serif" font-weight="700" font-size="12" text-anchor="middle">GENERIC NAME: ${productName.toUpperCase()}</text>

  <!-- Statutory Declaration Panel (Legal Metrology Packaged Commodities Rules 2011) -->
  <rect x="60" y="250" width="580" height="560" rx="16" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
  
  <!-- Panel Title Bar -->
  <rect x="60" y="250" width="580" height="40" rx="16" fill="#0f172a" />
  <rect x="60" y="275" width="580" height="15" fill="#0f172a" />
  <text x="350" y="276" fill="#38bdf8" font-family="system-ui, sans-serif" font-size="13" font-weight="900" text-anchor="middle" letter-spacing="1">MANDATORY STATUTORY DECLARATIONS (PCR 2011)</text>

  <!-- Field 1: Net Quantity (Rule 6(1)(b)) -->
  <rect x="80" y="305" width="255" height="65" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1.5" />
  <text x="95" y="327" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">NET QUANTITY (Rule 6(1)(b)):</text>
  <text x="95" y="356" fill="#0f172a" font-family="system-ui, sans-serif" font-size="20" font-weight="900">${netQty}</text>

  <!-- Field 2: MRP (Rule 6(1)(e)) -->
  <rect x="365" y="305" width="255" height="65" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1.5" />
  <text x="380" y="327" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">MAX. RETAIL PRICE (Rule 6(1)(e)):</text>
  <text x="380" y="356" fill="#0f172a" font-family="system-ui, sans-serif" font-size="20" font-weight="900">${mrp} <tspan font-size="12" font-weight="normal" fill="#64748b">(incl. taxes)</tspan></text>

  <!-- Field 3: Manufacturer Address (Rule 6(1)(a)) -->
  <rect x="80" y="385" width="540" height="75" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1.5" />
  <text x="95" y="407" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">MANUFACTURED &amp; PACKED BY (Rule 6(1)(a)):</text>
  <text x="95" y="432" fill="#0f172a" font-family="system-ui, sans-serif" font-size="13" font-weight="700">${mfr.slice(0, 75)}</text>
  <text x="95" y="450" fill="#334155" font-family="system-ui, sans-serif" font-size="12">${mfr.slice(75, 150) || 'Registered Premises, Industrial Area, India'}</text>

  <!-- Field 4: Date Info (Rule 6(1)(d)) -->
  <rect x="80" y="475" width="255" height="65" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1.5" />
  <text x="95" y="497" fill="#64748b" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">MFG &amp; EXPIRY (Rule 6(1)(d)):</text>
  <text x="95" y="525" fill="#0f172a" font-family="system-ui, sans-serif" font-size="15" font-weight="800">Mfg: ${mfg} | Exp: ${exp.slice(0, 15)}</text>

  <!-- Field 5: Unit Sale Price (Rule 6(1)(h)) -->
  <rect x="365" y="475" width="255" height="65" rx="8" fill="${uspBg}" stroke="${isViolation ? '#f87171' : '#e2e8f0'}" stroke-width="${isViolation ? 2 : 1.5}" />
  <text x="380" y="497" fill="${isViolation ? '#dc2626' : '#64748b'}" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">UNIT SALE PRICE (Rule 6(1)(h)):</text>
  <text x="380" y="525" fill="${uspColor}" font-family="system-ui, sans-serif" font-size="15" font-weight="800">${displayedUsp}</text>

  <!-- Field 6: Consumer Care Cell (Rule 6(1)(g)) -->
  <rect x="80" y="555" width="540" height="70" rx="8" fill="${isReview ? '#fffbeb' : '#f8fafc'}" stroke="${isReview ? '#fcd34d' : '#e2e8f0'}" stroke-width="1.5" />
  <text x="95" y="577" fill="${isReview ? '#b45309' : '#64748b'}" font-family="system-ui, sans-serif" font-size="11" font-weight="bold">CONSUMER CARE CELL (Rule 6(1)(g)):</text>
  <text x="95" y="605" fill="#0f172a" font-family="system-ui, sans-serif" font-size="13" font-weight="700">${care}</text>

  <!-- Barcode Graphic with EAN-13 -->
  <rect x="80" y="640" width="540" height="70" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1.5" />
  <g transform="translate(180, 648)">
    <rect x="0" y="0" width="4" height="40" fill="#0f172a"/>
    <rect x="8" y="0" width="2" height="40" fill="#0f172a"/>
    <rect x="14" y="0" width="6" height="40" fill="#0f172a"/>
    <rect x="24" y="0" width="2" height="40" fill="#0f172a"/>
    <rect x="32" y="0" width="4" height="40" fill="#0f172a"/>
    <rect x="42" y="0" width="8" height="40" fill="#0f172a"/>
    <rect x="54" y="0" width="2" height="40" fill="#0f172a"/>
    <rect x="62" y="0" width="6" height="40" fill="#0f172a"/>
    <rect x="74" y="0" width="4" height="40" fill="#0f172a"/>
    <rect x="82" y="0" width="2" height="40" fill="#0f172a"/>
    <rect x="92" y="0" width="6" height="40" fill="#0f172a"/>
    <rect x="104" y="0" width="4" height="40" fill="#0f172a"/>
    <rect x="114" y="0" width="8" height="40" fill="#0f172a"/>
    <rect x="128" y="0" width="2" height="40" fill="#0f172a"/>
    <rect x="136" y="0" width="6" height="40" fill="#0f172a"/>
    <rect x="148" y="0" width="4" height="40" fill="#0f172a"/>
    <rect x="158" y="0" width="2" height="40" fill="#0f172a"/>
    <rect x="166" y="0" width="6" height="40" fill="#0f172a"/>
    <rect x="178" y="0" width="4" height="40" fill="#0f172a"/>
    <rect x="188" y="0" width="8" height="40" fill="#0f172a"/>
    <rect x="202" y="0" width="2" height="40" fill="#0f172a"/>
    <rect x="210" y="0" width="6" height="40" fill="#0f172a"/>
    <rect x="222" y="0" width="4" height="40" fill="#0f172a"/>
    <rect x="232" y="0" width="8" height="40" fill="#0f172a"/>
    <rect x="246" y="0" width="4" height="40" fill="#0f172a"/>
    <text x="125" y="55" fill="#334155" font-family="monospace" font-size="13" font-weight="bold" text-anchor="middle">${barcode}</text>
  </g>

  <!-- Legal Metrology Status Ribbon / Watermark Stamp -->
  <rect x="80" y="725" width="540" height="70" rx="10" fill="${verdictBadgeColor}" fill-opacity="0.12" stroke="${verdictBadgeColor}" stroke-width="2" />
  <circle cx="120" cy="760" r="22" fill="${verdictBadgeColor}" />
  <text x="120" y="767" fill="#ffffff" font-family="system-ui, sans-serif" font-size="20" font-weight="bold" text-anchor="middle">${isViolation ? '✗' : isReview ? '!' : '✓'}</text>
  <text x="160" y="752" fill="${verdictBadgeColor}" font-family="system-ui, sans-serif" font-size="14" font-weight="900">${verdictText}</text>
  <text x="160" y="774" fill="#64748b" font-family="monospace" font-size="11">CERTIFIED EVIDENCE ARTIFACT • AUDIT LOG: ${batchNumber}</text>
</svg>
`)}`;
}

export function generate300DemoInspections(): InspectionRecord[] {
  const records: InspectionRecord[] = [];

  // Equal division of 300 packages:
  // Compliant: 100 certified
  // Review Queue (Needs Review): 100 flagged
  // Violations (Non-Compliant): 100 omissions
  const TARGET_COMPLIANT = 100;
  const TARGET_REVIEW = 100;
  const TARGET_VIOLATIONS = 100;
  const TOTAL = TARGET_COMPLIANT + TARGET_REVIEW + TARGET_VIOLATIONS; // 300

  for (let i = 0; i < TOTAL; i++) {
    const itemIndex = i % EXPANDED_CATALOG.length;
    const baseItem = EXPANDED_CATALOG[itemIndex];
    const sequenceNum = String(i + 1).padStart(3, '0');
    const id = `insp-pkg-${sequenceNum}`;
    const batchNumber = `LOT-2026-B${sequenceNum}`;

    let overallVerdict: OverallVerdict = 'COMPLIANT';
    let batchStatus: BatchStatus = 'RELEASED';
    let complianceScore = 96;

    if (i >= TARGET_COMPLIANT && i < TARGET_COMPLIANT + TARGET_REVIEW) {
      // Review Queue (46 packages)
      overallVerdict = 'NEEDS_REVIEW';
      batchStatus = 'HOLD';
      complianceScore = 78;
    } else if (i >= TARGET_COMPLIANT + TARGET_REVIEW) {
      // Violations (24 packages)
      overallVerdict = 'NON_COMPLIANT';
      batchStatus = 'RECALLED';
      complianceScore = 42;
    }

    // Spread timestamps across the last 30 days
    const dayOffset = Math.floor((300 - i) / 10);
    const hourOffset = (i * 7) % 24;
    const minuteOffset = (i * 23) % 60;
    const recordDate = new Date(2026, 8, 23 - dayOffset, hourOffset, minuteOffset);
    const scannedAt = recordDate.toISOString();

    const isViolation = overallVerdict === 'NON_COMPLIANT';
    const isReview = overallVerdict === 'NEEDS_REVIEW';

    // Build evidence image matching actual statutory declarations
    const evidenceImage = generateEvidenceSvg(
      baseItem.name,
      baseItem.brand,
      baseItem.category,
      baseItem.mrp,
      baseItem.usp,
      baseItem.netQty,
      baseItem.mfg,
      baseItem.exp,
      baseItem.mfr,
      baseItem.care,
      baseItem.barcode,
      batchNumber,
      overallVerdict
    );

    const fields: Record<MVPFieldKey, ExtractedField> = {
      mrp: {
        fieldKey: 'mrp',
        fieldName: 'Maximum Retail Price (MRP)',
        rawValue: baseItem.mrp,
        cleanedValue: baseItem.mrp,
        status: isViolation && (i % 3 === 0) ? 'MISSING' : 'FOUND',
        confidence: isViolation && (i % 3 === 0) ? 0.2 : 0.98,
        evidenceSnippet: isViolation && (i % 3 === 0) ? 'MRP not printed or illegible' : `MRP ${baseItem.mrp} (inclusive of all taxes)`,
        ruleReference: 'PCR 2011 Rule 6(1)(e)',
        ruleExplanation: 'Every package must bear retail sale price inclusive of all taxes.',
        boundingBox: { x: 52, y: 34, width: 36, height: 7 },
      },
      netQuantity: {
        fieldKey: 'netQuantity',
        fieldName: 'Net Quantity Declaration',
        rawValue: isViolation && (i % 4 === 0) ? `${baseItem.netQty} approx` : baseItem.netQty,
        cleanedValue: baseItem.netQty,
        status: isViolation && (i % 4 === 0) ? 'MISSING' : 'FOUND',
        confidence: isViolation && (i % 4 === 0) ? 0.35 : 0.97,
        evidenceSnippet: `Net Quantity: ${baseItem.netQty}`,
        ruleReference: 'PCR 2011 Rule 6(1)(b) & Schedule II',
        ruleExplanation: 'Standard units of mass or measure (g, kg, ml, L) without qualifying words.',
        boundingBox: { x: 11, y: 34, width: 36, height: 7 },
      },
      manufacturer: {
        fieldKey: 'manufacturer',
        fieldName: 'Manufacturer / Packer Identity',
        rawValue: baseItem.mfr,
        cleanedValue: baseItem.mfr,
        status: isReview && (i % 3 === 0) ? 'REVIEW' : 'FOUND',
        confidence: isReview && (i % 3 === 0) ? 0.72 : 0.96,
        evidenceSnippet: baseItem.mfr,
        ruleReference: 'PCR 2011 Rule 6(1)(a)',
        ruleExplanation: 'Name and complete address of the manufacturer or pre-packer.',
        boundingBox: { x: 11, y: 43, width: 77, height: 8 },
      },
      genericName: {
        fieldKey: 'genericName',
        fieldName: 'Generic / Common Name of Commodity',
        rawValue: baseItem.name,
        cleanedValue: baseItem.name,
        status: 'FOUND',
        confidence: 0.96,
        evidenceSnippet: `GENERIC NAME: ${baseItem.name.toUpperCase()}`,
        ruleReference: 'PCR 2011 Rule 6(1)(c)',
        ruleExplanation: 'Common or generic name of commodity contained in the package.',
        boundingBox: { x: 14, y: 23, width: 71, height: 3 },
      },
      dateInfo: {
        fieldKey: 'dateInfo',
        fieldName: 'Month & Year of Manufacture / Packing',
        rawValue: baseItem.mfg,
        cleanedValue: baseItem.mfg,
        status: isViolation && (i % 3 === 1) ? 'MISSING' : isReview && (i % 3 === 1) ? 'REVIEW' : 'FOUND',
        confidence: isViolation && (i % 3 === 1) ? 0.15 : isReview && (i % 3 === 1) ? 0.68 : 0.95,
        evidenceSnippet: `Mfg: ${baseItem.mfg} | Best Before: ${baseItem.exp}`,
        ruleReference: 'PCR 2011 Rule 6(1)(d)',
        ruleExplanation: 'Month and year of manufacture or pre-packing must be clearly visible.',
        boundingBox: { x: 11, y: 53, width: 36, height: 7 },
      },
      consumerCare: {
        fieldKey: 'consumerCare',
        fieldName: 'Consumer Care Cell Details',
        rawValue: isViolation && (i % 3 === 2) ? 'Write to factory' : baseItem.care,
        cleanedValue: baseItem.care,
        status: isViolation && (i % 3 === 2) ? 'MISSING' : isReview && (i % 3 === 2) ? 'REVIEW' : 'FOUND',
        confidence: isViolation && (i % 3 === 2) ? 0.25 : isReview && (i % 3 === 2) ? 0.74 : 0.95,
        evidenceSnippet: baseItem.care,
        ruleReference: 'PCR 2011 Rule 6(1)(g)',
        ruleExplanation: 'Name, address, telephone number and email of person or grievance officer.',
        boundingBox: { x: 11, y: 62, width: 77, height: 8 },
      },
      unitSalePrice: {
        fieldKey: 'unitSalePrice',
        fieldName: 'Unit Sale Price (USP)',
        rawValue: isViolation ? '[NOT PRINTED]' : baseItem.usp,
        cleanedValue: isViolation ? '' : baseItem.usp,
        status: isViolation ? 'MISSING' : 'FOUND',
        confidence: isViolation ? 0.1 : 0.96,
        evidenceSnippet: isViolation ? 'Omission: Unit Sale Price mandatory under Rule 6(1)(h)' : `Unit Sale Price: ${baseItem.usp}`,
        ruleReference: 'PCR 2011 Rule 6(1)(h)',
        ruleExplanation: 'Unit Sale Price in Rupees per g, kg, ml or L must be declared on packages > 100g/ml.',
        boundingBox: { x: 52, y: 53, width: 36, height: 7 },
      },
    };

    records.push({
      id,
      commodityName: baseItem.name,
      brandName: baseItem.brand,
      batchNumber,
      batchStatus,
      category: baseItem.category,
      scannedAt,
      imageUrl: evidenceImage,
      imageQuality: {
        score: isReview ? 74 : 96,
        blurScore: isReview ? 'MODERATE_BLUR' : 'SHARP',
        lightingQuality: 'GOOD',
        resolutionScore: 'PASS',
        framingScore: 'CENTERED',
        isReadable: true,
        warnings: isReview ? ['Partial low-contrast print detected on declaration borders'] : [],
      },
      fields,
      overallVerdict,
      complianceScore,
      officerRemarks:
        overallVerdict === 'COMPLIANT'
          ? 'Full statutory compliance verified under Legal Metrology Packaged Commodities Rules, 2011.'
          : overallVerdict === 'NEEDS_REVIEW'
          ? 'Visual verification recommended for declaration font heights and contrast.'
          : 'Statutory non-compliance: Mandatory declarations omitted or non-standard under PCR 2011.',
      officerName: 'J. Sharma, Metrologist',
      officerDesignation: 'Legal Metrology Inspector, Grade I',
      location: 'Central Depot Terminal, Gate 4',
      barcodeData: {
        rawValue: baseItem.barcode,
        format: 'EAN_13',
        type: 'FMCG_PACKAGED_GOODS',
        productName: baseItem.name,
        brandName: baseItem.brand,
        category: baseItem.category,
        mrp: baseItem.mrp,
        netQuantity: baseItem.netQty,
        unitSalePrice: baseItem.usp,
        lotNumber: batchNumber,
        countryOfOrigin: 'India',
        manufacturerName: baseItem.mfr,
        isRealDatabaseLookup: true,
      },
      status: overallVerdict === 'COMPLIANT' ? 'REPORT_ISSUED' : 'ANALYZED',
      createdAt: scannedAt,
      updatedAt: scannedAt,
    });
  }

  return records;
}
