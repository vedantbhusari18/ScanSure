import { ImageQualityMetrics } from '../types/inspection';

export function analyzeImageQuality(
  imgWidth: number = 800,
  imgHeight: number = 600,
  isDemoSample: boolean = false,
  presetIssue?: 'BLUR' | 'GLARE' | 'LOW_RES' | 'NONE'
): ImageQualityMetrics {
  const warnings: string[] = [];

  // Resolution check
  const minPixels = 400 * 300;
  const actualPixels = imgWidth * imgHeight;
  let resolutionScore: 'PASS' | 'MARGINAL' | 'FAIL' = 'PASS';
  if (actualPixels < minPixels) {
    resolutionScore = 'FAIL';
    warnings.push('Image resolution is below 300 DPI equivalent. Small fonts may degrade OCR.');
  } else if (actualPixels < 800 * 600) {
    resolutionScore = 'MARGINAL';
    warnings.push('Moderate resolution. Recommend closer crop for fine text verification.');
  }

  let blurScore: 'SHARP' | 'MODERATE_BLUR' | 'SEVERE_BLUR' = 'SHARP';
  let lightingQuality: 'GOOD' | 'GLARE_DETECTED' | 'UNDEREXPOSED' = 'GOOD';
  let framingScore: 'CENTERED' | 'ANGLED' | 'CROPPED' = 'CENTERED';
  let score = 92;

  if (presetIssue === 'BLUR') {
    blurScore = 'MODERATE_BLUR';
    score -= 25;
    warnings.push('Edge contrast indicates camera motion blur on consumer care panel.');
  } else if (presetIssue === 'GLARE') {
    lightingQuality = 'GLARE_DETECTED';
    score -= 20;
    warnings.push('Specular reflection/glare detected over packaging laminate.');
  } else if (presetIssue === 'LOW_RES') {
    resolutionScore = 'FAIL';
    score -= 35;
    warnings.push('Low pixel density detected on secondary declaration panel.');
  }

  if (resolutionScore === 'MARGINAL') score -= 10;
  if (resolutionScore === 'FAIL') score -= 25;

  score = Math.max(15, Math.min(100, score));

  return {
    score,
    blurScore,
    lightingQuality,
    resolutionScore,
    framingScore,
    isReadable: score >= 50,
    warnings,
  };
}
