import { jsPDF } from 'jspdf';
import { InspectionRecord, MVPFieldKey } from '../types/inspection';

export function generateCompliancePdf(record: InspectionRecord): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 14;

  // Header Banner
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Emblem / Logo accent
  doc.setFillColor(245, 158, 11); // amber-500
  doc.rect(margin, 6, 3, 16, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.text('ScanSure — PACKAGED COMMODITY COMPLIANCE REPORT', margin + 6, 13);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225);
  doc.text(`Batch Status: ${record.batchStatus || 'RELEASED'} | Legal Metrology (Packaged Commodities) Rules 2011`, margin + 6, 20);

  // Subheader: Formal Notice Title
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text('STATUTORY INSPECTION & AUDIT REPORT', margin, 38);

  // Inspection ID & Date box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, 42, pageWidth - margin * 2, 22, 2, 2, 'FD');

  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('INSPECTION ID:', margin + 4, 48);
  doc.text('SCANNED AT:', margin + 65, 48);
  doc.text('OFFICER / AUDITOR:', margin + 125, 48);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(record.id, margin + 4, 55);
  doc.text(new Date(record.scannedAt).toLocaleString(), margin + 65, 55);
  doc.text(record.officerName || 'Inspector (Legal Metrology Cell)', margin + 125, 55);

  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`Location: ${record.location || 'Central Inspection Terminal, Zone 1'}`, margin + 125, 60);

  // Commodity Particulars Box
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(margin, 68, pageWidth - margin * 2, 18, 2, 2, 'FD');

  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`Commodity: ${record.commodityName}`, margin + 4, 75);
  doc.text(`Brand: ${record.brandName}`, margin + 85, 75);
  doc.text(`Batch: ${record.batchNumber || 'N/A'} [${record.batchStatus || 'RELEASED'}]`, margin + 140, 75);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Category: ${record.category} | Image Quality: ${record.imageQuality.score}% (${record.imageQuality.blurScore})`, margin + 4, 81);

  // Verdict Banner
  let verdictColor: [number, number, number] = [34, 197, 94]; // green
  let verdictTitle = 'VERDICT: COMPLIANT WITH PACKAGED COMMODITIES RULES';
  if (record.overallVerdict === 'NON_COMPLIANT') {
    verdictColor = [225, 29, 72]; // red
    verdictTitle = 'VERDICT: NON-COMPLIANT (STATUTORY VIOLATIONS DETECTED)';
  } else if (record.overallVerdict === 'NEEDS_REVIEW') {
    verdictColor = [217, 119, 6]; // amber
    verdictTitle = 'VERDICT: CONDITIONAL (MANUAL VERIFICATION REQUIRED)';
  }

  doc.setFillColor(...verdictColor);
  doc.roundedRect(margin, 90, pageWidth - margin * 2, 12, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(verdictTitle, margin + 6, 97.5);
  doc.text(`Score: ${record.complianceScore}%`, pageWidth - margin - 26, 97.5);

  // Declarations Table
  let y = 108;
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('AUDIT FINDINGS BY MANDATORY DECLARATION (7 MVP FIELDS)', margin, y);

  y += 5;
  // Table Header
  doc.setFillColor(30, 41, 59);
  doc.rect(margin, y, pageWidth - margin * 2, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('FIELD / DECLARATION', margin + 3, y + 4.8);
  doc.text('STATUS', margin + 55, y + 4.8);
  doc.text('EXTRACTED EVIDENCE / VALUE', margin + 80, y + 4.8);
  doc.text('CONF.', margin + 145, y + 4.8);
  doc.text('LEGAL RULE', margin + 160, y + 4.8);

  y += 7;

  const fieldKeys: MVPFieldKey[] = [
    'mrp',
    'netQuantity',
    'manufacturer',
    'genericName',
    'dateInfo',
    'consumerCare',
    'unitSalePrice',
  ];

  doc.setFont('helvetica', 'normal');

  fieldKeys.forEach((key, index) => {
    const field = record.fields[key];
    const isAlt = index % 2 === 1;

    // Row background
    doc.setFillColor(isAlt ? 248 : 255, isAlt ? 250 : 255, isAlt ? 252 : 255);
    doc.rect(margin, y, pageWidth - margin * 2, 12, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y + 12, pageWidth - margin, y + 12);

    // Field name
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text(field.fieldName.length > 24 ? field.fieldName.slice(0, 22) + '...' : field.fieldName, margin + 3, y + 5);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text(field.ruleReference.split(',')[1]?.trim() || field.ruleReference, margin + 3, y + 9);

    // Status Badge
    let statusText = 'FOUND';
    let sColor: [number, number, number] = [22, 163, 74];
    if (field.status === 'REVIEW') {
      statusText = 'REVIEW';
      sColor = [217, 119, 6];
    } else if (field.status === 'MISSING') {
      statusText = 'MISSING';
      sColor = [220, 38, 38];
    }

    doc.setFillColor(...sColor);
    doc.roundedRect(margin + 55, y + 2.5, 18, 5.5, 1, 1, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.text(statusText, margin + 57, y + 6.3);

    // Evidence / Value
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    const displayVal = field.cleanedValue || field.rawValue || (field.status === 'MISSING' ? '[Declaration Not Found on Label]' : '[Unclear / Smudged]');
    const truncatedVal = displayVal.length > 42 ? displayVal.slice(0, 40) + '...' : displayVal;
    doc.text(truncatedVal, margin + 80, y + 5);

    if (field.trustNote) {
      doc.setFontSize(6.5);
      doc.setTextColor(180, 83, 9);
      doc.text(field.trustNote.slice(0, 50), margin + 80, y + 9);
    }

    // Confidence
    doc.setTextColor(71, 85, 105);
    doc.setFontSize(7.5);
    doc.text(`${Math.round(field.confidence * 100)}%`, margin + 145, y + 6.5);

    // Legal Ref
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text('PCR 2011', margin + 160, y + 6.5);

    y += 12;
  });

  // Trust Rule Compliance Note
  y += 6;
  doc.setFillColor(254, 243, 199);
  doc.setDrawColor(251, 191, 36);
  doc.roundedRect(margin, y, pageWidth - margin * 2, 14, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(146, 64, 14);
  doc.text('SYSTEM TRUST RULE & PROPORTIONALITY CERTIFICATION:', margin + 4, y + 5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text(
    'In accordance with SIH26034 trust criteria, illegible or smudged markings are designated as "Unable to verify" (REVIEW)',
    margin + 4,
    y + 9
  );
  doc.text(
    'and referred to human inspector verification rather than issuing automatic statutory violation penalties.',
    margin + 4,
    y + 12.5
  );

  // Officer Remarks & Signatures
  y += 18;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(margin, y, pageWidth - margin * 2, 34, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text('INSPECTOR REMARKS & DIRECTIVE:', margin + 4, y + 6);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    record.officerRemarks ||
      'Verified automated scan findings. Unit Sale Price absence confirmed on retail pack. Section 36 Notice to be prepared.',
    margin + 4,
    y + 12
  );

  // Signature lines
  const sigY = y + 26;
  doc.setDrawColor(148, 163, 184);
  doc.line(margin + 4, sigY, margin + 55, sigY);
  doc.line(pageWidth - margin - 55, sigY, pageWidth - margin - 4, sigY);

  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text('Authorized Legal Metrology Inspector', margin + 4, sigY + 4);
  doc.text('Packer / Manufacturer Representative', pageWidth - margin - 55, sigY + 4);

  // Footer
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text('Designed & Developed by Team HexaByte | ScanSure Compliance Engine', margin, pageHeight - 8);
  doc.text(`Page 1 of 1`, pageWidth - margin - 15, pageHeight - 8);

  return doc;
}
