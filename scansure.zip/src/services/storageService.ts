import { DashboardStats, InspectionRecord } from '../types/inspection';
import { generate300DemoInspections } from '../data/demo300Inspections';

const LOCAL_STORAGE_KEY = 'hexabyte_inspections_v1';
const DB_NAME = 'hexabyte_inspections_db';
const STORE_NAME = 'inspections';
const DB_VERSION = 1;

// ---------------- IndexedDB Implementation (Unlimited Quota Storage) ----------------
function openIdb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB not supported in this environment'));
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getIdbAll(): Promise<InspectionRecord[]> {
  try {
    const db = await openIdb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

async function putIdbRecord(record: InspectionRecord): Promise<void> {
  try {
    const db = await openIdb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(record);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Non-blocking fallback
  }
}

async function deleteIdbRecord(id: string): Promise<void> {
  try {
    const db = await openIdb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Non-blocking fallback
  }
}

// ---------------- Quota-Safe LocalStorage Helper ----------------
// Strips or trims heavy base64 strings so LocalStorage 5MB quota is NEVER exceeded
function safeSaveToLocalStorage(records: InspectionRecord[]): void {
  try {
    // 1. First attempt: standard save with lightweight image references
    const sanitized = records.slice(0, 30).map((item) => {
      if (item.imageUrl && item.imageUrl.length > 50000) {
        return {
          ...item,
          imageUrl: item.imageUrl.slice(0, 200) + '...[cached-in-idb]',
        };
      }
      return item;
    });
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(sanitized));
  } catch {
    // 2. Second attempt: strip all image data entirely to prevent quota error
    try {
      const stripped = records.slice(0, 15).map((item) => ({
        ...item,
        imageUrl: '',
      }));
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(stripped));
    } catch {
      // 3. Last resort: clear full/corrupted key silently
      try {
        localStorage.removeItem(LOCAL_STORAGE_KEY);
      } catch {
        // Storage disabled or blocked
      }
    }
  }
}

function safeReadFromLocalStorage(): InspectionRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return [];
}

function normalizeRecord(item: InspectionRecord): InspectionRecord {
  return {
    ...item,
    batchStatus:
      item.batchStatus ||
      (item.overallVerdict === 'COMPLIANT'
        ? 'RELEASED'
        : item.overallVerdict === 'NEEDS_REVIEW'
        ? 'HOLD'
        : 'RECALLED'),
  };
}

// ---------------- Primary Public API ----------------

export async function seed300DemoInspectionsAction(): Promise<InspectionRecord[]> {
  const records = generate300DemoInspections().map(normalizeRecord);

  // 1. Sync with backend API
  try {
    await fetch('/api/demo/seed-300', { method: 'POST' });
  } catch (err) {
    console.warn('Backend seed endpoint unreachable, saving to local offline storage:', err);
  }

  // 2. Put into IndexedDB (supports unlimited data & full SVG evidence images)
  for (const record of records) {
    putIdbRecord(record).catch(() => {});
  }

  // 3. Save lightweight reference into LocalStorage
  safeSaveToLocalStorage(records);

  return records;
}

// Backward-compatible alias
export const seed100DemoInspectionsAction = seed300DemoInspectionsAction;

export async function fetchAllInspections(): Promise<InspectionRecord[]> {
  // 1. Try Backend API first
  try {
    const res = await fetch('/api/inspections');
    if (res.ok) {
      const data: InspectionRecord[] = await res.json();
      if (Array.isArray(data) && data.length >= 300) {
        const normalized = data.map(normalizeRecord);
        // Sync to IndexedDB for offline fast access
        for (const record of normalized) {
          putIdbRecord(record).catch(() => {});
        }
        safeSaveToLocalStorage(normalized);
        return normalized;
      }
    }
  } catch (err) {
    console.warn('Backend API unreachable, using local storage cache:', err);
  }

  // 2. Try IndexedDB (holds full uncompressed records & images)
  try {
    const idbData = await getIdbAll();
    if (Array.isArray(idbData) && idbData.length >= 300) {
      const compliant = idbData.filter((i) => i.overallVerdict === 'COMPLIANT').length;
      const review = idbData.filter((i) => i.overallVerdict === 'NEEDS_REVIEW').length;
      if (compliant === 100 && review === 100) {
        const normalized = idbData.map(normalizeRecord);
        safeSaveToLocalStorage(normalized);
        return normalized;
      }
    }
  } catch {
    // fallback to local storage
  }

  // 3. Check LocalStorage
  const localData = safeReadFromLocalStorage().map(normalizeRecord);
  if (localData.length >= 300) {
    const compliant = localData.filter((i) => i.overallVerdict === 'COMPLIANT').length;
    const review = localData.filter((i) => i.overallVerdict === 'NEEDS_REVIEW').length;
    if (compliant === 100 && review === 100) {
      return localData;
    }
  }

  // 4. If fewer than 300 records or old distribution, auto-seed the 300 demo records
  return await seed300DemoInspectionsAction();
}

export async function saveInspectionRecord(record: InspectionRecord): Promise<void> {
  // 1. Save full record to IndexedDB (no quota issues)
  await putIdbRecord(record).catch(() => {});

  // 2. Update local storage with quota-safe trimming
  try {
    const existing = safeReadFromLocalStorage();
    const idx = existing.findIndex((item: InspectionRecord) => item.id === record.id);
    if (idx >= 0) {
      existing[idx] = record;
    } else {
      existing.unshift(record);
    }
    safeSaveToLocalStorage(existing);
  } catch {
    // Non-blocking
  }

  // 3. Sync with backend API
  try {
    await fetch('/api/inspections', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record),
    });
  } catch (err) {
    console.warn('Backend API sync deferred:', err);
  }
}

export async function deleteInspectionRecord(id: string): Promise<void> {
  // 1. Delete from IndexedDB
  await deleteIdbRecord(id).catch(() => {});

  // 2. Delete from LocalStorage
  try {
    const existing = safeReadFromLocalStorage();
    const filtered = existing.filter((item: InspectionRecord) => item.id !== id);
    safeSaveToLocalStorage(filtered);
  } catch {
    // Non-blocking
  }

  // 3. Delete from backend API
  try {
    await fetch(`/api/inspections/${id}`, { method: 'DELETE' });
  } catch (err) {
    console.warn(err);
  }
}

export function computeDashboardStats(inspections: InspectionRecord[]): DashboardStats {
  const totalScanned = inspections.length;
  const compliantCount = inspections.filter((i) => i.overallVerdict === 'COMPLIANT').length;
  const reviewRequiredCount = inspections.filter((i) => i.overallVerdict === 'NEEDS_REVIEW').length;
  const violationCount = inspections.filter((i) => i.overallVerdict === 'NON_COMPLIANT').length;

  const complianceRate = totalScanned > 0 ? Math.round((compliantCount / totalScanned) * 100) : 0;

  let totalConf = 0;
  let fieldCount = 0;
  inspections.forEach((ins) => {
    Object.values(ins.fields).forEach((f) => {
      totalConf += f.confidence;
      fieldCount++;
    });
  });

  const averageConfidence = fieldCount > 0 ? Math.round((totalConf / fieldCount) * 100) : 92;

  const releasedCount = inspections.filter((i) => i.batchStatus === 'RELEASED').length;
  const holdCount = inspections.filter((i) => i.batchStatus === 'HOLD').length;
  const inspectingCount = inspections.filter((i) => i.batchStatus === 'INSPECTION').length;
  const recalledCount = inspections.filter((i) => i.batchStatus === 'RECALLED').length;

  return {
    totalScanned,
    compliantCount,
    reviewRequiredCount,
    violationCount,
    complianceRate,
    averageConfidence,
    recentInspections: inspections.slice(0, 8),
    batchStatusCounts: {
      released: releasedCount,
      hold: holdCount,
      inspection: inspectingCount,
      recalled: recalledCount,
    },
  };
}
