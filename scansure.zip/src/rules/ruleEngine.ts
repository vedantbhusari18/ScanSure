import { ExtractedField, FieldStatus, MVPFieldKey, OverallVerdict } from '../types/inspection';
import { LEGAL_RULES_CONFIG } from './rulesConfig';

export interface EvaluationInput {
  fieldKey: MVPFieldKey;
  found: boolean;
  isReadable: boolean;
  rawValue: string;
  cleanedValue: string;
  confidence: number;
  boundingBox?: { x: number; y: number; width: number; height: number };
  evidenceSnippet: string;
  notes?: string;
}

export function evaluateField(input: EvaluationInput): ExtractedField {
  const rule = LEGAL_RULES_CONFIG[input.fieldKey];
  let status: FieldStatus = 'MISSING';
  let trustNote: string | undefined = undefined;
  let ruleExplanation = '';

  // IMPORTANT TRUST RULE:
  // If the text is present or partially captured but deemed unreadable/blurry/unclear,
  // it is categorized as "Unable to verify" (REVIEW), NOT automatically a violation.
  if (!input.isReadable && (input.rawValue.trim().length > 0 || input.notes?.toLowerCase().includes('unclear') || input.confidence < 0.5)) {
    status = 'REVIEW';
    trustNote = 'Trust Rule Applied: Unreadable/unclear text marked as "Unable to verify" for human inspection, not an immediate violation penalty.';
    ruleExplanation = `Declared field present on package but text quality is degraded or partially smudged. Flagged for officer physical verification under ${rule.legalActReference}.`;
  } else if (input.found && input.cleanedValue.trim().length > 0 && input.confidence >= 0.55) {
    status = 'FOUND';
    ruleExplanation = `Compliant with ${rule.legalActReference}. Required statutory declaration identified and validated.`;
  } else if (input.found && input.confidence < 0.55) {
    status = 'REVIEW';
    trustNote = 'Confidence is below deterministic threshold. Officer visual confirmation suggested.';
    ruleExplanation = `Borderline extraction under ${rule.legalActReference}. Requires officer sign-off.`;
  } else {
    status = 'MISSING';
    ruleExplanation = `Statutory declaration is absent from the scanned surface. Non-compliant with ${rule.legalActReference}.`;
  }

  return {
    fieldKey: input.fieldKey,
    fieldName: rule.fieldName,
    rawValue: input.rawValue,
    cleanedValue: input.cleanedValue,
    status,
    confidence: input.confidence,
    boundingBox: input.boundingBox,
    evidenceSnippet: input.evidenceSnippet,
    ruleReference: rule.legalActReference,
    ruleExplanation,
    trustNote,
  };
}

export function computeOverallVerdict(fields: Record<MVPFieldKey, ExtractedField>): {
  verdict: OverallVerdict;
  complianceScore: number;
  summaryText: string;
} {
  const fieldList = Object.values(fields);
  const total = fieldList.length;
  const foundCount = fieldList.filter((f) => f.status === 'FOUND').length;
  const reviewCount = fieldList.filter((f) => f.status === 'REVIEW').length;
  const missingCount = fieldList.filter((f) => f.status === 'MISSING').length;

  // Score calculation: FOUND = 100%, REVIEW = 50%, MISSING = 0%
  const weightedSum = foundCount * 100 + reviewCount * 50;
  const complianceScore = Math.round(weightedSum / total);

  let verdict: OverallVerdict = 'COMPLIANT';
  let summaryText = '';

  if (missingCount > 0) {
    verdict = 'NON_COMPLIANT';
    summaryText = `${missingCount} mandatory declaration(s) missing under Legal Metrology Rules. Notice for compliance required.`;
  } else if (reviewCount > 0) {
    verdict = 'NEEDS_REVIEW';
    summaryText = `${reviewCount} declaration(s) marked for manual officer verification due to print legibility or smudge.`;
  } else {
    verdict = 'COMPLIANT';
    summaryText = 'All 7 mandatory statutory declarations successfully verified and compliant with PCR 2011.';
  }

  return {
    verdict,
    complianceScore,
    summaryText,
  };
}
