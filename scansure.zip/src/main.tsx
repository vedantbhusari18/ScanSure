import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register PWA Service Worker for offline capability & asset precaching in production
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  try {
    registerSW({
      immediate: true,
      onNeedRefresh() {
        console.log('PWA: New version available');
      },
      onOfflineReady() {
        console.log('PWA: App ready to work offline');
      },
      onRegisterError(error) {
        console.warn('PWA registration error:', error);
      },
    });
  } catch (err) {
    console.warn('PWA initialization skipped:', err);
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
