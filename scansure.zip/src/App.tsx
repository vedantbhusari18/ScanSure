import React, { useState, useEffect } from 'react';
import { ActiveScreen } from './components/Navbar';
import { AppSidebar } from './components/AppSidebar';
import { AppHeader } from './components/AppHeader';
import { AppStatusBar } from './components/AppStatusBar';
import { MobileDrawer } from './components/MobileDrawer';
import { MobileAppDock } from './components/MobileAppDock';
import { CommandPalette } from './components/CommandPalette';
import { DashboardView } from './components/DashboardView';
import { ScannerUploadView } from './components/ScannerUploadView';
import { AnalysisEvidenceView } from './components/AnalysisEvidenceView';
import { ComplianceReviewView } from './components/ComplianceReviewView';
import { ReportPdfView } from './components/ReportPdfView';
import { InspectionHistoryView } from './components/InspectionHistoryView';
import { InspectionRecord, ImageQualityMetrics, BatchStatus } from './types/inspection';
import {
  fetchAllInspections,
  saveInspectionRecord,
  deleteInspectionRecord,
  computeDashboardStats,
  seed300DemoInspectionsAction,
} from './services/storageService';
import { parseAndEvaluatePackage } from './services/declarationParser';
import { computeOverallVerdict } from './rules/ruleEngine';
import { analyzeImageQuality } from './services/imageQuality';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallBanner } from './components/PWAInstallBanner';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('DASHBOARD');
  const [inspections, setInspections] = useState<InspectionRecord[]>([]);
  const [currentInspection, setCurrentInspection] = useState<InspectionRecord | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' } | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('scansure_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('scansure_theme');
      if (saved) return saved === 'dark';
      return (
        typeof window !== 'undefined' &&
        window.matchMedia &&
        window.matchMedia('(prefers-color-scheme: dark)').matches
      );
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('scansure_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('scansure_theme', 'light');
      }
    } catch {
      // ignore
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev);

  const toggleSidebar = () => {
    setSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('scansure_sidebar_collapsed', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  // Global Keyboard Navigation (App shortcuts)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd+K or Ctrl+K opens Command Palette
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
        return;
      }

      // Do not trigger view hotkeys when typing in an input/textarea
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable)
      ) {
        return;
      }

      if (e.key === '1') setActiveScreen('DASHBOARD');
      else if (e.key === '2') setActiveScreen('SCANNER');
      else if (e.key === '3') setActiveScreen('ANALYSIS');
      else if (e.key === '4') setActiveScreen('REVIEW');
      else if (e.key === '5') setActiveScreen('REPORT');
      else if (e.key === '6') setActiveScreen('HISTORY');
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Load initial inspections on mount
  useEffect(() => {
    async function initData() {
      const list = await fetchAllInspections();
      setInspections(list);
      if (list.length > 0 && !currentInspection) {
        setCurrentInspection(list[0]);
      }
    }
    initData();
  }, []);

  const showNotification = (message: string, type: 'success' | 'info' = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3500);
  };

  const handleStartAnalysis = async (payload: {
    imageUrl: string;
    commodityName: string;
    brandName: string;
    batchNumber: string;
    batchStatus?: BatchStatus;
    category: string;
    quality: ImageQualityMetrics;
    presetId?: string;
    rawOcrText?: string;
    barcodeData?: any;
  }) => {
    const fields = parseAndEvaluatePackage({
      presetId: payload.presetId,
      rawOcrText: payload.rawOcrText,
      customProductInfo: {
        name: payload.commodityName,
        brand: payload.brandName,
        category: payload.category,
      },
      barcodeData: payload.barcodeData,
    });

    const overall = computeOverallVerdict(fields);

    const calculatedBatchStatus: BatchStatus =
      payload.batchStatus ||
      (overall.verdict === 'COMPLIANT'
        ? 'RELEASED'
        : overall.verdict === 'NEEDS_REVIEW'
        ? 'HOLD'
        : 'RECALLED');

    const newRecord: InspectionRecord = {
      id: `INS-SCAN-${Date.now().toString().slice(-4)}`,
      commodityName:
        payload.commodityName ||
        payload.barcodeData?.productName ||
        (payload.barcodeData?.gtin ? `GTIN-${payload.barcodeData.gtin}` : 'Scanned Commodity'),
      brandName: payload.brandName || payload.barcodeData?.brandName || 'Verified Brand',
      batchNumber:
        payload.batchNumber ||
        payload.barcodeData?.lotNumber ||
        payload.barcodeData?.batchNumber ||
        `LOT-${Date.now().toString().slice(-6)}`,
      batchStatus: calculatedBatchStatus,
      category: payload.category || payload.barcodeData?.category || 'Packaged Commodity',
      scannedAt: new Date().toISOString(),
      imageUrl: payload.imageUrl,
      imageQuality: payload.quality,
      fields,
      overallVerdict: overall.verdict,
      complianceScore: overall.complianceScore,
      officerRemarks: 'Initial automated scanner capture. Pending metrology verification.',
      barcodeData: payload.barcodeData,
      status: 'ANALYZED',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await saveInspectionRecord(newRecord);
    const updatedList = await fetchAllInspections();
    setInspections(updatedList);
    setCurrentInspection(newRecord);
    setActiveScreen('ANALYSIS');
    showNotification('Package image & barcode processed successfully!', 'success');
  };

  const handleSaveReview = async (updated: InspectionRecord) => {
    await saveInspectionRecord(updated);
    const updatedList = await fetchAllInspections();
    setInspections(updatedList);
    setCurrentInspection(updated);
    showNotification('Inspection review & manual sign-off saved.', 'success');
  };

  const handleDeleteInspection = async (id: string) => {
    await deleteInspectionRecord(id);
    const updatedList = await fetchAllInspections();
    setInspections(updatedList);
    if (currentInspection?.id === id) {
      setCurrentInspection(updatedList.length > 0 ? updatedList[0] : null);
    }
    showNotification('Inspection record archived.', 'info');
  };

  const handleSelectInspection = (record: InspectionRecord) => {
    setCurrentInspection(record);
    setActiveScreen('ANALYSIS');
  };

  const handleReload100Demo = async () => {
    try {
      const records = await seed300DemoInspectionsAction();
      setInspections(records);
      if (records.length > 0) {
        setCurrentInspection(records[0]);
      }
      showNotification('Successfully loaded 300 demo packages with complete compliance ledger and vision evidence!', 'success');
    } catch (err) {
      showNotification('Failed to load demo data', 'info');
    }
  };

  const stats = computeDashboardStats(inspections);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors selection:bg-emerald-500 selection:text-white">
      {/* Left Application Sidebar for Desktop Screens */}
      <AppSidebar
        activeScreen={activeScreen}
        onNavigate={(screen) => setActiveScreen(screen)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={toggleSidebar}
        currentInspection={currentInspection}
        inspectionsCount={inspections.length}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Application Header Bar */}
        <AppHeader
          activeScreen={activeScreen}
          onNavigate={(screen) => setActiveScreen(screen)}
          onOpenCommandPalette={() => setCommandPaletteOpen(true)}
          isDarkMode={isDarkMode}
          onToggleDarkMode={toggleDarkMode}
          currentInspectionId={currentInspection?.id}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
        />

        {/* Scrollable Application Workspace Canvas */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-5 pb-24 lg:pb-6">
          <div className="max-w-7xl mx-auto space-y-5">
            {/* PWA In-App Install Banner */}
            <PWAInstallBanner />

            {/* Screen Views */}
            {activeScreen === 'DASHBOARD' && (
              <DashboardView
                stats={stats}
                onSelectInspection={handleSelectInspection}
                onNewScan={() => setActiveScreen('SCANNER')}
                onReload100Demo={handleReload100Demo}
                onViewAllHistory={() => setActiveScreen('HISTORY')}
              />
            )}

            {activeScreen === 'SCANNER' && (
              <ScannerUploadView onStartAnalysis={handleStartAnalysis} />
            )}

            {activeScreen === 'ANALYSIS' && (
              currentInspection ? (
                <AnalysisEvidenceView
                  inspection={currentInspection}
                  onProceedToReview={() => setActiveScreen('REVIEW')}
                  onProceedToReport={() => setActiveScreen('REPORT')}
                  onRescan={() => setActiveScreen('SCANNER')}
                />
              ) : (
                <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-16 text-center shadow-2xs space-y-4">
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    No inspection selected in workspace.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveScreen('SCANNER')}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs transition cursor-pointer"
                  >
                    Start New Inspection Scan
                  </button>
                </div>
              )
            )}

            {activeScreen === 'REVIEW' && (
              currentInspection ? (
                <ComplianceReviewView
                  inspection={currentInspection}
                  onSaveReview={handleSaveReview}
                  onProceedToReport={() => setActiveScreen('REPORT')}
                  onRescan={() => setActiveScreen('SCANNER')}
                />
              ) : (
                <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-16 text-center shadow-2xs">
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    Please select an inspection to review compliance declarations.
                  </p>
                </div>
              )
            )}

            {activeScreen === 'REPORT' && (
              currentInspection ? (
                <ReportPdfView
                  inspection={currentInspection}
                  onBackToDashboard={() => setActiveScreen('DASHBOARD')}
                  onNewScan={() => setActiveScreen('SCANNER')}
                />
              ) : (
                <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-16 text-center shadow-2xs">
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    Please select an inspection to generate a statutory certificate.
                  </p>
                </div>
              )
            )}

            {activeScreen === 'HISTORY' && (
              <InspectionHistoryView
                inspections={inspections}
                onSelectInspection={handleSelectInspection}
                onDeleteInspection={handleDeleteInspection}
                onNewScan={() => setActiveScreen('SCANNER')}
                onReload100Demo={handleReload100Demo}
              />
            )}
          </div>
        </main>

        {/* Application Status Bar (Desktop) */}
        <AppStatusBar recordsCount={inspections.length} />
      </div>

      {/* Mobile Slide-over Drawer */}
      <MobileDrawer
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        activeScreen={activeScreen}
        onNavigate={(screen) => setActiveScreen(screen)}
        currentInspection={currentInspection}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      {/* Mobile App Bottom Dock (Shifted to downside of app) */}
      <MobileAppDock
        activeScreen={activeScreen}
        onNavigate={(screen) => setActiveScreen(screen)}
        inspectionsCount={inspections.length}
      />

      {/* Global Command Palette (Cmd+K / Ctrl+K) */}
      <CommandPalette
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        onNavigate={(screen) => setActiveScreen(screen)}
        inspections={inspections}
        onSelectInspection={handleSelectInspection}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-20 lg:bottom-10 right-4 sm:right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-semibold shadow-xl border border-slate-700/50 animate-in slide-in-from-bottom-2">
          <span
            className={`w-2 h-2 rounded-full ${
              notification.type === 'success' ? 'bg-emerald-400' : 'bg-amber-400'
            }`}
          />
          <span>{notification.message}</span>
        </div>
      )}

      {/* Offline Status Toast */}
      <OfflineIndicator />
    </div>
  );
}
