export type FieldStatus = 'FOUND' | 'REVIEW' | 'MISSING';

export type OverallVerdict = 'COMPLIANT' | 'NON_COMPLIANT' | 'NEEDS_REVIEW';

export interface BoundingBox {
  x: number;      // percentage 0 - 100
  y: number;      // percentage 0 - 100
  width: number;  // percentage 0 - 100
  height: number; // percentage 0 - 100
}

export interface RuleDefinition {
  id: string;
  fieldKey: MVPFieldKey;
  fieldName: string;
  legalActReference: string; // e.g., "PCR 2011 Rule 6(1)(e)"
  description: string;
  required: boolean;
  validationRegex?: string;
  unitRequirement?: string;
  guidanceText: string;
}

export type MVPFieldKey =
  | 'mrp'
  | 'netQuantity'
  | 'manufacturer'
  | 'genericName'
  | 'dateInfo'
  | 'consumerCare'
  | 'unitSalePrice';

export interface ExtractedField {
  fieldKey: MVPFieldKey;
  fieldName: string;
  rawValue: string;
  cleanedValue: string;
  status: FieldStatus;
  confidence: number; // 0 to 1
  boundingBox?: BoundingBox;
  evidenceSnippet: string;
  ruleReference: string;
  ruleExplanation: string;
  trustNote?: string; // e.g. "Text unclear / degraded print -> Set to Unable to verify (Review), not Violation"
  officerOverride?: {
    status: FieldStatus;
    correctedValue?: string;
    notes?: string;
    reviewedBy?: string;
    reviewedAt?: string;
  };
}

export interface ImageQualityMetrics {
  score: number; // 0 to 100
  blurScore: 'SHARP' | 'MODERATE_BLUR' | 'SEVERE_BLUR';
  lightingQuality: 'GOOD' | 'GLARE_DETECTED' | 'UNDEREXPOSED';
  resolutionScore: 'PASS' | 'MARGINAL' | 'FAIL';
  framingScore: 'CENTERED' | 'ANGLED' | 'CROPPED';
  isReadable: boolean;
  warnings: string[];
}

export type BatchStatus = 'RELEASED' | 'HOLD' | 'INSPECTION' | 'RECALLED';

export interface InspectionRecord {
  id: string;
  commodityName: string;
  brandName: string;
  batchNumber?: string;
  batchStatus?: BatchStatus;
  category: string;
  scannedAt: string;
  imageUrl: string;
  imageQuality: ImageQualityMetrics;
  fields: Record<MVPFieldKey, ExtractedField>;
  overallVerdict: OverallVerdict;
  complianceScore: number; // 0 to 100
  officerRemarks?: string;
  officerName?: string;
  officerDesignation?: string;
  location?: string;
  barcodeData?: {
    rawValue: string;
    format: string;
    type?: string;
    title?: string;
    gtin?: string;
    batchNumber?: string;
    lotNumber?: string;
    price?: string;
    mrp?: string;
    dmartPrice?: string;
    netQuantity?: string;
    unitSalePrice?: string;
    countryOfOrigin?: string;
    manufacturerName?: string;
    productName?: string;
    brandName?: string;
    category?: string;
    expiryDate?: string;
    url?: string;
    isRealDatabaseLookup?: boolean;
  };
  status: 'ANALYZED' | 'REVIEWED' | 'REPORT_ISSUED';
  createdAt: string;
  updatedAt: string;
}

export interface DashboardStats {
  totalScanned: number;
  compliantCount: number;
  reviewRequiredCount: number;
  violationCount: number;
  complianceRate: number;
  averageConfidence: number;
  recentInspections: InspectionRecord[];
  batchStatusCounts?: {
    released: number;
    hold: number;
    inspection: number;
    recalled: number;
  };
}
