import React from 'react';
import {
  LayoutDashboard,
  Camera,
  Search,
  FileCheck2,
  FileSpreadsheet,
  History,
} from 'lucide-react';
import { ActiveScreen } from './Navbar';

interface MobileAppDockProps {
  activeScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
  inspectionsCount?: number;
}

export const MobileAppDock: React.FC<MobileAppDockProps> = ({
  activeScreen,
  onNavigate,
  inspectionsCount,
}) => {
  const items = [
    {
      id: 'DASHBOARD' as ActiveScreen,
      label: 'Overview',
      icon: LayoutDashboard,
      number: '1',
    },
    {
      id: 'SCANNER' as ActiveScreen,
      label: 'Scanner',
      icon: Camera,
      number: '2',
      isLive: true,
    },
    {
      id: 'ANALYSIS' as ActiveScreen,
      label: 'Evidence',
      icon: Search,
      number: '3',
    },
    {
      id: 'REVIEW' as ActiveScreen,
      label: 'Review',
      icon: FileCheck2,
      number: '4',
    },
    {
      id: 'REPORT' as ActiveScreen,
      label: 'Certificates',
      icon: FileSpreadsheet,
      number: '5',
    },
    {
      id: 'HISTORY' as ActiveScreen,
      label: 'History',
      icon: History,
      number: '6',
      badge: inspectionsCount,
    },
  ];

  return (
    <nav
      aria-label="Mobile Workspace Navigation"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 pb-safe shadow-lg transition-colors"
    >
      <div className="grid grid-cols-6 items-center h-15 px-1 max-w-lg mx-auto">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activeScreen === item.id;
          const isScanner = item.id === 'SCANNER';

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-0.5 transition-all cursor-pointer rounded-lg group ${
                isActive
                  ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
              title={item.label}
              aria-label={item.label}
            >
              {/* Active top indicator dot */}
              {isActive && (
                <span className="absolute -top-1 w-5 h-0.5 rounded-full bg-emerald-500 shadow-xs" />
              )}

              {/* Icon Container */}
              <div
                className={`relative p-1 rounded-md transition-transform active:scale-90 ${
                  isActive
                    ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400'
                    : isScanner
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-slate-600 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white'
                }`}
              >
                <Icon className="w-4.5 h-4.5" />
                {item.isLive && !isActive && (
                  <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-500" />
                )}
              </div>

              {/* Label */}
              <span className="text-[10px] leading-tight mt-0.5 truncate max-w-full font-medium">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
