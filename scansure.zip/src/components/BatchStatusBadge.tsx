import React from 'react';
import { BatchStatus } from '../types/inspection';
import { CheckCircle2, AlertTriangle, Clock, Ban } from 'lucide-react';

interface BatchStatusBadgeProps {
  status?: BatchStatus;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const BatchStatusBadge: React.FC<BatchStatusBadgeProps> = ({
  status = 'RELEASED',
  size = 'md',
  showIcon = true,
}) => {
  const config = {
    RELEASED: {
      label: 'Batch Released',
      shortLabel: 'RELEASED',
      icon: CheckCircle2,
      style:
        'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30',
      dot: 'bg-emerald-500',
    },
    HOLD: {
      label: 'Quality Hold',
      shortLabel: 'ON HOLD',
      icon: AlertTriangle,
      style:
        'bg-amber-500/10 text-amber-800 dark:text-amber-400 border-amber-500/30',
      dot: 'bg-amber-500',
    },
    INSPECTION: {
      label: 'In Inspection',
      shortLabel: 'INSPECTION',
      icon: Clock,
      style:
        'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/30',
      dot: 'bg-blue-500',
    },
    RECALLED: {
      label: 'Quarantined',
      shortLabel: 'RECALLED',
      icon: Ban,
      style:
        'bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-500/30',
      dot: 'bg-rose-500',
    },
  }[status] || {
    label: 'Released',
    shortLabel: 'RELEASED',
    icon: CheckCircle2,
    style: 'bg-slate-500/10 text-slate-700 dark:text-slate-300 border-slate-500/30',
    dot: 'bg-slate-400',
  };

  const Icon = config.icon;

  const sizeClasses = {
    sm: 'text-[10px] px-1.5 py-0.5 gap-1',
    md: 'text-xs px-2 py-0.5 gap-1.5',
    lg: 'text-xs px-3 py-1 gap-1.5 font-bold',
  }[size];

  const iconSizes = {
    sm: 'w-2.5 h-2.5',
    md: 'w-3 h-3',
    lg: 'w-3.5 h-3.5',
  }[size];

  return (
    <span
      className={`inline-flex items-center font-mono font-semibold rounded-md border tracking-wide uppercase transition-colors ${config.style} ${sizeClasses}`}
      title={`Batch Quality Status: ${config.label}`}
    >
      {showIcon && <Icon className={`${iconSizes} shrink-0`} />}
      <span>{size === 'sm' ? config.shortLabel : config.label}</span>
    </span>
  );
};
