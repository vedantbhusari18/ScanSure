import React from 'react';

interface ScanSureLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

export const ScanSureLogo: React.FC<ScanSureLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const iconSize = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  }[size];

  const textSize = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
  }[size];

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Precision Geometric Scanner Glyph */}
      <div
        className={`${iconSize} relative rounded-xl bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 p-[1.5px] shadow-sm flex items-center justify-center shrink-0 group`}
      >
        <div className="w-full h-full rounded-[10px] bg-slate-950 flex items-center justify-center relative overflow-hidden">
          {/* Subtle scanning beam sweep effect */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-emerald-500/20 to-transparent opacity-60" />

          {/* Precision SVG Vector Mark */}
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5 text-emerald-400 relative z-10"
          >
            {/* 4 Corner Viewfinder Aperture Reticles */}
            <path d="M3 7V5a2 2 0 0 1 2-2h2" />
            <path d="M17 3h2a2 2 0 0 1 2 2v2" />
            <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
            <path d="M7 21H5a2 2 0 0 1-2-2v-2" />

            {/* Central Assurance / Certainty Check Laser Beam */}
            <path
              d="M7.5 12.5l3 3 6-6"
              className="stroke-amber-400"
              strokeWidth="2.4"
            />
          </svg>
        </div>
      </div>

      {/* Clean App Name "ScanSure" — No excess titles or subtitles */}
      {showText && (
        <div className="flex items-center tracking-tight font-extrabold font-sans leading-none">
          <span className={`${textSize} text-slate-900 dark:text-white transition-colors`}>
            Scan
          </span>
          <span className={`${textSize} text-emerald-600 dark:text-emerald-400 transition-colors`}>
            Sure
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 ml-0.5 mt-1 animate-pulse" />
        </div>
      )}
    </div>
  );
};
