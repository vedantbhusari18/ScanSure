import React, { useState } from 'react';
import { InspectionRecord, MVPFieldKey } from '../types/inspection';
import { StatusBadge } from './StatusBadge';
import { BatchStatusBadge } from './BatchStatusBadge';
import { generateCompliancePdf } from '../services/pdfGenerator';
import {
  Download,
  Printer,
  ShieldCheck,
  ShieldAlert,
  ArrowLeft,
  Copy,
  Check,
  AlertTriangle,
  Scan,
} from 'lucide-react';

interface ReportPdfViewProps {
  inspection: InspectionRecord;
  onBackToDashboard: () => void;
  onNewScan: () => void;
}

export const ReportPdfView: React.FC<ReportPdfViewProps> = ({
  inspection,
  onBackToDashboard,
  onNewScan,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [downloading, setDownloading] = useState<boolean>(false);

  const fieldKeys: MVPFieldKey[] = [
    'mrp',
    'netQuantity',
    'manufacturer',
    'genericName',
    'dateInfo',
    'consumerCare',
    'unitSalePrice',
  ];

  const handleDownloadPdf = () => {
    setDownloading(true);
    try {
      const doc = generateCompliancePdf(inspection);
      doc.save(`ScanSure-Report-${inspection.id}.pdf`);
    } catch (err) {
      console.error('PDF generation error:', err);
      alert('Failed to generate PDF. You can also use the Print button.');
    } finally {
      setDownloading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopySummary = () => {
    const summary = `ScanSure Inspection Report (${inspection.id})
Commodity: ${inspection.commodityName} | Brand: ${inspection.brandName}
Batch Status: ${inspection.batchStatus || 'RELEASED'}
Verdict: ${inspection.overallVerdict} (Score: ${inspection.complianceScore}%)
MRP: ${inspection.fields.mrp.status} (${inspection.fields.mrp.cleanedValue || 'Omitted'})
Net Qty: ${inspection.fields.netQuantity.status} (${inspection.fields.netQuantity.cleanedValue || 'Omitted'})
Manufacturer: ${inspection.fields.manufacturer.status}
Date: ${inspection.fields.dateInfo.status} (${inspection.fields.dateInfo.cleanedValue || 'Omitted'})
Consumer Care: ${inspection.fields.consumerCare.status}
Unit Sale Price: ${inspection.fields.unitSalePrice.status}
Officer Remarks: ${inspection.officerRemarks || 'None'}
Designed & Developed by Team HexaByte`;

    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      {/* Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs">
        <button
          type="button"
          onClick={onBackToDashboard}
          className="inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-semibold transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopySummary}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Summary'}</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>

          <button
            type="button"
            id="download-pdf-btn"
            onClick={handleDownloadPdf}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{downloading ? 'Exporting...' : 'Download PDF Report'}</span>
          </button>
        </div>
      </div>

      {/* Formal Printable Document Certificate Card */}
      <div id="printable-report" className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-xl shadow-xs p-8 sm:p-10 border border-slate-200 dark:border-slate-800">
        {/* Document Header */}
        <div className="border-b-2 border-slate-900 dark:border-slate-700 pb-5">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-black text-lg shadow-xs">
                <Scan className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  ScanSure
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  Inspection Report • {inspection.id}
                </p>
              </div>
            </div>

            <div className="text-right font-mono text-xs text-slate-600 dark:text-slate-400">
              <div className="font-bold text-slate-900 dark:text-white text-sm">{inspection.id}</div>
              <div>{new Date(inspection.scannedAt).toLocaleDateString()}</div>
              <div className="mt-1">
                <BatchStatusBadge status={inspection.batchStatus || 'RELEASED'} size="sm" />
              </div>
            </div>
          </div>
        </div>

        {/* Commodity Identification Section */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 py-4 border-b border-slate-200 dark:border-slate-800 text-xs">
          <div>
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">Commodity</span>
            <span className="font-bold text-slate-900 dark:text-white text-sm">{inspection.commodityName}</span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">Brand</span>
            <span className="font-bold text-slate-800 dark:text-slate-200">{inspection.brandName}</span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">Batch ID</span>
            <span className="font-mono text-slate-800 dark:text-slate-200">{inspection.batchNumber}</span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">Batch Status</span>
            <div className="mt-0.5">
              <BatchStatusBadge status={inspection.batchStatus || 'RELEASED'} size="sm" />
            </div>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">Category</span>
            <span className="text-slate-800 dark:text-slate-200">{inspection.category}</span>
          </div>
        </div>

        {/* Real Supermarket & GS1 Barcode Verification Panel */}
        {inspection.barcodeData && (
          <div className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700 mb-3">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-mono text-[10px] font-bold">
                  {inspection.barcodeData.format || 'EAN-13'}
                </span>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Barcode Decoded Information
                </span>
              </div>
              <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700">
                VERIFIED
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-2 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">Barcode / GTIN</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{inspection.barcodeData.rawValue}</span>
              </div>
              <div className="p-2 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">Max Retail Price (MRP)</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{inspection.barcodeData.mrp || inspection.barcodeData.price || 'Statutory Stamped'}</span>
              </div>
              {inspection.barcodeData.dmartPrice && (
                <div className="p-2 bg-emerald-50 dark:bg-emerald-950/40 rounded border border-emerald-200 dark:border-emerald-800">
                  <span className="text-[10px] uppercase font-bold text-emerald-800 dark:text-emerald-300 block">D-Mart Price</span>
                  <span className="font-mono font-bold text-emerald-950 dark:text-emerald-200">{inspection.barcodeData.dmartPrice}</span>
                </div>
              )}
              <div className="p-2 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">Net Quantity</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{inspection.barcodeData.netQuantity || 'Standard Pack'}</span>
              </div>
              {inspection.barcodeData.lotNumber && (
                <div className="p-2 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">Lot / Batch Number</span>
                  <span className="font-mono font-bold text-cyan-900 dark:text-cyan-300">{inspection.barcodeData.lotNumber}</span>
                </div>
              )}
              {inspection.barcodeData.unitSalePrice && (
                <div className="p-2 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">Unit Sale Price</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">{inspection.barcodeData.unitSalePrice}</span>
                </div>
              )}
              {inspection.barcodeData.manufacturerName && (
                <div className="col-span-2 p-2 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">Manufacturer / Packer</span>
                  <span className="font-semibold text-slate-900 dark:text-white truncate block">{inspection.barcodeData.manufacturerName}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Verdict Banner */}
        <div className="my-6 p-4 rounded-xl border bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3">
            {inspection.overallVerdict === 'COMPLIANT' ? (
              <ShieldCheck className="w-8 h-8 text-emerald-600 shrink-0" />
            ) : inspection.overallVerdict === 'NEEDS_REVIEW' ? (
              <AlertTriangle className="w-8 h-8 text-amber-600 shrink-0" />
            ) : (
              <ShieldAlert className="w-8 h-8 text-rose-600 shrink-0" />
            )}
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Audit Verdict
              </div>
              <div className="text-lg font-black text-slate-900 dark:text-white">
                {inspection.overallVerdict === 'COMPLIANT'
                  ? 'COMPLIANT'
                  : inspection.overallVerdict === 'NEEDS_REVIEW'
                  ? 'NEEDS REVIEW'
                  : 'NON-COMPLIANT'}
              </div>
            </div>
          </div>

          <div className="text-right sm:border-l sm:border-slate-300 dark:sm:border-slate-700 sm:pl-6">
            <div className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400">Compliance Score</div>
            <div className="text-2xl font-black font-mono text-slate-900 dark:text-white">{inspection.complianceScore}%</div>
          </div>
        </div>

        {/* 7 Statutory Declarations Evidence Table */}
        <div className="mb-6">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
            Declarations Review Table
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs border border-slate-200 dark:border-slate-700">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                  <th className="py-2.5 px-3">Field</th>
                  <th className="py-2.5 px-3">Rule</th>
                  <th className="py-2.5 px-3">Extracted Value</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 text-right">Confidence</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700 font-sans">
                {fieldKeys.map((key) => {
                  const field = inspection.fields[key];
                  return (
                    <tr key={key} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">{field.fieldName}</td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400">{field.ruleReference}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-800 dark:text-slate-200">
                        {field.cleanedValue || field.rawValue || (
                          <span className="text-rose-600 dark:text-rose-400 italic">Not Declared on Pack</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <StatusBadge status={field.status} size="sm" />
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-600 dark:text-slate-400 font-medium">
                        {Math.round(field.confidence * 100)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Officer Remarks & Sign-off */}
        <div className="border-t border-slate-200 dark:border-slate-800 pt-5 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div>
              <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold mb-1">
                Officer Remarks
              </span>
              <p className="text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 p-3 rounded border border-slate-200 dark:border-slate-700 italic leading-relaxed">
                "{inspection.officerRemarks || 'Inspection completed successfully.'}"
              </p>
            </div>

            <div className="flex flex-col justify-end items-end space-y-1 text-right">
              <div className="w-48 border-b border-slate-400 dark:border-slate-600 pb-1 mb-1 font-mono text-xs text-slate-600 dark:text-slate-400 text-center">
                [Verified &amp; Certified]
              </div>
              <div className="font-bold text-slate-900 dark:text-white text-sm">{inspection.officerName || 'Inspector Rajesh Varma'}</div>
              <div className="text-slate-600 dark:text-slate-400">{inspection.officerDesignation || 'Legal Metrology Inspector'}</div>
              <div className="text-slate-500 dark:text-slate-400 text-[11px] font-mono">{inspection.location}</div>
            </div>
          </div>
        </div>

        {/* Attribution Footer */}
        <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-600 dark:text-slate-400 gap-2">
          <span className="font-bold text-slate-900 dark:text-slate-100">Designed &amp; Developed by Team HexaByte</span>
          <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
            ScanSure Inspection System
          </span>
        </div>
      </div>
    </div>
  );
};
