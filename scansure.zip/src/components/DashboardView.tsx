import React from 'react';
import { DashboardStats, InspectionRecord } from '../types/inspection';
import { StatusBadge } from './StatusBadge';
import { BatchStatusBadge } from './BatchStatusBadge';
import {
  ShieldCheck,
  AlertTriangle,
  XCircle,
  ScanLine,
  TrendingUp,
  Clock,
  ArrowRight,
  FileText,
  Layers,
} from 'lucide-react';

interface DashboardViewProps {
  stats: DashboardStats;
  onSelectInspection: (record: InspectionRecord) => void;
  onNewScan: () => void;
  onReload100Demo?: () => void;
  onViewAllHistory?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  onSelectInspection,
  onNewScan,
  onReload100Demo,
  onViewAllHistory,
}) => {
  // Compute batch status counts across entire inspections database
  const releasedBatches = stats.batchStatusCounts?.released ?? stats.recentInspections.filter(
    (i) => i.batchStatus === 'RELEASED'
  ).length;
  const holdBatches = stats.batchStatusCounts?.hold ?? stats.recentInspections.filter(
    (i) => i.batchStatus === 'HOLD'
  ).length;
  const inspectionBatches = stats.batchStatusCounts?.inspection ?? stats.recentInspections.filter(
    (i) => i.batchStatus === 'INSPECTION'
  ).length;
  const recalledBatches = stats.batchStatusCounts?.recalled ?? stats.recentInspections.filter(
    (i) => i.batchStatus === 'RECALLED'
  ).length;

  return (
    <div className="space-y-5">
      {/* Web-App Quick KPI Toolbar / Status Ribbon */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-800 dark:text-slate-200">
          <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>Batch Status Ledger</span>
        </div>

        {/* Clean unboxed metadata with typographic separators & tabular figures */}
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-300 font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="text-slate-500 dark:text-slate-400 font-sans">Released:</span>
            <span className="font-bold tabular-nums text-slate-900 dark:text-white">
              {releasedBatches}
            </span>
          </div>

          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span className="text-slate-500 dark:text-slate-400 font-sans">Hold:</span>
            <span className="font-bold tabular-nums text-slate-900 dark:text-white">
              {holdBatches}
            </span>
          </div>

          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            <span className="text-slate-500 dark:text-slate-400 font-sans">Inspecting:</span>
            <span className="font-bold tabular-nums text-slate-900 dark:text-white">
              {inspectionBatches}
            </span>
          </div>

          {recalledBatches > 0 && (
            <>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <span className="text-slate-500 dark:text-slate-400 font-sans">Recalled:</span>
                <span className="font-bold tabular-nums text-rose-600 dark:text-rose-400">
                  {recalledBatches}
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Metric 1: Total Scans */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 shadow-2xs transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Total Packages
            </span>
            <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
              <ScanLine className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
              {stats.totalScanned}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">scans</span>
          </div>
          <div className="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
            <span>Avg OCR Confidence: <strong className="font-mono">{stats.averageConfidence}%</strong></span>
          </div>
        </div>

        {/* Metric 2: Compliant */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 shadow-2xs transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
              Compliant
            </span>
            <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
              {stats.compliantCount}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">certified</span>
          </div>
          <div className="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            Pass Rate:{' '}
            <strong className="text-emerald-600 dark:text-emerald-400 font-mono">
              {stats.complianceRate}%
            </strong>
          </div>
        </div>

        {/* Metric 3: Under Review */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 shadow-2xs transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-700 dark:text-amber-400">
              Review Queue
            </span>
            <div className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400">
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-amber-600 dark:text-amber-400 font-mono tabular-nums">
              {stats.reviewRequiredCount}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">flagged</span>
          </div>
          <div className="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            Awaiting manual sign-off
          </div>
        </div>

        {/* Metric 4: Violations */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 shadow-2xs transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-700 dark:text-rose-400">
              Violations
            </span>
            <div className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400">
              <XCircle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-rose-600 dark:text-rose-400 font-mono tabular-nums">
              {stats.violationCount}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">omissions</span>
          </div>
          <div className="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            PCR 2011 notice recommended
          </div>
        </div>
      </div>

      {/* Recent Inspections Table with Web-App Toolbar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs transition-colors">
        <div className="px-4 py-3 border-b border-slate-200/80 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            <h2 className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Recent Inspection Ledger
            </h2>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 font-mono">
            <span>{stats.recentInspections.length} recorded</span>
            <button
              type="button"
              onClick={onNewScan}
              className="text-emerald-600 dark:text-emerald-400 hover:underline font-semibold font-sans cursor-pointer text-xs"
            >
              + New Scan
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/80 dark:border-slate-800">
                <th className="py-2.5 px-4 font-mono text-[11px]">ID</th>
                <th className="py-2.5 px-4">Commodity / Brand</th>
                <th className="py-2.5 px-4 font-mono text-[11px]">Batch No.</th>
                <th className="py-2.5 px-4">Batch Status</th>
                <th className="py-2.5 px-4">Verdict</th>
                <th className="py-2.5 px-4">Score</th>
                <th className="py-2.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {stats.recentInspections.map((rec) => (
                <tr
                  key={rec.id}
                  className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition cursor-pointer"
                  onClick={() => onSelectInspection(rec)}
                >
                  <td className="py-2.5 px-4 font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                    {rec.id}
                  </td>
                  <td className="py-2.5 px-4">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      {rec.commodityName}
                    </div>
                    <div className="text-[11px] text-slate-400">{rec.brandName}</div>
                  </td>
                  <td className="py-2.5 px-4 font-mono font-medium text-slate-600 dark:text-slate-300">
                    {rec.batchNumber}
                  </td>
                  <td className="py-2.5 px-4">
                    <BatchStatusBadge status={rec.batchStatus} />
                  </td>
                  <td className="py-2.5 px-4">
                    <StatusBadge status={rec.overallVerdict} />
                  </td>
                  <td className="py-2.5 px-4 font-mono font-semibold tabular-nums">
                    {rec.complianceScore}%
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <button
                      type="button"
                      className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 font-semibold cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectInspection(rec);
                      }}
                    >
                      <span>Open</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {onViewAllHistory && stats.totalScanned > 0 && (
          <div className="px-4 py-2.5 border-t border-slate-200/80 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-800/30 flex items-center justify-between text-xs">
            <span className="text-slate-500 dark:text-slate-400">
              Showing recent scans of <strong className="font-mono text-slate-800 dark:text-slate-200">{stats.totalScanned} Total Packages</strong>
            </span>
            <button
              type="button"
              onClick={onViewAllHistory}
              className="inline-flex items-center gap-1.5 font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 cursor-pointer"
            >
              <span>View All {stats.totalScanned} in History</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
