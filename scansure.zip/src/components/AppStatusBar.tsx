import React from 'react';
import { Database, ShieldCheck, Cpu, Terminal } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface AppStatusBarProps {
  recordsCount: number;
}

export const AppStatusBar: React.FC<AppStatusBarProps> = ({ recordsCount }) => {
  const isOnline = useOnlineStatus();

  return (
    <footer className="hidden md:flex h-8 bg-white dark:bg-slate-900 border-t border-slate-200/80 dark:border-slate-800 px-4 items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono select-none z-20 shrink-0">
      {/* Left: Terminal status */}
      <div className="flex items-center gap-2">
        <span
          className={`w-2 h-2 rounded-full ${
            isOnline ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'
          }`}
        />
        <span className="font-semibold text-slate-700 dark:text-slate-300">
          Terminal #04
        </span>
        <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
        <span>Legal Metrology PCR 2011</span>
      </div>

      {/* Center: Keyboard Shortcuts Hint */}
      <div className="hidden lg:flex items-center gap-3 text-slate-400">
        <span>
          <kbd className="px-1 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            ⌘K
          </kbd>{' '}
          Command
        </span>
        <span>
          <kbd className="px-1 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            1-6
          </kbd>{' '}
          Switch View
        </span>
      </div>

      {/* Right: DB and Record Sync */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5">
          <Database className="w-3 h-3 text-emerald-500" />
          <span>Local Storage · {recordsCount} Records</span>
        </div>
        <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
        <span className="text-[10px] text-slate-400">
          ScanSure v2.4
        </span>
      </div>
    </footer>
  );
};
