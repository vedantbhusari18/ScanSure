import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  LayoutDashboard,
  Camera,
  FileCheck2,
  FileSpreadsheet,
  History,
  Sun,
  Moon,
  Maximize2,
  Minimize2,
  Download,
  X,
  Package,
  Sparkles,
  ArrowRight,
  Command,
} from 'lucide-react';
import { ActiveScreen } from './Navbar';
import { InspectionRecord } from '../types/inspection';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (screen: ActiveScreen) => void;
  inspections: InspectionRecord[];
  onSelectInspection: (record: InspectionRecord) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onInstallApp?: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  inspections,
  onSelectInspection,
  isDarkMode,
  onToggleDarkMode,
  onInstallApp,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  // Build items based on query
  const navigationItems = [
    { id: 'nav-dash', label: 'Go to Dashboard', screen: 'DASHBOARD' as ActiveScreen, icon: LayoutDashboard, category: 'Navigation', shortcut: '1' },
    { id: 'nav-scan', label: 'Start Camera / Barcode Scanner', screen: 'SCANNER' as ActiveScreen, icon: Camera, category: 'Navigation', shortcut: '2' },
    { id: 'nav-evid', label: 'View OCR Evidence & Coordinates', screen: 'ANALYSIS' as ActiveScreen, icon: Search, category: 'Navigation', shortcut: '3' },
    { id: 'nav-rev', label: 'Compliance Review & PCR 2011 Checklist', screen: 'REVIEW' as ActiveScreen, icon: FileCheck2, category: 'Navigation', shortcut: '4' },
    { id: 'nav-rep', label: 'Statutory Inspection Certificate (PDF)', screen: 'REPORT' as ActiveScreen, icon: FileSpreadsheet, category: 'Navigation', shortcut: '5' },
    { id: 'nav-hist', label: 'Audit Trail & Inspection Logs', screen: 'HISTORY' as ActiveScreen, icon: History, category: 'Navigation', shortcut: '6' },
  ];

  const actionItems = [
    {
      id: 'act-theme',
      label: isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode',
      icon: isDarkMode ? Sun : Moon,
      category: 'Actions',
      action: () => {
        onToggleDarkMode();
        onClose();
      },
    },
    {
      id: 'act-full',
      label: 'Toggle Fullscreen Mode',
      icon: Maximize2,
      category: 'Actions',
      action: () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
        onClose();
      },
    },
  ];

  const filteredNav = navigationItems.filter((i) =>
    i.label.toLowerCase().includes(query.toLowerCase())
  );

  const filteredInspections = query.trim()
    ? inspections.filter(
        (rec) =>
          rec.commodityName.toLowerCase().includes(query.toLowerCase()) ||
          rec.brandName.toLowerCase().includes(query.toLowerCase()) ||
          rec.batchNumber.toLowerCase().includes(query.toLowerCase()) ||
          rec.id.toLowerCase().includes(query.toLowerCase()) ||
          rec.category.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 6)
    : inspections.slice(0, 3);

  const totalItems = [
    ...filteredNav.map((item) => ({ type: 'nav', ...item })),
    ...actionItems
      .filter((i) => i.label.toLowerCase().includes(query.toLowerCase()))
      .map((item) => ({ type: 'action', ...item })),
    ...filteredInspections.map((rec) => ({ type: 'record', record: rec })),
  ];

  // Handle keyboard arrow keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % (totalItems.length || 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + totalItems.length) % (totalItems.length || 1));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const selected = totalItems[selectedIndex];
        if (!selected) return;

        if (selected.type === 'nav' && 'screen' in selected) {
          onNavigate(selected.screen as ActiveScreen);
          onClose();
        } else if (selected.type === 'action' && 'action' in selected) {
          selected.action();
        } else if (selected.type === 'record' && 'record' in selected) {
          onSelectInspection(selected.record);
          onNavigate('ANALYSIS');
          onClose();
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, totalItems, selectedIndex, onNavigate, onClose, onSelectInspection]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Type a view, action, batch ID, or commodity..."
            className="flex-1 bg-transparent text-sm font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
          />
          <kbd className="hidden sm:inline-flex items-center px-2 py-0.5 text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-200/60 dark:bg-slate-800 rounded border border-slate-300/50 dark:border-slate-700">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-3">
          {/* Views & Actions */}
          {filteredNav.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Workspaces
              </div>
              <div className="space-y-0.5">
                {filteredNav.map((item, idx) => {
                  const Icon = item.icon;
                  const isSelected = selectedIndex === idx;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onNavigate(item.screen);
                        onClose();
                      }}
                      onMouseEnter={() => setSelectedIndex(idx)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-left transition cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-600 text-white dark:bg-emerald-600'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                        <span>{item.label}</span>
                      </div>
                      <kbd className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}>
                        {item.shortcut}
                      </kbd>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quick Actions */}
          {actionItems.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                App Actions
              </div>
              <div className="space-y-0.5">
                {actionItems.map((item, idx) => {
                  const itemIndex = filteredNav.length + idx;
                  const Icon = item.icon;
                  const isSelected = selectedIndex === itemIndex;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={item.action}
                      onMouseEnter={() => setSelectedIndex(itemIndex)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-left transition cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-600 text-white'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                        <span>{item.label}</span>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 opacity-60" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Inspection Records */}
          {filteredInspections.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                {query.trim() ? 'Matched Inspections' : 'Recent Inspections'}
              </div>
              <div className="space-y-0.5">
                {filteredInspections.map((rec, idx) => {
                  const itemIndex = filteredNav.length + actionItems.length + idx;
                  const isSelected = selectedIndex === itemIndex;
                  return (
                    <button
                      key={rec.id}
                      type="button"
                      onClick={() => {
                        onSelectInspection(rec);
                        onNavigate('ANALYSIS');
                        onClose();
                      }}
                      onMouseEnter={() => setSelectedIndex(itemIndex)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs text-left transition cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-600 text-white'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Package className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-emerald-500'}`} />
                        <div className="truncate">
                          <span className="font-semibold">{rec.commodityName}</span>
                          <span className={`ml-2 text-[11px] ${isSelected ? 'text-emerald-100' : 'text-slate-400'}`}>
                            {rec.batchNumber}
                          </span>
                        </div>
                      </div>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded shrink-0 ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}>
                        {rec.overallVerdict}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {totalItems.length === 0 && (
            <div className="py-8 text-center text-xs text-slate-400">
              No matching commands or inspections found.
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="px-4 py-2.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>ESC Close</span>
          </div>
          <span>ScanSure Web-App Terminal</span>
        </div>
      </div>
    </div>
  );
};
