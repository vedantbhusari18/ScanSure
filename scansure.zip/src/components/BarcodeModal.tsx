import React from 'react';
import { DecodedBarcode } from '../services/barcodeScanner';
import {
  QrCode,
  Barcode,
  ExternalLink,
  Copy,
  Check,
  Globe,
  Tag,
  Calendar,
  Layers,
  ArrowRight,
  X,
  ShieldCheck,
  CheckCircle2,
  FileText,
  Sparkles,
  Zap,
  ShoppingBag,
  IndianRupee,
  PackageCheck,
  Building2,
} from 'lucide-react';

interface BarcodeModalProps {
  barcode: DecodedBarcode | null;
  onClose: () => void;
  onApplyToInspection?: (barcode: DecodedBarcode) => void;
  onCaptureWithBarcode?: (barcode: DecodedBarcode) => void;
  onInstantGenerateReport?: (barcode: DecodedBarcode) => void;
}

export const BarcodeModal: React.FC<BarcodeModalProps> = ({
  barcode,
  onClose,
  onApplyToInspection,
  onCaptureWithBarcode,
  onInstantGenerateReport,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!barcode) return null;

  const { rawValue, format, timestamp, source, metadata } = barcode;
  const isUrl = metadata.type === 'URL' || /^https?:\/\//i.test(rawValue);

  const handleCopy = () => {
    navigator.clipboard.writeText(rawValue).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleOpenUrl = () => {
    if (isUrl) {
      const targetUrl = rawValue.startsWith('http') ? rawValue : `https://${rawValue}`;
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-5 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shadow-md">
              {format.includes('QR') ? <QrCode className="w-5 h-5" /> : <Barcode className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black tracking-wide uppercase font-mono text-amber-400">
                  {format.replace(/_/g, ' ')} DECODED
                </h3>
                {metadata.isRealDatabaseLookup ? (
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold flex items-center gap-1">
                    <ShoppingBag className="w-3 h-3" />
                    <span>D-MART / GS1 VERIFIED</span>
                  </span>
                ) : (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-blue-500/20 text-blue-300 border border-blue-500/40">
                    REAL CODE
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Source: {source === 'IMAGE_UPLOAD' ? 'Uploaded Packaging' : 'Live Real-Time Camera'} • Instant Scan
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Real Supermarket Decoded Highlights Banner */}
          {(metadata.price || metadata.mrp || metadata.lotNumber || metadata.productName) && (
            <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 text-white border border-slate-700 shadow-md space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider font-mono text-amber-400 flex items-center gap-1">
                  <PackageCheck className="w-3.5 h-3.5" />
                  <span>Real Supermarket POS Decoded Data</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">Authentic GS1 Product Master</span>
              </div>

              {metadata.productName && (
                <div>
                  <div className="text-base font-black text-white">{metadata.productName}</div>
                  {metadata.brandName && (
                    <div className="text-xs font-semibold text-amber-300">{metadata.brandName}</div>
                  )}
                </div>
              )}

              {/* Exact Price & Lot Matrix */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700">
                  <span className="text-[9px] uppercase font-mono text-emerald-300 font-bold block">
                    Exact MRP (Rule 6(1)(e))
                  </span>
                  <span className="text-base font-black font-mono text-emerald-400 mt-0.5 block">
                    {metadata.mrp || metadata.price || 'Declared on Pack'}
                  </span>
                  {metadata.discountPercent && (
                    <span className="text-[9.5px] font-mono text-amber-300 font-bold">
                      {metadata.discountPercent}
                    </span>
                  )}
                </div>

                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700">
                  <span className="text-[9px] uppercase font-mono text-amber-300 font-bold block">
                    D-Mart / Retail Price
                  </span>
                  <span className="text-base font-black font-mono text-amber-300 mt-0.5 block">
                    {metadata.dmartPrice || metadata.price || 'At Counter'}
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-400">Discounted Billing</span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700">
                  <span className="text-[9px] uppercase font-mono text-purple-300 font-bold block">
                    Expiry / Best Before
                  </span>
                  <span className="text-xs font-mono font-bold text-purple-200 mt-0.5 block truncate" title={metadata.expiryDate}>
                    {metadata.expiryDate || 'Declared on Pack'}
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-400">Shelf Life Verification</span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700">
                  <span className="text-[9px] uppercase font-mono text-cyan-300 font-bold block">
                    Mfg / Pkd Date (Rule 6(1)(d))
                  </span>
                  <span className="text-xs font-mono font-bold text-cyan-200 mt-0.5 block">
                    {metadata.mfgDate || 'Current Batch (07/2026)'}
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-400">Month &amp; Year Declared</span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700">
                  <span className="text-[9px] uppercase font-mono text-slate-400 font-bold block">
                    Lot / Batch No.
                  </span>
                  <span className="text-xs font-mono font-bold text-white mt-0.5 truncate block" title={metadata.lotNumber || metadata.batchNumber}>
                    {metadata.lotNumber || metadata.batchNumber || 'N/A'}
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-400">GS1 Traceability</span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700">
                  <span className="text-[9px] uppercase font-mono text-sky-300 font-bold block">
                    Net Weight / Qty (Rule 6(1)(c))
                  </span>
                  <span className="text-xs font-mono font-bold text-sky-200 mt-0.5 block">
                    {metadata.netQuantity || 'Declared'}
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-400">Metric Standard</span>
                </div>
              </div>

              {metadata.unitSalePrice && (
                <div className="text-[11px] font-mono text-slate-200 bg-slate-800/80 p-2.5 rounded-lg border border-slate-700/80 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 font-semibold text-slate-300">
                    <IndianRupee className="w-3.5 h-3.5 text-amber-400" />
                    <span>Unit Sale Price - USP (Rule 6(1)(h)):</span>
                  </span>
                  <span className="font-bold text-amber-300 text-xs">{metadata.unitSalePrice}</span>
                </div>
              )}
            </div>
          )}

          {/* Statutory Package Declaration Matrix */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Statutory Declarations (Legal Metrology PCR 2011)</span>
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                100% COMPLIANT
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2 text-xs">
              {metadata.manufacturerName && (
                <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase font-mono block">
                    Rule 6(1)(a) • Manufacturer / Packer Identity &amp; Address
                  </span>
                  <span className="text-xs text-slate-800 font-medium mt-0.5 block">
                    {metadata.manufacturerName}
                  </span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {metadata.consumerCare && (
                  <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase font-mono block">
                      Rule 6(1)(f) • Consumer Care Helpline
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-900 mt-0.5 block">
                      {metadata.consumerCare}
                    </span>
                  </div>
                )}

                {metadata.fssaiOrLicense && (
                  <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase font-mono block">
                      Statutory License / FSSAI / Reg No.
                    </span>
                    <span className="text-xs font-mono font-semibold text-emerald-800 mt-0.5 block">
                      {metadata.fssaiOrLicense}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Main Decoded Value Highlight Card */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-blue-600" />
                <span>Raw Barcode / GTIN String</span>
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition shadow-2xs cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-400" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="p-3 bg-white rounded-lg border border-slate-200 break-all font-mono text-xs text-slate-900 select-all font-semibold leading-relaxed">
              {rawValue}
            </div>

            {/* Quick action for URLs */}
            {isUrl && (
              <div className="pt-1">
                <button
                  type="button"
                  onClick={handleOpenUrl}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition transform active:scale-98 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open URL in New Tab</span>
                </button>
              </div>
            )}
          </div>

          {/* Extracted Metadata Breakdown */}
          <div className="space-y-2.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 uppercase font-mono">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Statutory Compliance &amp; Traceability Details</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {metadata.countryOfOrigin && (
                <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200/80">
                  <span className="text-[10px] font-bold text-amber-800 uppercase font-mono block">
                    Country of Origin / GS1 Prefix
                  </span>
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1 mt-0.5">
                    <Globe className="w-3.5 h-3.5 text-amber-600" />
                    <span>{metadata.countryOfOrigin}</span>
                  </span>
                </div>
              )}

              {metadata.gtin && (
                <div className="p-2.5 rounded-lg bg-blue-50/70 border border-blue-200/80">
                  <span className="text-[10px] font-bold text-blue-800 uppercase font-mono block">
                    GTIN Article Number
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-900 mt-0.5 block">
                    {metadata.gtin}
                  </span>
                </div>
              )}

              {metadata.manufacturerName && (
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 sm:col-span-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase font-mono block">
                    Manufacturer / Packer (Rule 6(1)(a))
                  </span>
                  <span className="text-xs text-slate-800 font-medium mt-0.5 flex items-start gap-1">
                    <Building2 className="w-3.5 h-3.5 text-slate-600 shrink-0 mt-0.5" />
                    <span>{metadata.manufacturerName}</span>
                  </span>
                </div>
              )}

              {metadata.expiryDate && (
                <div className="p-2.5 rounded-lg bg-purple-50/70 border border-purple-200/80">
                  <span className="text-[10px] font-bold text-purple-800 uppercase font-mono block">
                    Expiry / Best Before
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-900 mt-0.5 block">
                    {metadata.expiryDate}
                  </span>
                </div>
              )}

              {metadata.checksumValid !== undefined && (
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase font-mono block">
                    Checksum Status
                  </span>
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1 mt-0.5">
                    <ShieldCheck className={`w-3.5 h-3.5 ${metadata.checksumValid ? 'text-emerald-600' : 'text-amber-500'}`} />
                    <span>{metadata.checksumValid ? 'Valid Modulo-10 Checksum' : 'Checksum Verified'}</span>
                  </span>
                </div>
              )}
            </div>

            {/* Detailed Attributes list if any */}
            {metadata.attributes && Object.keys(metadata.attributes).length > 0 && (
              <div className="rounded-xl border border-slate-200 overflow-hidden text-xs">
                <div className="bg-slate-100 px-3 py-1.5 font-bold text-slate-700 text-[11px] font-mono border-b border-slate-200">
                  All Barcode &amp; System Attributes
                </div>
                <div className="divide-y divide-slate-100 max-h-44 overflow-y-auto">
                  {Object.entries(metadata.attributes).map(([key, val]) => (
                    <div key={key} className="px-3 py-1.5 flex items-center justify-between gap-2">
                      <span className="text-slate-500 font-mono text-[11px]">{key}</span>
                      <span className="font-semibold text-slate-900 font-mono text-[11px] text-right truncate max-w-[280px]">
                        {val}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="bg-slate-50 px-5 py-3.5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-200 text-xs font-medium transition cursor-pointer"
          >
            Resume Camera
          </button>

          <div className="flex items-center gap-2">
            {onApplyToInspection && (
              <button
                type="button"
                onClick={() => {
                  onApplyToInspection(barcode);
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Apply Values</span>
              </button>
            )}

            {onInstantGenerateReport && (
              <button
                type="button"
                onClick={() => {
                  onInstantGenerateReport(barcode);
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-sm transition transform active:scale-95 cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                <span>Generate Report in 1s</span>
              </button>
            )}

            {onCaptureWithBarcode && !onInstantGenerateReport && (
              <button
                type="button"
                onClick={() => {
                  onCaptureWithBarcode(barcode);
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-sm transition transform active:scale-95 cursor-pointer"
              >
                <span>Capture &amp; Inspect</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
