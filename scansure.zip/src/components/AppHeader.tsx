import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { ActiveScreen } from './Navbar';
import { ScanSureLogo } from './ScanSureLogo';

interface AppHeaderProps {
  activeScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
  onOpenCommandPalette?: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  currentInspectionId?: string;
  onOpenMobileMenu?: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  activeScreen,
  onNavigate,
  isDarkMode,
  onToggleDarkMode,
  currentInspectionId,
}) => {
  const screenTitles: Record<ActiveScreen, string> = {
    DASHBOARD: 'ScanSure',
    SCANNER: 'Package Scanner & Barcode Decode',
    ANALYSIS: 'OCR Evidence & Inspection Map',
    REVIEW: 'PCR 2011 Verification Review',
    REPORT: 'Inspection Certificate',
    HISTORY: 'Audit Trail & Record History',
  };

  const currentTitle = screenTitles[activeScreen] || screenTitles.DASHBOARD;

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors">
      <div className="px-4 sm:px-6 flex items-center justify-between h-14 gap-4">
        {/* Left: Mobile Brand Logo & Header Title */}
        <div className="flex items-center gap-3 min-w-0">
          {/* Logo visible only on mobile / small screens where sidebar is hidden */}
          <div
            onClick={() => onNavigate('DASHBOARD')}
            className="lg:hidden flex items-center cursor-pointer shrink-0"
          >
            <ScanSureLogo size="sm" showText={false} />
          </div>

          {/* Web App Workspace Title */}
          <div className="flex flex-col min-w-0">
            <h1 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-tight truncate">
              {currentTitle}
            </h1>
          </div>
        </div>

        {/* Right: Theme Toggle & Mobile Menu Trigger */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Dark Mode Toggle */}
          <button
            type="button"
            onClick={onToggleDarkMode}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-700" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
