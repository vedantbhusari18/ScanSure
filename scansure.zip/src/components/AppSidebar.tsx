import React from 'react';
import {
  LayoutDashboard,
  Camera,
  Search,
  FileCheck2,
  FileSpreadsheet,
  History,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  UserCheck,
  Radio,
  FileText,
  Zap,
} from 'lucide-react';
import { ActiveScreen } from './Navbar';
import { ScanSureLogo } from './ScanSureLogo';
import { InspectionRecord } from '../types/inspection';
import { PWAInstallButton } from './PWAInstallButton';

interface AppSidebarProps {
  activeScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  currentInspection: InspectionRecord | null;
  inspectionsCount: number;
}

export const AppSidebar: React.FC<AppSidebarProps> = ({
  activeScreen,
  onNavigate,
  collapsed,
  onToggleCollapse,
  currentInspection,
  inspectionsCount,
}) => {
  const navItems = [
    {
      id: 'DASHBOARD' as ActiveScreen,
      label: 'Overview',
      subtitle: 'Batch KPIs & metrics',
      icon: LayoutDashboard,
      hotkey: '1',
    },
    {
      id: 'SCANNER' as ActiveScreen,
      label: 'Package Scanner',
      subtitle: 'Camera & barcode decode',
      icon: Camera,
      hotkey: '2',
      isLive: true,
    },
    {
      id: 'ANALYSIS' as ActiveScreen,
      label: 'Evidence & OCR',
      subtitle: 'Detection coordinates',
      icon: Search,
      hotkey: '3',
    },
    {
      id: 'REVIEW' as ActiveScreen,
      label: 'PCR 2011 Review',
      subtitle: 'Mandatory checklist',
      icon: FileCheck2,
      hotkey: '4',
    },
    {
      id: 'REPORT' as ActiveScreen,
      label: 'Certificates',
      subtitle: 'Statutory PDF export',
      icon: FileSpreadsheet,
      hotkey: '5',
    },
    {
      id: 'HISTORY' as ActiveScreen,
      label: 'Audit History',
      subtitle: `${inspectionsCount} saved records`,
      icon: History,
      hotkey: '6',
    },
  ];

  return (
    <aside
      className={`hidden lg:flex flex-col bg-white dark:bg-slate-900 border-r border-slate-200/80 dark:border-slate-800 transition-all duration-200 z-30 select-none ${
        collapsed ? 'w-18' : 'w-64'
      }`}
    >
      {/* Brand & Toggle Header */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-slate-200/80 dark:border-slate-800 shrink-0">
        <div
          onClick={() => onNavigate('DASHBOARD')}
          className="flex items-center gap-2 cursor-pointer overflow-hidden"
          title="ScanSure Web Application"
        >
          <ScanSureLogo size={collapsed ? 'sm' : 'md'} showText={!collapsed} />
        </div>

        <button
          type="button"
          onClick={onToggleCollapse}
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <ChevronLeft className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Terminal Workspace Tag (Unboxed metadata) */}
      {!collapsed && (
        <div className="px-4 py-2.5 bg-slate-50/60 dark:bg-slate-900/40 border-b border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-slate-700 dark:text-slate-300">Terminal #04</span>
            <span aria-hidden="true">·</span>
            <span>Online</span>
          </div>
          <span className="font-mono text-[10px] text-slate-400">PCR 2011</span>
        </div>
      )}

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {!collapsed && (
          <div className="px-2 pb-1.5 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            Workspace
          </div>
        )}

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeScreen === item.id;
          const isScanner = item.id === 'SCANNER';

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              title={`${item.label} (Press ${item.hotkey})`}
              className={`w-full group flex items-center gap-3 p-2.5 rounded-xl transition-all text-left cursor-pointer border ${
                isActive
                  ? 'bg-slate-900 text-white dark:bg-emerald-600 dark:text-white border-transparent shadow-xs'
                  : isScanner
                  ? 'bg-emerald-50/60 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300 hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 border-emerald-200/60 dark:border-emerald-800/40'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white border-transparent'
              }`}
            >
              <div
                className={`p-1.5 rounded-lg shrink-0 transition-colors ${
                  isActive
                    ? 'bg-white/20 text-white'
                    : isScanner
                    ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400'
                    : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>

              {!collapsed && (
                <div className="flex-1 min-w-0 flex items-center justify-between">
                  <div className="truncate">
                    <div className="text-xs font-semibold leading-tight flex items-center gap-1.5">
                      <span className="truncate">{item.label}</span>
                      {item.isLive && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      )}
                    </div>
                    <div
                      className={`text-[10px] truncate leading-tight mt-0.5 ${
                        isActive
                          ? 'text-slate-300 dark:text-emerald-100'
                          : 'text-slate-400 dark:text-slate-500'
                      }`}
                    >
                      {item.subtitle}
                    </div>
                  </div>

                  <kbd
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded ml-2 shrink-0 ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.hotkey}
                  </kbd>
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Active Record Quick Panel (if inspection exists) */}
      {!collapsed && currentInspection && (
        <div className="p-3 mx-3 mb-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Active Batch</span>
            <span className="font-mono font-bold text-slate-900 dark:text-white">
              {currentInspection.batchNumber}
            </span>
          </div>
          <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
            {currentInspection.commodityName}
          </p>
          <div className="mt-2 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onNavigate('ANALYSIS')}
              className="flex-1 py-1 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold text-center transition cursor-pointer"
            >
              Analyze
            </button>
            <button
              type="button"
              onClick={() => onNavigate('REPORT')}
              className="py-1 px-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-[11px] font-medium hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              PDF
            </button>
          </div>
        </div>
      )}

      {/* PWA In-App Install Button in Sidebar */}
      <div className="px-3 pb-2 shrink-0">
        <PWAInstallButton variant={collapsed ? 'compact' : 'full'} />
      </div>

      {/* Inspector Profile & Status Footer */}
      <div className="p-3 border-t border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-xs shrink-0">
            JS
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate leading-tight">
                J. Sharma, Metrologist
              </p>
              <p className="text-[10px] text-slate-400 truncate leading-tight mt-0.5">
                Dept. Legal Metrology
              </p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
