import React from 'react';

// Standard GS1 EAN-13 encoding tables
const L_CODES = [
  '0001101', '0011001', '0010011', '0111101', '0100011',
  '0110001', '0101111', '0111011', '0110111', '0001011',
];

const G_CODES = [
  '0100111', '0110011', '0011011', '0100001', '0011101',
  '0111001', '0000101', '0010001', '0001001', '0010111',
];

const R_CODES = [
  '1110010', '1100110', '1101100', '1000010', '1011100',
  '1001110', '1010000', '1000100', '1001000', '1110100',
];

const PARITY_MAP = [
  'LLLLLL', // 0
  'LLGLGG', // 1
  'LLGGLG', // 2
  'LLGGGL', // 3
  'LGLLGG', // 4
  'LGGLLG', // 5
  'LGGGLL', // 6
  'LGLGLG', // 7
  'LGLGGL', // 8
  'LGGLGL', // 9
];

interface BarcodeSvgProps {
  value: string;
  width?: number;
  height?: number;
  showText?: boolean;
  className?: string;
}

export const BarcodeSvg: React.FC<BarcodeSvgProps> = ({
  value,
  width = 220,
  height = 75,
  showText = true,
  className = '',
}) => {
  // Normalize string
  const cleanVal = String(value || '').replace(/\D/g, '');
  let digits = cleanVal;

  if (digits.length === 12) {
    digits = '0' + digits; // convert UPC-A to EAN-13
  }

  // If not standard 13 digits, pad or fallback
  if (digits.length !== 13) {
    digits = digits.padStart(13, '0').slice(-13);
  }

  const firstDigit = parseInt(digits[0], 10) || 0;
  const parity = PARITY_MAP[firstDigit] || 'LLLLLL';

  let modules = '';
  // Left guard: 101
  modules += '101';

  // 6 left digits
  for (let i = 1; i <= 6; i++) {
    const digit = parseInt(digits[i], 10) || 0;
    const type = parity[i - 1];
    modules += type === 'L' ? L_CODES[digit] : G_CODES[digit];
  }

  // Center guard: 01010
  modules += '01010';

  // 6 right digits (R codes)
  for (let i = 7; i <= 12; i++) {
    const digit = parseInt(digits[i], 10) || 0;
    modules += R_CODES[digit];
  }

  // Right guard: 101
  modules += '101';

  const totalModules = modules.length; // 95 modules
  const quietZone = 7; // Quiet margin modules
  const totalUnits = totalModules + quietZone * 2;
  const barHeight = showText ? height - 18 : height;
  const guardExtraHeight = showText ? 5 : 0;

  // Guard positions in 95-module EAN-13:
  // Left: 0..2
  // Center: 45..49
  // Right: 92..94
  const isGuard = (idx: number) => {
    return (idx >= 0 && idx <= 2) || (idx >= 45 && idx <= 49) || (idx >= 92 && idx <= 94);
  };

  return (
    <div className={`inline-flex flex-col items-center select-none ${className}`}>
      <svg
        viewBox={`0 0 ${totalUnits} ${height}`}
        width={width}
        height={height}
        className="bg-white p-1 rounded-sm overflow-visible"
        shapeRendering="crispEdges"
      >
        {/* Background white rect */}
        <rect x="0" y="0" width={totalUnits} height={height} fill="#ffffff" />

        {/* Barcode bars */}
        {modules.split('').map((bit, idx) => {
          if (bit !== '1') return null;
          const x = quietZone + idx;
          const h = isGuard(idx) ? barHeight + guardExtraHeight : barHeight;
          return <rect key={idx} x={x} y={2} width={1} height={h} fill="#09090b" />;
        })}

        {/* Human readable numbers */}
        {showText && (
          <text
            x={totalUnits / 2}
            y={height - 2}
            textAnchor="middle"
            fill="#09090b"
            fontSize="7"
            fontFamily="ui-monospace, monospace"
            fontWeight="bold"
            letterSpacing="1"
          >
            {digits[0]}  {digits.slice(1, 7)}  {digits.slice(7, 13)}
          </text>
        )}
      </svg>
    </div>
  );
};
