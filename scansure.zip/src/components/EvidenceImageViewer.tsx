import React, { useState } from 'react';
import { ExtractedField, MVPFieldKey } from '../types/inspection';
import { ZoomIn, ZoomOut, RotateCcw, Eye, Layers } from 'lucide-react';

interface EvidenceImageViewerProps {
  imageUrl: string;
  fields: Record<MVPFieldKey, ExtractedField>;
  selectedFieldKey?: MVPFieldKey | null;
  onSelectField?: (key: MVPFieldKey) => void;
  productTitle?: string;
}

export const EvidenceImageViewer: React.FC<EvidenceImageViewerProps> = ({
  imageUrl,
  fields,
  selectedFieldKey,
  onSelectField,
  productTitle = 'Packaged Commodity',
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showBoxes, setShowBoxes] = useState<boolean>(true);
  const [hoveredFieldKey, setHoveredFieldKey] = useState<MVPFieldKey | null>(null);

  const handleZoomIn = () => setZoomLevel((prev) => Math.min(prev + 0.25, 2.5));
  const handleZoomOut = () => setZoomLevel((prev) => Math.max(prev - 0.25, 0.75));
  const handleReset = () => setZoomLevel(1);

  const activeFieldKey = selectedFieldKey || hoveredFieldKey;

  return (
    <div id="evidence-viewer-container" className="flex flex-col bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
      {/* Control Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-50 border-b border-slate-200 text-slate-700 text-xs">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-600" />
          <span className="font-bold text-slate-900">Evidence Vision Stage</span>
          <span className="text-slate-300">|</span>
          <span className="text-slate-600 truncate max-w-xs">{productTitle}</span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            id="toggle-boxes-btn"
            onClick={() => setShowBoxes(!showBoxes)}
            className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition ${
              showBoxes
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
            title="Toggle Bounding Boxes"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{showBoxes ? 'Boxes ON' : 'Boxes OFF'}</span>
          </button>

          <div className="h-4 w-px bg-slate-300 mx-1" />

          <button
            type="button"
            id="zoom-out-btn"
            onClick={handleZoomOut}
            className="p-1 rounded-md bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-2xs transition"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="px-1.5 text-[11px] text-slate-600 font-mono font-semibold">
            {Math.round(zoomLevel * 100)}%
          </span>
          <button
            type="button"
            id="zoom-in-btn"
            onClick={handleZoomIn}
            className="p-1 rounded-md bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-2xs transition"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            id="zoom-reset-btn"
            onClick={handleReset}
            className="p-1 rounded-md bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-2xs transition ml-1"
            title="Reset Zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Image Stage Container */}
      <div className="relative w-full h-[480px] bg-slate-100/70 overflow-auto flex items-center justify-center p-4">
        <div
          className="relative transition-transform duration-200 ease-out origin-center"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          {/* Base Package Image */}
          <img
            src={imageUrl}
            alt={productTitle}
            className="max-h-[440px] w-auto object-contain rounded-lg shadow-md pointer-events-none select-none border border-slate-200/80 bg-white"
          />

          {/* Bounding Box Overlays */}
          {showBoxes && (
            <div className="absolute inset-0 pointer-events-auto">
              {(Object.keys(fields) as MVPFieldKey[]).map((key) => {
                const field = fields[key];
                const box = field.boundingBox;
                if (!box) return null;

                const isSelected = selectedFieldKey === key;
                const isHovered = hoveredFieldKey === key;
                const isHighlighted = isSelected || isHovered;

                let borderColor = 'border-emerald-600 bg-emerald-500/15 text-emerald-800';
                let dotColor = 'bg-emerald-600';

                if (field.status === 'REVIEW') {
                  borderColor = 'border-amber-600 bg-amber-500/20 text-amber-900';
                  dotColor = 'bg-amber-600 animate-pulse';
                } else if (field.status === 'MISSING') {
                  borderColor = 'border-rose-600 bg-rose-500/20 text-rose-900';
                  dotColor = 'bg-rose-600';
                }

                return (
                  <div
                    key={key}
                    id={`bbox-${key}`}
                    onClick={() => onSelectField?.(key)}
                    onMouseEnter={() => setHoveredFieldKey(key)}
                    onMouseLeave={() => setHoveredFieldKey(null)}
                    style={{
                      left: `${box.x}%`,
                      top: `${box.y}%`,
                      width: `${box.width}%`,
                      height: `${box.height}%`,
                    }}
                    className={`absolute cursor-pointer rounded transition-all duration-150 border-2 ${borderColor} ${
                      isHighlighted
                        ? 'ring-3 ring-amber-400 shadow-md scale-[1.02] z-30'
                        : 'hover:ring-2 hover:ring-slate-400 z-10'
                    }`}
                  >
                    {/* Corner Tag Label */}
                    <div
                      className={`absolute -top-5 left-0 px-1.5 py-0.5 rounded text-[10px] font-bold tracking-tight whitespace-nowrap shadow-xs flex items-center gap-1 ${
                        field.status === 'FOUND'
                          ? 'bg-emerald-700 text-white'
                          : field.status === 'REVIEW'
                          ? 'bg-amber-700 text-white'
                          : 'bg-rose-700 text-white'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />
                      <span>{field.fieldName}</span>
                      <span className="opacity-90 font-mono">({Math.round(field.confidence * 100)}%)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Active Field Quick Inspection Drawer */}
      {activeFieldKey && fields[activeFieldKey] && (
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2.5">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                fields[activeFieldKey].status === 'FOUND'
                  ? 'bg-emerald-600'
                  : fields[activeFieldKey].status === 'REVIEW'
                  ? 'bg-amber-600'
                  : 'bg-rose-600'
              }`}
            />
            <div>
              <span className="font-bold text-slate-900">{fields[activeFieldKey].fieldName}:</span>{' '}
              <span className="text-slate-800 font-mono font-medium">
                {fields[activeFieldKey].cleanedValue || fields[activeFieldKey].rawValue || '[Omitted / Not Declared]'}
              </span>
            </div>
          </div>
          <div className="text-slate-600 text-[11px] font-mono">
            <span>Rule: </span>
            <span className="font-bold text-slate-800">{fields[activeFieldKey].ruleReference}</span>
          </div>
        </div>
      )}
    </div>
  );
};
