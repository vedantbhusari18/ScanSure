import React, { useEffect, useRef, useState, useImperativeHandle, forwardRef } from 'react';
import { SUPERMARKET_CATALOG, SupermarketProduct } from '../data/supermarketProducts';
import { Sparkles, Scan, RotateCw, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';

export interface SimulatedCameraFeedRef {
  getCanvas: () => HTMLCanvasElement | null;
  captureFrame: () => string;
  getCurrentProduct: () => SupermarketProduct;
}

interface SimulatedCameraFeedProps {
  onProductChange?: (product: SupermarketProduct) => void;
  onFrameScanned?: (product: SupermarketProduct) => void;
  isBarcodeScannerActive?: boolean;
}

// Draw standard EAN-13 barcode pattern on 2D canvas
function drawEan13Barcode(
  ctx: CanvasRenderingContext2D,
  code: string,
  x: number,
  y: number,
  width: number,
  height: number
) {
  // Pad or trim to 13 digits
  const digits = (code.replace(/\D/g, '') + '8901058852393').slice(0, 13);

  // Background white box with quiet zones
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x - 12, y - 6, width + 24, height + 24);

  // Barcode styling
  ctx.fillStyle = '#0f172a';

  // Standard EAN-13 bit patterns (L and G codes)
  const L_CODES = [
    '0001101', '0011001', '0010011', '0111101', '0100011',
    '0110001', '0101111', '0111011', '0110111', '0001011'
  ];
  const R_CODES = [
    '1110010', '1100110', '1101100', '1000010', '1011100',
    '1001110', '1010000', '1000100', '1001000', '1110100'
  ];

  // Start guard (101)
  let pattern = '101';

  // Left 6 digits (using simplified L codes for visual fidelity)
  for (let i = 1; i <= 6; i++) {
    const d = parseInt(digits[i], 10) || 0;
    pattern += L_CODES[d];
  }

  // Center guard (01010)
  pattern += '01010';

  // Right 6 digits (using R codes)
  for (let i = 7; i <= 12; i++) {
    const d = parseInt(digits[i], 10) || 0;
    pattern += R_CODES[d];
  }

  // End guard (101)
  pattern += '101';

  const barWidth = width / pattern.length;

  for (let i = 0; i < pattern.length; i++) {
    if (pattern[i] === '1') {
      const isGuard = i < 3 || (i >= 45 && i < 50) || i >= 92;
      const barH = isGuard ? height + 6 : height;
      ctx.fillRect(x + i * barWidth, y, Math.ceil(barWidth), barH);
    }
  }

  // Human readable digits text
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 12px monospace';
  ctx.textAlign = 'center';
  ctx.fillText(digits.slice(0, 1) + ' ' + digits.slice(1, 7) + ' ' + digits.slice(7, 13), x + width / 2, y + height + 16);
}

export const SimulatedCameraFeed = forwardRef<SimulatedCameraFeedRef, SimulatedCameraFeedProps>(
  ({ onProductChange, onFrameScanned, isBarcodeScannerActive = true }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const [selectedProductIndex, setSelectedProductIndex] = useState<number>(0);
    const animFrameRef = useRef<number | null>(null);
    const startTimeRef = useRef<number>(Date.now());

    // Selected product from authentic catalog
    const activeProduct = SUPERMARKET_CATALOG[selectedProductIndex % SUPERMARKET_CATALOG.length];

    useEffect(() => {
      if (onProductChange) {
        onProductChange(activeProduct);
      }
    }, [selectedProductIndex]);

    useImperativeHandle(ref, () => ({
      getCanvas: () => canvasRef.current,
      captureFrame: () => {
        if (!canvasRef.current) return '';
        return canvasRef.current.toDataURL('image/jpeg', 0.9);
      },
      getCurrentProduct: () => activeProduct,
    }));

    // Live continuous 30FPS realistic camera simulation renderer
    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let isRunning = true;

      const render = () => {
        if (!isRunning) return;

        const now = Date.now();
        const elapsed = (now - startTimeRef.current) / 1000;

        const width = canvas.width || 1280;
        const height = canvas.height || 720;

        // 1. Background: Simulated Retail Inspection Conveyor / Bench Lighting
        const bgGrad = ctx.createRadialGradient(width / 2, height / 2, 80, width / 2, height / 2, width * 0.7);
        bgGrad.addColorStop(0, '#1e293b');
        bgGrad.addColorStop(0.6, '#0f172a');
        bgGrad.addColorStop(1, '#020617');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);

        // Subtle technical grid pattern
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.04)';
        ctx.lineWidth = 1;
        const gridSize = 40;
        for (let x = 0; x < width; x += gridSize) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
          ctx.stroke();
        }
        for (let y = 0; y < height; y += gridSize) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }

        // 2. Realistic Handheld Camera Drift (sine-wave micro breathing)
        const driftX = Math.sin(elapsed * 0.8) * 8;
        const driftY = Math.cos(elapsed * 1.1) * 6;
        const scaleZoom = 1.0 + Math.sin(elapsed * 0.5) * 0.015;

        ctx.save();
        ctx.translate(width / 2 + driftX, height / 2 + driftY);
        ctx.scale(scaleZoom, scaleZoom);
        ctx.translate(-width / 2, -height / 2);

        // 3. Product Package Surface
        const pkgW = 620;
        const pkgH = 500;
        const pkgX = (width - pkgW) / 2;
        const pkgY = (height - pkgH) / 2 - 10;

        // Shadow behind package
        ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
        ctx.shadowBlur = 30;
        ctx.shadowOffsetY = 15;

        // Package Body with Rounded Corners
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.roundRect(pkgX, pkgY, pkgW, pkgH, 18);
        ctx.fill();
        ctx.shadowColor = 'transparent';

        // Package Outer Border
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 3;
        ctx.stroke();

        // 4. Product Header Banner (Customized per brand)
        let headerColor1 = '#dc2626';
        let headerColor2 = '#b91c1c';
        if (activeProduct.brand.toLowerCase().includes('nestle') || activeProduct.productName.toLowerCase().includes('maggi')) {
          headerColor1 = '#eab308'; // Maggi yellow
          headerColor2 = '#ca8a04';
        } else if (activeProduct.brand.toLowerCase().includes('parle')) {
          headerColor1 = '#f59e0b';
          headerColor2 = '#d97706';
        } else if (activeProduct.brand.toLowerCase().includes('amul')) {
          headerColor1 = '#2563eb';
          headerColor2 = '#1d4ed8';
        } else if (activeProduct.brand.toLowerCase().includes('tata')) {
          headerColor1 = '#0284c7';
          headerColor2 = '#0369a1';
        }

        const bannerGrad = ctx.createLinearGradient(pkgX, pkgY, pkgX + pkgW, pkgY);
        bannerGrad.addColorStop(0, headerColor1);
        bannerGrad.addColorStop(1, headerColor2);
        ctx.fillStyle = bannerGrad;
        ctx.beginPath();
        ctx.roundRect(pkgX, pkgY, pkgW, 85, [18, 18, 0, 0]);
        ctx.fill();

        // Brand & Product Header Text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 20px system-ui, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`★ ${activeProduct.brand.toUpperCase()} ★`, pkgX + 24, pkgY + 34);

        ctx.font = '900 24px system-ui, sans-serif';
        ctx.fillText(activeProduct.productName, pkgX + 24, pkgY + 68);

        // Green Veg / Food Symbol
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(pkgX + pkgW - 48, pkgY + 24, 30, 30);
        ctx.strokeStyle = '#16a34a';
        ctx.lineWidth = 2.5;
        ctx.strokeRect(pkgX + pkgW - 48, pkgY + 24, 30, 30);
        ctx.fillStyle = '#16a34a';
        ctx.beginPath();
        ctx.arc(pkgX + pkgW - 33, pkgY + 39, 7.5, 0, Math.PI * 2);
        ctx.fill();

        // 5. Mandatory PCR 2011 Declaration Table (Government Legal Metrology Format)
        const tableX = pkgX + 20;
        const tableY = pkgY + 105;
        const tableW = 340;

        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(tableX, tableY, tableW, 370);
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(tableX, tableY, tableW, 370);

        // Section Title: Mandatory PCR Declarations
        ctx.fillStyle = '#1e293b';
        ctx.font = 'bold 12px system-ui, sans-serif';
        ctx.fillText('LEGAL METROLOGY (PACKAGED COMMODITIES) RULES, 2011', tableX + 12, tableY + 24);

        ctx.strokeStyle = '#cbd5e1';
        ctx.beginPath();
        ctx.moveTo(tableX + 12, tableY + 32);
        ctx.lineTo(tableX + tableW - 12, tableY + 32);
        ctx.stroke();

        // Declaration Line Items
        const fields = [
          { label: 'Commodity:', val: activeProduct.productName.slice(0, 28) },
          { label: 'Net Quantity:', val: activeProduct.netQuantity },
          { label: 'Max Retail Price (MRP):', val: `${activeProduct.mrp} (Incl. of all taxes)` },
          { label: 'Unit Sale Price (USP):', val: activeProduct.unitSalePrice || '₹0.20 / g' },
          { label: 'Month & Year of Mfg:', val: activeProduct.mfgDate },
          { label: 'Best Before / Expiry:', val: activeProduct.expiryDate || '9 Months from Mfg' },
          { label: 'Batch / Lot No.:', val: activeProduct.lotNumber },
          { label: 'Consumer Care:', val: activeProduct.consumerCare || '1800-103-1947' },
          { label: 'FSSAI License No.:', val: activeProduct.fssaiOrLicense || '10012011000168' },
          { label: 'Country of Origin:', val: activeProduct.countryOfOrigin || 'India' },
        ];

        let curY = tableY + 54;
        fields.forEach((f) => {
          ctx.fillStyle = '#64748b';
          ctx.font = 'bold 11px system-ui, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(f.label, tableX + 12, curY);

          ctx.fillStyle = '#0f172a';
          ctx.font = '600 11px system-ui, sans-serif';
          ctx.fillText(f.val, tableX + 145, curY);

          curY += 31;
        });

        // 6. Right Column: High-Res Barcode & Supermarket POS Tag
        const bcX = pkgX + 380;
        const bcY = pkgY + 125;
        const bcW = 210;
        const bcH = 95;

        // Draw Authenticated EAN-13 Barcode
        drawEan13Barcode(ctx, activeProduct.barcode, bcX, bcY, bcW, bcH);

        // Supermarket D-Mart Special Price Badge
        const discountBoxY = bcY + bcH + 45;
        ctx.fillStyle = '#059669';
        ctx.beginPath();
        ctx.roundRect(bcX, discountBoxY, bcW, 75, 10);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px system-ui, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText('SUPERMARKET SMART VALUE', bcX + 14, discountBoxY + 22);

        ctx.font = 'bold 22px system-ui, sans-serif';
        ctx.fillText(`D-MART: ${activeProduct.dmartPrice}`, bcX + 14, discountBoxY + 50);

        ctx.font = '10px system-ui, sans-serif';
        ctx.fillStyle = '#a7f3d0';
        ctx.fillText(`Save vs MRP ${activeProduct.mrp}`, bcX + 14, discountBoxY + 66);

        // Manufacturer Seal Box
        const mfgBoxY = discountBoxY + 90;
        ctx.fillStyle = '#f1f5f9';
        ctx.beginPath();
        ctx.roundRect(bcX, mfgBoxY, bcW, 55, 8);
        ctx.fill();
        ctx.strokeStyle = '#e2e8f0';
        ctx.stroke();

        ctx.fillStyle = '#475569';
        ctx.font = 'bold 9px system-ui, sans-serif';
        ctx.fillText('PACKED & MARKETED BY:', bcX + 10, mfgBoxY + 16);
        ctx.font = '8px system-ui, sans-serif';
        ctx.fillText(activeProduct.manufacturer.slice(0, 36), bcX + 10, mfgBoxY + 30);
        ctx.fillText(activeProduct.manufacturer.slice(36, 75), bcX + 10, mfgBoxY + 42);

        ctx.restore();

        // 7. Sensor Grain & Live Camera HUD
        ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
        for (let i = 0; i < 400; i++) {
          const rx = Math.random() * width;
          const ry = Math.random() * height;
          ctx.fillRect(rx, ry, 1, 1);
        }

        // Live Optical Scanning Laser Line
        if (isBarcodeScannerActive) {
          const laserProgress = (elapsed % 2.5) / 2.5;
          const laserY = pkgY + 100 + laserProgress * 360;

          const laserGrad = ctx.createLinearGradient(pkgX - 40, laserY, pkgX + pkgW + 40, laserY);
          laserGrad.addColorStop(0, 'rgba(16, 185, 129, 0)');
          laserGrad.addColorStop(0.5, 'rgba(52, 211, 153, 0.85)');
          laserGrad.addColorStop(1, 'rgba(16, 185, 129, 0)');

          ctx.fillStyle = laserGrad;
          ctx.fillRect(pkgX - 40, laserY - 1.5, pkgW + 80, 3);

          // Subtle laser beam glow
          ctx.shadowColor = '#10b981';
          ctx.shadowBlur = 10;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
          ctx.fillRect(pkgX + 20, laserY - 0.5, pkgW - 40, 1);
          ctx.shadowColor = 'transparent';
        }

        // Frame Loop
        animFrameRef.current = requestAnimationFrame(render);
      };

      animFrameRef.current = requestAnimationFrame(render);

      return () => {
        isRunning = false;
        if (animFrameRef.current) {
          cancelAnimationFrame(animFrameRef.current);
        }
      };
    }, [activeProduct, isBarcodeScannerActive]);

    return (
      <div className="relative w-full h-full flex flex-col items-center justify-center">
        {/* Main Canvas rendering real-time high-fidelity packaging feed */}
        <canvas
          ref={canvasRef}
          width={1280}
          height={720}
          className="w-full h-full object-contain bg-black"
        />

        {/* Product Carousel Quick Switcher Toolbar at bottom */}
        <div className="absolute bottom-16 left-4 right-4 flex items-center justify-center gap-2 z-20 pointer-events-auto">
          <div className="bg-slate-950/85 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/20 shadow-2xl flex items-center gap-2 max-w-full overflow-x-auto">
            <span className="text-[10px] text-amber-300 font-mono font-bold flex items-center gap-1 shrink-0">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Simulated Package:</span>
            </span>

            {[
              { label: 'Maggi Noodles', idx: 0 },
              { label: 'Parle-G Biscuits', idx: 1 },
              { label: 'Amul Butter', idx: 2 },
              { label: 'Tata Salt', idx: 3 },
              { label: 'Cadbury Dairy Milk', idx: 4 },
            ].map((item) => (
              <button
                key={item.label}
                type="button"
                onClick={() => setSelectedProductIndex(item.idx)}
                className={`px-2.5 py-1 rounded-full text-[10px] font-medium transition shrink-0 cursor-pointer ${
                  selectedProductIndex === item.idx
                    ? 'bg-amber-400 text-slate-950 font-bold shadow-xs'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                }`}
              >
                {item.label}
              </button>
            ))}

            <button
              type="button"
              onClick={() => setSelectedProductIndex((prev) => (prev + 1) % 5)}
              className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition shrink-0"
              title="Next Product Package"
            >
              <RotateCw className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    );
  }
);
SimulatedCameraFeed.displayName = 'SimulatedCameraFeed';
