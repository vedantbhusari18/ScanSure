import React from 'react';
import { FieldStatus, OverallVerdict } from '../types/inspection';
import { CheckCircle2, AlertTriangle, XCircle, ShieldCheck, ShieldAlert, Clock } from 'lucide-react';

interface StatusBadgeProps {
  status: FieldStatus | OverallVerdict;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md', showIcon = true }) => {
  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5 gap-1 font-semibold',
    md: 'text-xs px-2.5 py-1 gap-1.5 font-semibold',
    lg: 'text-xs sm:text-sm px-3 py-1.5 gap-2 font-bold',
  };

  switch (status) {
    case 'FOUND':
      return (
        <span
          id={`badge-found-${size}`}
          className={`inline-flex items-center rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 ${sizeClasses[size]}`}
        >
          {showIcon && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
          <span>FOUND</span>
        </span>
      );

    case 'REVIEW':
      return (
        <span
          id={`badge-review-${size}`}
          className={`inline-flex items-center rounded-md bg-amber-50 text-amber-800 border border-amber-200 ${sizeClasses[size]}`}
        >
          {showIcon && <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />}
          <span>REVIEW</span>
        </span>
      );

    case 'MISSING':
      return (
        <span
          id={`badge-missing-${size}`}
          className={`inline-flex items-center rounded-md bg-rose-50 text-rose-800 border border-rose-200 ${sizeClasses[size]}`}
        >
          {showIcon && <XCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />}
          <span>MISSING</span>
        </span>
      );

    case 'COMPLIANT':
      return (
        <span
          id={`badge-compliant-${size}`}
          className={`inline-flex items-center rounded-md bg-emerald-600 text-white shadow-xs ${sizeClasses[size]}`}
        >
          {showIcon && <ShieldCheck className="w-4 h-4 shrink-0" />}
          <span>COMPLIANT</span>
        </span>
      );

    case 'NEEDS_REVIEW':
      return (
        <span
          id={`badge-needs-review-${size}`}
          className={`inline-flex items-center rounded-md bg-amber-500 text-slate-950 font-bold shadow-xs ${sizeClasses[size]}`}
        >
          {showIcon && <Clock className="w-4 h-4 text-slate-950 shrink-0" />}
          <span>NEEDS REVIEW</span>
        </span>
      );

    case 'NON_COMPLIANT':
      return (
        <span
          id={`badge-non-compliant-${size}`}
          className={`inline-flex items-center rounded-md bg-rose-600 text-white shadow-xs ${sizeClasses[size]}`}
        >
          {showIcon && <ShieldAlert className="w-4 h-4 shrink-0" />}
          <span>NON-COMPLIANT</span>
        </span>
      );

    default:
      return (
        <span className={`inline-flex items-center rounded-md bg-slate-100 text-slate-700 border border-slate-200 ${sizeClasses[size]}`}>
          {status}
        </span>
      );
  }
};

