import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Camera,
  Search,
  FileCheck2,
  FileSpreadsheet,
  History,
  Sun,
  Moon,
  Menu,
  X,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { ScanSureLogo } from './ScanSureLogo';
import { PWAInstallButton } from './PWAInstallButton';

export type ActiveScreen =
  | 'DASHBOARD'
  | 'SCANNER'
  | 'ANALYSIS'
  | 'REVIEW'
  | 'REPORT'
  | 'HISTORY';

interface NavbarProps {
  activeScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
  currentInspectionId?: string;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeScreen,
  onNavigate,
  currentInspectionId,
  isDarkMode,
  onToggleDarkMode,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Close drawer on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMenuOpen) {
        setIsMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMenuOpen]);

  // Lock body scrolling when drawer is open on mobile
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  const navItems = [
    {
      id: 'DASHBOARD' as ActiveScreen,
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Compliance metrics, KPIs & batch overview',
    },
    {
      id: 'SCANNER' as ActiveScreen,
      label: 'Scanner',
      icon: Camera,
      description: 'Real-time camera & high-speed barcode decode',
      isLive: true,
    },
    {
      id: 'ANALYSIS' as ActiveScreen,
      label: 'Evidence',
      icon: Search,
      description: 'OCR detection coordinates & confidence map',
    },
    {
      id: 'REVIEW' as ActiveScreen,
      label: 'Review',
      icon: FileCheck2,
      description: 'Mandatory PCR 2011 checklist & sign-off',
    },
    {
      id: 'REPORT' as ActiveScreen,
      label: 'Report',
      icon: FileSpreadsheet,
      description: 'Statutory certificate & formal PDF print',
    },
    {
      id: 'HISTORY' as ActiveScreen,
      label: 'History',
      icon: History,
      description: 'Audit trails & historical inspection logs',
    },
  ];

  const handleSelectItem = (id: ActiveScreen) => {
    onNavigate(id);
    setIsMenuOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* ScanSure Brand Logo */}
            <div
              className="flex items-center cursor-pointer transition transform hover:opacity-90 active:scale-95"
              onClick={() => onNavigate('DASHBOARD')}
              id="brand-logo-btn"
            >
              <ScanSureLogo size="md" />
            </div>

            {/* Right Corner: Controls & 3-Lines Corner Menu Button */}
            <div className="flex items-center gap-2">
              {/* PWA In-App Install Button */}
              <PWAInstallButton variant="compact" />

              {/* Dark Mode Toggle */}
              <button
                type="button"
                id="theme-toggle-btn"
                onClick={onToggleDarkMode}
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                aria-label="Toggle theme"
              >
                {isDarkMode ? (
                  <Sun className="w-4 h-4 text-amber-400" />
                ) : (
                  <Moon className="w-4 h-4 text-slate-700" />
                )}
              </button>

              {/* 3-Lines Corner Side Menu Button (☰) */}
              <button
                type="button"
                id="corner-menu-btn"
                onClick={() => setIsMenuOpen((prev) => !prev)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border transition-all transform active:scale-95 cursor-pointer ${
                  isMenuOpen
                    ? 'bg-slate-900 text-white border-slate-900 dark:bg-emerald-600 dark:border-emerald-600 shadow-md'
                    : 'text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border-slate-200 dark:border-slate-700 shadow-2xs'
                }`}
                aria-label={isMenuOpen ? 'Close Navigation Menu' : 'Open 3-Lines Navigation Menu'}
                title="Navigation Menu (3 lines)"
              >
                {isMenuOpen ? (
                  <X className="w-4 h-4 text-white" />
                ) : (
                  <Menu className="w-4 h-4 text-slate-800 dark:text-slate-100" />
                )}
                <span className="hidden sm:inline text-xs font-bold tracking-tight">Menu</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Slide-over Side Drawer from the Corner */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
            onClick={() => setIsMenuOpen(false)}
            aria-hidden="true"
          />

          {/* Drawer Panel in the Corner */}
          <aside
            id="corner-navigation-drawer"
            className="relative w-full max-w-sm sm:max-w-md h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-250 ease-out"
            role="dialog"
            aria-modal="true"
            aria-label="Navigation Menu"
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                  <Menu className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                    Navigation Menu
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    PCR 2011 Inspection Terminal
                  </p>
                </div>
              </div>

              <button
                type="button"
                id="close-corner-menu-btn"
                onClick={() => setIsMenuOpen(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Active Record Callout (if active inspection exists) */}
            {currentInspectionId && (
              <div className="mx-5 mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 overflow-hidden">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span className="text-xs text-slate-600 dark:text-slate-300 truncate">
                    Active: <strong className="text-slate-900 dark:text-white font-mono">{currentInspectionId}</strong>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleSelectItem('ANALYSIS')}
                  className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline shrink-0 cursor-pointer"
                >
                  View
                </button>
              </div>
            )}

            {/* Navigation Items List (Transferred from header tabs) */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-2">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 mb-2">
                Select View
              </div>

              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeScreen === item.id;
                const isCamera = item.id === 'SCANNER';

                return (
                  <button
                    key={item.id}
                    id={`nav-item-${item.id.toLowerCase()}`}
                    onClick={() => handleSelectItem(item.id)}
                    className={`w-full group flex items-start gap-3.5 p-3 rounded-xl transition-all text-left cursor-pointer border ${
                      isActive
                        ? 'bg-slate-900 text-white dark:bg-emerald-600 dark:text-white border-transparent shadow-sm'
                        : isCamera
                        ? 'bg-emerald-50/70 dark:bg-emerald-950/30 text-slate-800 dark:text-slate-100 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border-emerald-200/70 dark:border-emerald-800/60'
                        : 'bg-white dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-800'
                    }`}
                  >
                    <div
                      className={`p-2 rounded-lg shrink-0 transition-colors ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : isCamera
                          ? 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-white'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold leading-none">
                          {item.label}
                        </span>
                        {item.isLive && (
                          <span
                            className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"
                            title="Live camera stream active"
                          />
                        )}
                        {isActive && (
                          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-white/20 text-white ml-auto">
                            Active
                          </span>
                        )}
                      </div>
                      <p
                        className={`text-xs mt-1 leading-snug line-clamp-1 ${
                          isActive
                            ? 'text-slate-300 dark:text-emerald-100'
                            : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {item.description}
                      </p>
                    </div>

                    {!isActive && (
                      <ChevronRight className="w-4 h-4 text-slate-400 dark:text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity self-center shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Drawer Footer Actions */}
            <div className="p-5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70 space-y-3">
              {/* PWA Install Button in Drawer */}
              <PWAInstallButton variant="full" />

              <button
                type="button"
                id="drawer-new-scan-btn"
                onClick={() => handleSelectItem('SCANNER')}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition transform active:scale-95 cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span>Start New Package Scan</span>
              </button>

              <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                <span>ScanSure Legal Metrology</span>
                <button
                  type="button"
                  onClick={onToggleDarkMode}
                  className="hover:text-slate-900 dark:hover:text-white font-medium underline underline-offset-2 cursor-pointer"
                >
                  {isDarkMode ? 'Switch to Light' : 'Switch to Dark'}
                </button>
              </div>
            </div>
          </aside>
        </div>
      )}
    </>
  );
};

