import React, { useEffect } from 'react';
import {
  LayoutDashboard,
  Camera,
  Search,
  FileCheck2,
  FileSpreadsheet,
  History,
  X,
  Sparkles,
  Sun,
  Moon,
  ShieldCheck,
} from 'lucide-react';
import { ActiveScreen } from './Navbar';
import { ScanSureLogo } from './ScanSureLogo';
import { PWAInstallButton } from './PWAInstallButton';
import { InspectionRecord } from '../types/inspection';

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
  currentInspection: InspectionRecord | null;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  isOpen,
  onClose,
  activeScreen,
  onNavigate,
  currentInspection,
  isDarkMode,
  onToggleDarkMode,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const navItems = [
    {
      id: 'DASHBOARD' as ActiveScreen,
      label: 'Dashboard Overview',
      icon: LayoutDashboard,
      desc: 'Batch compliance KPIs & metrics',
    },
    {
      id: 'SCANNER' as ActiveScreen,
      label: 'Package Scanner',
      icon: Camera,
      desc: 'Live camera & high-speed barcode decode',
      isLive: true,
    },
    {
      id: 'ANALYSIS' as ActiveScreen,
      label: 'OCR Evidence Map',
      icon: Search,
      desc: 'Confidence scores & spatial bounding boxes',
    },
    {
      id: 'REVIEW' as ActiveScreen,
      label: 'Compliance Review',
      icon: FileCheck2,
      desc: 'PCR 2011 mandatory declaration checklist',
    },
    {
      id: 'REPORT' as ActiveScreen,
      label: 'Certificates & PDF',
      icon: FileSpreadsheet,
      desc: 'Statutory metrology certificate output',
    },
    {
      id: 'HISTORY' as ActiveScreen,
      label: 'Audit History',
      icon: History,
      desc: 'Past inspections & lot records',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer Panel */}
      <aside
        className="relative w-full max-w-xs sm:max-w-sm h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-250 ease-out"
        role="dialog"
        aria-modal="true"
        aria-label="Navigation Drawer"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <ScanSureLogo size="sm" />
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Active Inspection Widget */}
        {currentInspection && (
          <div className="mx-4 mt-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-2">
            <div className="truncate">
              <span className="text-[11px] text-slate-400">Current Record</span>
              <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                {currentInspection.commodityName}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                onNavigate('ANALYSIS');
                onClose();
              }}
              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shrink-0 cursor-pointer"
            >
              View
            </button>
          </div>
        )}

        {/* Navigation Items */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 py-1">
            Workspaces
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            const isScanner = item.id === 'SCANNER';

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full flex items-start gap-3 p-2.5 rounded-xl transition text-left cursor-pointer border ${
                  isActive
                    ? 'bg-slate-900 text-white dark:bg-emerald-600 dark:text-white border-transparent'
                    : isScanner
                    ? 'bg-emerald-50/70 dark:bg-emerald-950/30 text-slate-800 dark:text-slate-100 border-emerald-200/70 dark:border-emerald-800/60'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border-transparent'
                }`}
              >
                <div
                  className={`p-2 rounded-lg shrink-0 ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : isScanner
                      ? 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold leading-tight flex items-center gap-1.5">
                    <span>{item.label}</span>
                    {item.isLive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    )}
                  </div>
                  <p
                    className={`text-[11px] mt-0.5 truncate ${
                      isActive
                        ? 'text-slate-300 dark:text-emerald-100'
                        : 'text-slate-400 dark:text-slate-500'
                    }`}
                  >
                    {item.desc}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 space-y-2.5">
          <PWAInstallButton variant="full" />

          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-1 px-1">
            <span>Theme</span>
            <button
              type="button"
              onClick={onToggleDarkMode}
              className="flex items-center gap-1.5 font-medium text-slate-800 dark:text-slate-200 hover:underline cursor-pointer"
            >
              {isDarkMode ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Light Mode</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-600" />
                  <span>Dark Mode</span>
                </>
              )}
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
};
