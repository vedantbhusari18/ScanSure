import React, { useState } from 'react';
import { ExtractedField, InspectionRecord, MVPFieldKey } from '../types/inspection';
import { StatusBadge } from './StatusBadge';
import { BatchStatusBadge } from './BatchStatusBadge';
import { EvidenceImageViewer } from './EvidenceImageViewer';
import { LEGAL_RULES_CONFIG } from '../rules/rulesConfig';
import {
  FileCheck2,
  FileSpreadsheet,
  Info,
  ChevronRight,
  ArrowRight,
  HelpCircle,
  RotateCcw,
  QrCode,
  Barcode,
  ExternalLink,
  Globe,
  Tag,
} from 'lucide-react';

interface AnalysisEvidenceViewProps {
  inspection: InspectionRecord;
  onProceedToReview: () => void;
  onProceedToReport: () => void;
  onRescan: () => void;
}

export const AnalysisEvidenceView: React.FC<AnalysisEvidenceViewProps> = ({
  inspection,
  onProceedToReview,
  onProceedToReport,
  onRescan,
}) => {
  const [selectedFieldKey, setSelectedFieldKey] = useState<MVPFieldKey | null>('mrp');

  const fieldKeys: MVPFieldKey[] = [
    'mrp',
    'netQuantity',
    'manufacturer',
    'genericName',
    'dateInfo',
    'consumerCare',
    'unitSalePrice',
  ];

  const allFields = Object.values(inspection.fields) as ExtractedField[];
  const fieldStats = {
    found: allFields.filter((f) => f.status === 'FOUND').length,
    review: allFields.filter((f) => f.status === 'REVIEW').length,
    missing: allFields.filter((f) => f.status === 'MISSING').length,
  };

  const activeField = selectedFieldKey ? inspection.fields[selectedFieldKey] : null;
  const activeRule = selectedFieldKey ? LEGAL_RULES_CONFIG[selectedFieldKey] : null;

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner with Verdict and Quick Summary */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="text-[11px] font-mono font-bold text-slate-400 uppercase">Audit ID:</span>
            <span className="text-xs font-mono text-slate-900 dark:text-slate-100 font-bold bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
              {inspection.id}
            </span>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <span className="text-xs text-slate-700 dark:text-slate-300 font-bold">{inspection.commodityName}</span>
            <span className="text-slate-400 text-xs">({inspection.brandName})</span>
            {inspection.batchNumber && (
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                Batch: {inspection.batchNumber}
              </span>
            )}
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <StatusBadge status={inspection.overallVerdict} size="lg" />
            <BatchStatusBadge status={inspection.batchStatus} size="md" />
            <div className="text-xs text-slate-600 dark:text-slate-400">
              Statutory Compliance Index:{' '}
              <strong className="text-slate-900 dark:text-white text-sm font-mono">{inspection.complianceScore}%</strong>
            </div>
          </div>
        </div>

        {/* Counts summary pills */}
        <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800/80 p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-mono">
          <div className="px-2.5 py-1 rounded-md bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-bold">
            {fieldStats.found} FOUND
          </div>
          <div className="px-2.5 py-1 rounded-md bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-300 font-bold">
            {fieldStats.review} REVIEW
          </div>
          <div className="px-2.5 py-1 rounded-md bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 font-bold">
            {fieldStats.missing} MISSING
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="proceed-review-btn"
            onClick={onProceedToReview}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition"
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Officer Review</span>
          </button>
          <button
            type="button"
            id="proceed-report-btn"
            onClick={onProceedToReport}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 text-xs font-semibold shadow-xs transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Notice PDF</span>
          </button>
        </div>
      </div>

      {/* SIH Trust Rule Notice Callout */}
      {fieldStats.review > 0 && (
        <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-start gap-3 text-xs text-amber-900 dark:text-amber-300 shadow-xs">
          <HelpCircle className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong className="font-bold text-amber-950 dark:text-amber-200">Statutory Trust Rule Activated: </strong>
            One or more declarations (e.g. Consumer Care helpline) contain unreadable or smudged print. Under Legal Metrology inspection guidelines, this is designated{' '}
            <span className="font-bold text-amber-950 dark:text-amber-100 underline decoration-amber-400">"Unable to verify" (REVIEW)</span> for physical scrutiny rather than imposing immediate statutory fines on manufacturers.
          </div>
        </div>
      )}

      {/* Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Evidence Viewer Canvas (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <EvidenceImageViewer
            imageUrl={inspection.imageUrl}
            fields={inspection.fields}
            selectedFieldKey={selectedFieldKey}
            onSelectField={(key) => setSelectedFieldKey(key)}
            productTitle={inspection.commodityName}
          />

          {/* Quick instructions */}
          <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between px-1">
            <span>Click any bounding box on the package or declaration row to highlight.</span>
            <button
              type="button"
              onClick={onRescan}
              className="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white font-semibold underline cursor-pointer"
            >
              Rescan Package
            </button>
          </div>
        </div>

        {/* Right Column: 7 Statutory Fields Table & Detailed Inspector Panel (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          {/* Decoded Barcode / Packaging Code Card if available */}
          {inspection.barcodeData && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                    {inspection.barcodeData.format.includes('QR') ? (
                      <QrCode className="w-3.5 h-3.5" />
                    ) : (
                      <Barcode className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase font-mono">
                      Decoded Packaging Code ({inspection.barcodeData.format})
                    </h3>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">Statutory E-Commerce &amp; Traceability Code</p>
                  </div>
                </div>

                {inspection.barcodeData.url && (
                  <a
                    href={inspection.barcodeData.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold shadow-xs transition"
                  >
                    <span>Open URL</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

              <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 font-mono text-xs text-slate-900 dark:text-slate-100 break-all select-all font-semibold">
                {inspection.barcodeData.rawValue}
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                {inspection.barcodeData.mrp && (
                  <div className="p-2 rounded bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200">
                    <span className="text-[10px] uppercase font-mono text-amber-800 dark:text-amber-400 font-bold block">Max Retail Price (MRP)</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 block">{inspection.barcodeData.mrp}</span>
                  </div>
                )}

                {inspection.barcodeData.dmartPrice && (
                  <div className="p-2 rounded bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200">
                    <span className="text-[10px] uppercase font-mono text-emerald-800 dark:text-emerald-400 font-bold block">D-Mart Price</span>
                    <span className="font-mono font-bold text-emerald-950 dark:text-emerald-300 mt-0.5 block">{inspection.barcodeData.dmartPrice}</span>
                  </div>
                )}

                {inspection.barcodeData.lotNumber && (
                  <div className="p-2 rounded bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800 text-cyan-900 dark:text-cyan-200">
                    <span className="text-[10px] uppercase font-mono text-cyan-800 dark:text-cyan-400 font-bold block">Lot / Batch Number</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 block">{inspection.barcodeData.lotNumber}</span>
                  </div>
                )}

                {inspection.barcodeData.netQuantity && (
                  <div className="p-2 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-200">
                    <span className="text-[10px] uppercase font-mono text-slate-600 dark:text-slate-400 font-bold block">Net Quantity</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 block">{inspection.barcodeData.netQuantity}</span>
                  </div>
                )}

                {inspection.barcodeData.countryOfOrigin && (
                  <div className="p-2 rounded bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200">
                    <span className="text-[10px] uppercase font-mono text-amber-800 dark:text-amber-400 font-bold block">Origin / GS1 Prefix</span>
                    <span className="font-semibold text-slate-900 dark:text-white flex items-center gap-1 mt-0.5">
                      <Globe className="w-3 h-3 text-amber-600" />
                      <span>{inspection.barcodeData.countryOfOrigin}</span>
                    </span>
                  </div>
                )}

                {inspection.barcodeData.gtin && (
                  <div className="p-2 rounded bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200">
                    <span className="text-[10px] uppercase font-mono text-blue-800 dark:text-blue-400 font-bold block">GTIN / Article #</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 block">{inspection.barcodeData.gtin}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Field Selection Cards */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                7 Mandatory Declarations (Rule 6 Matrix)
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Click row for evidence</span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {fieldKeys.map((key) => {
                const field = inspection.fields[key];
                const isSelected = selectedFieldKey === key;
                return (
                  <div
                    key={key}
                    id={`field-row-${key}`}
                    onClick={() => setSelectedFieldKey(key)}
                    className={`p-3.5 flex items-center justify-between cursor-pointer transition ${
                      isSelected
                        ? 'bg-slate-50 dark:bg-slate-800 border-l-4 border-emerald-500 pl-3'
                        : 'hover:bg-slate-50/70 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="space-y-1 min-w-0 pr-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-white">{field.fieldName}</span>
                        <StatusBadge status={field.status} size="sm" />
                      </div>
                      <div className="text-xs text-slate-700 dark:text-slate-300 font-mono font-medium truncate">
                        {field.cleanedValue || field.rawValue || (
                          <span className="text-rose-600 dark:text-rose-400 italic">[Declaration omitted from package]</span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 font-sans">
                        {field.ruleReference}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <div className="text-xs font-mono font-bold text-slate-900 dark:text-white">
                          {Math.round(field.confidence * 100)}%
                        </div>
                        <div className="text-[10px] text-slate-400">Confidence</div>
                      </div>
                      <ChevronRight
                        className={`w-4 h-4 text-slate-400 transition ${
                          isSelected ? 'text-emerald-500 translate-x-0.5' : ''
                        }`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detailed Evidence & Rule Explanation Inspector Box */}
          {activeField && activeRule && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <Info className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    Statutory Detail: {activeField.fieldName}
                  </h4>
                </div>
                <StatusBadge status={activeField.status} size="sm" />
              </div>

              {/* Evidence Snippet */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">Extracted Text Evidence:</span>
                <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-800 dark:text-slate-200 break-all font-medium">
                  "{activeField.evidenceSnippet || activeField.rawValue || 'No matching textual declaration found'}"
                </div>
              </div>

              {/* Legal Reference & Rule Explanation */}
              <div className="space-y-1 text-xs">
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">PCR 2011 Mandate:</span>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-xs">{activeField.ruleExplanation}</p>
                <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-mono font-semibold pt-1">
                  {activeRule.legalActReference}
                </div>
              </div>

              {/* Trust Note */}
              {activeField.trustNote && (
                <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-300 space-y-1">
                  <span className="font-bold block text-amber-950 dark:text-amber-200">Trust Rule Action:</span>
                  <p>{activeField.trustNote}</p>
                </div>
              )}

              {/* Bounding Box Coordinates */}
              {activeField.boundingBox && (
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                  <span>Coordinates:</span>
                  <span>
                    X: {activeField.boundingBox.x.toFixed(1)}% | Y: {activeField.boundingBox.y.toFixed(1)}% | W: {activeField.boundingBox.width.toFixed(1)}% | H: {activeField.boundingBox.height.toFixed(1)}%
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Forward Button */}
          <button
            type="button"
            onClick={onProceedToReview}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs flex items-center justify-center gap-2 transition"
          >
            <span>Proceed to Officer Compliance Review</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
