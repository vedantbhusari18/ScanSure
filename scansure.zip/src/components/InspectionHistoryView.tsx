import React, { useState, useMemo } from 'react';
import { InspectionRecord, ExtractedField } from '../types/inspection';
import { StatusBadge } from './StatusBadge';
import { BatchStatusBadge } from './BatchStatusBadge';
import { generateCompliancePdf } from '../services/pdfGenerator';
import {
  History,
  Search,
  Filter,
  Download,
  Trash2,
  ExternalLink,
  PlusCircle,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

interface InspectionHistoryViewProps {
  inspections: InspectionRecord[];
  onSelectInspection: (record: InspectionRecord) => void;
  onDeleteInspection: (id: string) => void;
  onNewScan: () => void;
  onReload100Demo?: () => void;
}

export const InspectionHistoryView: React.FC<InspectionHistoryViewProps> = ({
  inspections,
  onSelectInspection,
  onDeleteInspection,
  onNewScan,
  onReload100Demo,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 20;

  const filtered = useMemo(() => {
    return inspections.filter((item) => {
      const term = searchTerm.toLowerCase();
      const matchesSearch =
        item.commodityName.toLowerCase().includes(term) ||
        item.brandName.toLowerCase().includes(term) ||
        item.id.toLowerCase().includes(term) ||
        (item.batchNumber && item.batchNumber.toLowerCase().includes(term)) ||
        (item.batchStatus && item.batchStatus.toLowerCase().includes(term));

      const matchesStatus =
        statusFilter === 'ALL' ||
        item.overallVerdict === statusFilter ||
        item.batchStatus === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [inspections, searchTerm, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  // Counts for filters
  const counts = useMemo(() => {
    return {
      all: inspections.length,
      compliant: inspections.filter((i) => i.overallVerdict === 'COMPLIANT').length,
      review: inspections.filter((i) => i.overallVerdict === 'NEEDS_REVIEW').length,
      violation: inspections.filter((i) => i.overallVerdict === 'NON_COMPLIANT').length,
      hold: inspections.filter((i) => i.batchStatus === 'HOLD').length,
    };
  }, [inspections]);

  const handleDownloadPdf = (record: InspectionRecord, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const doc = generateCompliancePdf(record);
      doc.save(`ScanSure-Report-${record.id}.pdf`);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this inspection audit record?')) {
      onDeleteInspection(id);
    }
  };

  return (
    <div className="space-y-5 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Inspection Audit History
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
              {inspections.length} Packages Recorded
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Complete statutory ledger of inspected packaged commodities, declarations, and legal metrology status.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          <button
            type="button"
            onClick={onNewScan}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Scan</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search commodity, brand, batch no, or audit ID..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white placeholder-slate-400 outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <span className="text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Filter:
          </span>
          {[
            { key: 'ALL', label: `All (${counts.all})` },
            { key: 'COMPLIANT', label: `Compliant (${counts.compliant})` },
            { key: 'NEEDS_REVIEW', label: `Review Queue (${counts.review})` },
            { key: 'NON_COMPLIANT', label: `Violations (${counts.violation})` },
            { key: 'HOLD', label: `Hold (${counts.hold})` },
          ].map(({ key, label }) => (
            <button
              key={key}
              type="button"
              onClick={() => {
                setStatusFilter(key);
                setCurrentPage(1);
              }}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                statusFilter === key
                  ? 'bg-slate-900 dark:bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-slate-500 dark:text-slate-400 text-xs">
            No inspection records match your search query.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                  <th className="py-3 px-4">Audit ID</th>
                  <th className="py-3 px-4">Commodity / Brand</th>
                  <th className="py-3 px-4">Batch Status</th>
                  <th className="py-3 px-4">Verdict</th>
                  <th className="py-3 px-4">Score</th>
                  <th className="py-3 px-4">Declarations</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paginatedItems.map((item) => {
                  const fieldsArr = Object.values(item.fields) as ExtractedField[];
                  const missingCount = fieldsArr.filter((f) => f.status === 'MISSING').length;
                  const reviewCount = fieldsArr.filter((f) => f.status === 'REVIEW').length;
                  const passCount = fieldsArr.filter((f) => f.status === 'FOUND').length;

                  return (
                    <tr
                      key={item.id}
                      onClick={() => onSelectInspection(item)}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">
                        {item.id}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {item.commodityName}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 flex-wrap">
                          <span>{item.brandName}</span>
                          <span>•</span>
                          <span className="font-mono text-[10px] text-emerald-600 dark:text-emerald-400">
                            {item.batchNumber || 'N/A'}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <BatchStatusBadge status={item.batchStatus} />
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge status={item.overallVerdict} />
                      </td>
                      <td className="py-3 px-4 font-mono font-bold">
                        <span
                          className={
                            item.complianceScore >= 90
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : item.complianceScore >= 70
                              ? 'text-amber-600 dark:text-amber-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }
                        >
                          {item.complianceScore}%
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1 font-mono text-[11px]">
                          <span className="text-emerald-600 dark:text-emerald-400 font-bold" title="Found">
                            {passCount}✓
                          </span>
                          {reviewCount > 0 && (
                            <span className="text-amber-500 font-bold ml-1" title="Review">
                              {reviewCount}?
                            </span>
                          )}
                          {missingCount > 0 && (
                            <span className="text-rose-500 font-bold ml-1" title="Missing">
                              {missingCount}✗
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-500 dark:text-slate-400 font-mono text-[11px] whitespace-nowrap">
                        {new Date(item.scannedAt).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => handleDownloadPdf(item, e)}
                            className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition cursor-pointer"
                            title="Download Report PDF"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleDelete(item.id, e)}
                            className="p-1.5 rounded-md hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition cursor-pointer"
                            title="Delete Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onSelectInspection(item)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition ml-1 cursor-pointer"
                          >
                            <span>Inspect</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Footer */}
        {filtered.length > 0 && (
          <div className="px-4 py-3 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs bg-slate-50/50 dark:bg-slate-800/30">
            <span className="text-slate-500 dark:text-slate-400">
              Showing <strong className="font-mono text-slate-900 dark:text-white">{(currentPage - 1) * pageSize + 1}</strong> to{' '}
              <strong className="font-mono text-slate-900 dark:text-white">
                {Math.min(currentPage * pageSize, filtered.length)}
              </strong>{' '}
              of <strong className="font-mono text-slate-900 dark:text-white">{filtered.length}</strong> matching packages ({inspections.length} total)
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition"
                aria-label="Previous Page"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <span className="font-mono text-xs text-slate-700 dark:text-slate-300 px-2">
                Page {currentPage} of {totalPages}
              </span>

              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition"
                aria-label="Next Page"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
