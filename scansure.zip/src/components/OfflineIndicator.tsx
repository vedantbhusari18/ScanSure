import React from 'react';
import { WifiOff, AlertCircle } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-16 sm:bottom-6 left-4 right-4 sm:right-auto sm:max-w-md z-50 flex items-center gap-3 rounded-xl bg-amber-600 text-white px-4 py-2.5 text-xs font-medium shadow-xl border border-amber-400/40 backdrop-blur-md animate-in slide-in-from-bottom duration-300"
    >
      <div className="p-1 rounded-md bg-amber-700/60 shrink-0">
        <WifiOff className="w-4 h-4 text-amber-100 animate-pulse" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-bold text-white leading-tight">Offline Mode Active</p>
        <p className="text-[11px] text-amber-100/90 leading-tight truncate">
          Inspections &amp; cached rules will sync when reconnected.
        </p>
      </div>
      <span className="w-2 h-2 rounded-full bg-amber-200 shrink-0 animate-ping" />
    </div>
  );
};
