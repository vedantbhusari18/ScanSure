import React, { useState } from 'react';
import { ExtractedField, FieldStatus, InspectionRecord, MVPFieldKey, BatchStatus } from '../types/inspection';
import { StatusBadge } from './StatusBadge';
import { BatchStatusBadge } from './BatchStatusBadge';
import { computeOverallVerdict } from '../rules/ruleEngine';
import {
  FileCheck2,
  CheckCircle2,
  Edit3,
  AlertTriangle,
  RotateCcw,
  Save,
  ArrowRight,
  ShieldCheck,
  UserCheck,
  Building,
} from 'lucide-react';

interface ComplianceReviewViewProps {
  inspection: InspectionRecord;
  onSaveReview: (updatedRecord: InspectionRecord) => void;
  onProceedToReport: () => void;
  onRescan: () => void;
}

export const ComplianceReviewView: React.FC<ComplianceReviewViewProps> = ({
  inspection,
  onSaveReview,
  onProceedToReport,
  onRescan,
}) => {
  const [fields, setFields] = useState<Record<MVPFieldKey, ExtractedField>>(inspection.fields);
  const [batchStatus, setBatchStatus] = useState<BatchStatus>(inspection.batchStatus || 'RELEASED');
  const [officerRemarks, setOfficerRemarks] = useState<string>(
    inspection.officerRemarks ||
      'Verified automated scan findings. Unit Sale Price absence confirmed on retail pack. Consumer care contact smudged. Section 36 Notice recommended.'
  );
  const [officerName, setOfficerName] = useState<string>(inspection.officerName || 'Inspector Rajesh Varma');
  const [officerDesignation, setOfficerDesignation] = useState<string>(
    inspection.officerDesignation || 'Legal Metrology Inspector, Grade-I'
  );
  const [location, setLocation] = useState<string>(inspection.location || 'Central Inspection Terminal, Zone 1');
  const [activeEditingKey, setActiveEditingKey] = useState<MVPFieldKey | null>(null);
  const [manualCorrectionText, setManualCorrectionText] = useState<string>('');
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const fieldKeys: MVPFieldKey[] = [
    'mrp',
    'netQuantity',
    'manufacturer',
    'genericName',
    'dateInfo',
    'consumerCare',
    'unitSalePrice',
  ];

  // Recalculate dynamic verdict and score based on current review states
  const overall = computeOverallVerdict(fields);

  const handleStatusChange = (key: MVPFieldKey, newStatus: FieldStatus) => {
    const updated = { ...fields };
    updated[key] = {
      ...updated[key],
      status: newStatus,
      officerOverride: {
        status: newStatus,
        correctedValue: updated[key].cleanedValue,
        notes: `Officer updated status to ${newStatus}`,
        reviewedBy: officerName,
        reviewedAt: new Date().toISOString(),
      },
    };
    setFields(updated);
    setIsSaved(false);
  };

  const handleApplyCorrection = (key: MVPFieldKey) => {
    if (!manualCorrectionText.trim()) return;
    const updated = { ...fields };
    updated[key] = {
      ...updated[key],
      status: 'FOUND',
      cleanedValue: manualCorrectionText.trim(),
      confidence: 1.0,
      trustNote: 'Officer verified and manually corrected declaration value.',
      officerOverride: {
        status: 'FOUND',
        correctedValue: manualCorrectionText.trim(),
        notes: 'Manual officer transcription override',
        reviewedBy: officerName,
        reviewedAt: new Date().toISOString(),
      },
    };
    setFields(updated);
    setActiveEditingKey(null);
    setManualCorrectionText('');
    setIsSaved(false);
  };

  const handleSaveAll = () => {
    const updatedRecord: InspectionRecord = {
      ...inspection,
      fields,
      batchStatus,
      overallVerdict: overall.verdict,
      complianceScore: overall.complianceScore,
      officerRemarks,
      officerName,
      officerDesignation,
      location,
      status: 'REVIEWED',
      updatedAt: new Date().toISOString(),
    };

    onSaveReview(updatedRecord);
    setIsSaved(true);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <UserCheck className="w-4 h-4 text-slate-700 dark:text-slate-300" />
            <span className="text-xs font-mono font-bold text-slate-400">AUDIT ID</span>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <span className="text-xs font-mono font-bold text-slate-800 dark:text-slate-200">{inspection.id}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            Compliance Review
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Verification, transcription correction, and batch authorization.
          </p>
        </div>

        <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/70 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
          <div className="text-right">
            <div className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold">Current Verdict</div>
            <StatusBadge status={overall.verdict} size="md" />
          </div>
          <div className="text-right pl-3 border-l border-slate-200 dark:border-slate-700">
            <div className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold">Score</div>
            <div className="text-xl font-mono font-extrabold text-slate-900 dark:text-white">{overall.complianceScore}%</div>
          </div>
        </div>
      </div>

      {/* Batch Status Authorization Control */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider font-mono">
            Batch Status:
          </span>
          <BatchStatusBadge status={batchStatus} size="md" />
          {inspection.batchNumber && (
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
              ({inspection.batchNumber})
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {(['RELEASED', 'HOLD', 'INSPECTION', 'RECALLED'] as BatchStatus[]).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => {
                setBatchStatus(st);
                setIsSaved(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 border ${
                batchStatus === st
                  ? st === 'RELEASED'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : st === 'HOLD'
                    ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                    : st === 'INSPECTION'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-rose-600 text-white border-rose-600 shadow-xs'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              <span>
                {st === 'RELEASED' && '✓ Release Batch'}
                {st === 'HOLD' && '⚠ Quality Hold'}
                {st === 'INSPECTION' && '🔍 In Inspection'}
                {st === 'RECALLED' && '✕ Recall Batch'}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Review Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs">
        <div className="text-xs text-slate-600 dark:text-slate-400">
          <strong className="text-slate-900 dark:text-slate-100 font-semibold">Trust Verification Protocol:</strong> Toggle field status or transcribe degraded print to resolve "Unable to verify" statuses.
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onRescan}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Rescan</span>
          </button>

          <button
            type="button"
            id="save-review-btn"
            onClick={handleSaveAll}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-bold shadow-xs transition"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaved ? 'Changes Saved' : 'Save Review'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              handleSaveAll();
              onProceedToReport();
            }}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition"
          >
            <span>Notice PDF</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 7 Statutory Declarations Review Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Mandatory Declarations Review (PCR 2011, Rule 6)
          </span>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">7 Statutory Fields</span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {fieldKeys.map((key) => {
            const field = fields[key];
            const isEditing = activeEditingKey === key;

            return (
              <div key={key} className="p-4 space-y-3 hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 dark:text-white">{field.fieldName}</span>
                      <span className="text-[10px] font-mono text-slate-400">{field.ruleReference}</span>
                    </div>
                    <div className="text-xs text-slate-700 dark:text-slate-300 font-mono font-medium">
                      {field.cleanedValue || field.rawValue || (
                        <span className="text-rose-600 dark:text-rose-400 italic">[Declaration Missing from Label]</span>
                      )}
                    </div>
                  </div>

                  {/* Status toggle buttons */}
                  <div className="flex items-center gap-1.5 self-start sm:self-auto bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                    <button
                      type="button"
                      onClick={() => handleStatusChange(key, 'FOUND')}
                      className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                        field.status === 'FOUND'
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      FOUND
                    </button>
                    <button
                      type="button"
                      onClick={() => handleStatusChange(key, 'REVIEW')}
                      className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                        field.status === 'REVIEW'
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-2xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      REVIEW
                    </button>
                    <button
                      type="button"
                      onClick={() => handleStatusChange(key, 'MISSING')}
                      className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                        field.status === 'MISSING'
                          ? 'bg-rose-600 text-white shadow-2xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      MISSING
                    </button>
                  </div>
                </div>

                {/* Extracted evidence display & inline edit toggle */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                  <div className="text-slate-600 dark:text-slate-400">
                    <span className="font-bold text-slate-500 uppercase text-[10px] mr-1">OCR Evidence:</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200">
                      "{field.evidenceSnippet || field.rawValue || 'N/A'}"
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (isEditing) {
                        setActiveEditingKey(null);
                      } else {
                        setActiveEditingKey(key);
                        setManualCorrectionText(field.cleanedValue || field.rawValue || '');
                      }
                    }}
                    className="inline-flex items-center gap-1 text-[11px] text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white font-bold underline cursor-pointer shrink-0"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>{isEditing ? 'Cancel Edit' : 'Edit Text'}</span>
                  </button>
                </div>

                {/* Inline Manual Transcription Editor */}
                {isEditing && (
                  <div className="p-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg space-y-2">
                    <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                      Inspector Correction / Clarified Text Value:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={manualCorrectionText}
                        onChange={(e) => setManualCorrectionText(e.target.value)}
                        placeholder="Enter verified declaration text..."
                        className="flex-1 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                      <button
                        type="button"
                        onClick={() => handleApplyCorrection(key)}
                        className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Officer Attestation & Remarks Box */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
        <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
          <Building className="w-4 h-4 text-slate-600 dark:text-slate-400" />
          <span>Statutory Sign-Off &amp; Official Notice Remarks</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
              Inspecting Officer Name
            </label>
            <input
              type="text"
              value={officerName}
              onChange={(e) => setOfficerName(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
              Designation / Badge
            </label>
            <input
              type="text"
              value={officerDesignation}
              onChange={(e) => setOfficerDesignation(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
              Inspection Station
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
            />
          </div>
        </div>

        <div>
          <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
            Inspector Legal Findings &amp; Directive (Appears on Official Notice)
          </label>
          <textarea
            rows={3}
            value={officerRemarks}
            onChange={(e) => setOfficerRemarks(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-3 text-xs text-slate-900 dark:text-white outline-none focus:ring-1 focus:ring-emerald-500 leading-relaxed font-sans"
          />
        </div>
      </div>
    </div>
  );
};
