import React, { useState, useRef, useEffect, useCallback } from 'react';
import { analyzeImageQuality } from '../services/imageQuality';
import { ImageQualityMetrics, BatchStatus } from '../types/inspection';
import {
  scanBarcodeFromSource,
  playScanBeep,
  DecodedBarcode,
  parseBarcodeMetadata,
  lookupBarcodeString,
} from '../services/barcodeScanner';
import { SUPERMARKET_CATALOG, SupermarketProduct } from '../data/supermarketProducts';
import { BarcodeModal } from './BarcodeModal';
import { BarcodeSvg } from './BarcodeSvg';
import {
  Camera,
  Video,
  RotateCcw,
  QrCode,
  Barcode,
  Zap,
  ShoppingBag,
  Search,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Scan,
  Upload,
  Sliders,
  ArrowRight,
  Play,
  Square,
  X,
  Tag,
  IndianRupee,
  Layers,
  Check,
  RefreshCw,
  Image as ImageIcon,
  HelpCircle,
  Filter,
} from 'lucide-react';

interface ScannerUploadViewProps {
  onStartAnalysis: (payload: {
    imageUrl: string;
    commodityName: string;
    brandName: string;
    batchNumber: string;
    batchStatus?: BatchStatus;
    category: string;
    quality: ImageQualityMetrics;
    presetId?: string;
    rawOcrText?: string;
    barcodeData?: any;
  }) => void;
}

export const ScannerUploadView: React.FC<ScannerUploadViewProps> = ({ onStartAnalysis }) => {
  const [activeTab, setActiveTab] = useState<'REALTIME_CAMERA' | 'UPLOAD'>('REALTIME_CAMERA');
  const [imagePreview, setImagePreview] = useState<string>('');
  const [commodityName, setCommodityName] = useState<string>('');
  const [brandName, setBrandName] = useState<string>('');
  const [batchNumber, setBatchNumber] = useState<string>('');
  const [batchStatus, setBatchStatus] = useState<BatchStatus>('RELEASED');
  const [category, setCategory] = useState<string>('Packaged Food & Snacks');
  const [qualityMetrics, setQualityMetrics] = useState<ImageQualityMetrics | null>(null);

  // Real-Time Camera State
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [isConnectingCamera, setIsConnectingCamera] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [flashEffect, setFlashEffect] = useState<boolean>(false);
  const [liveTimestamp, setLiveTimestamp] = useState<string>('');
  const [frameCount, setFrameCount] = useState<number>(100);

  // Barcode & QR Code Scanner State
  const [detectedBarcode, setDetectedBarcode] = useState<DecodedBarcode | null>(null);
  const [isBarcodeModalOpen, setIsBarcodeModalOpen] = useState<boolean>(false);
  const [isBarcodeScannerActive, setIsBarcodeScannerActive] = useState<boolean>(true);
  const [lastScannedCode, setLastScannedCode] = useState<string>('');
  const [isScanningFrame, setIsScanningFrame] = useState<boolean>(false);
  const [scanSuccessGlow, setScanSuccessGlow] = useState<boolean>(false);

  // Direct Barcode Search State
  const [manualBarcodeInput, setManualBarcodeInput] = useState<string>('');
  const [isSearchingBarcode, setIsSearchingBarcode] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Live HUD timer
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setLiveTimestamp(now.toLocaleTimeString());
      setFrameCount((prev) => (prev + 1) % 99999);
    }, 120);
    return () => clearInterval(timer);
  }, []);

  // Start device camera
  const handleStartCamera = async (targetMode: 'environment' | 'user' = facingMode) => {
    try {
      setIsConnectingCamera(true);
      setCameraError(null);

      // Stop any existing tracks
      if (mediaStream) {
        mediaStream.getTracks().forEach((t) => t.stop());
        setMediaStream(null);
      }

      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: { ideal: 1920, min: 640 },
            height: { ideal: 1080, min: 480 },
            facingMode: { ideal: targetMode },
          },
          audio: false,
        });
      } catch {
        // Fallback without strict resolution constraints
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      }

      setMediaStream(stream);
      setFacingMode(targetMode);
      setIsCameraActive(true);
      setIsConnectingCamera(false);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
    } catch (err: any) {
      setIsConnectingCamera(false);
      setIsCameraActive(false);
      console.error('Camera access error:', err);
      setCameraError(
        'Could not access camera: ' +
          (err?.message || 'Please grant camera permission in your browser to scan barcodes in real time.')
      );
    }
  };

  // Stop device camera
  const handleStopCamera = useCallback(() => {
    if (mediaStream) {
      mediaStream.getTracks().forEach((track) => track.stop());
      setMediaStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setIsConnectingCamera(false);
  }, [mediaStream]);

  // Flip camera between front and rear
  const handleFlipCamera = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    handleStartCamera(nextMode);
  };

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [mediaStream]);

  // Bind video ref
  const setVideoRef = (node: HTMLVideoElement | null) => {
    videoRef.current = node;
    if (node && mediaStream) {
      if (node.srcObject !== mediaStream) {
        node.srcObject = mediaStream;
      }
      node.play().catch(() => {});
    }
  };

  // Real-time continuous Barcode & QR Code scanner loop on camera feed
  useEffect(() => {
    let scanInterval: any = null;
    let isProcessing = false;

    if (isCameraActive && isBarcodeScannerActive) {
      scanInterval = setInterval(async () => {
        if (isProcessing) return;
        isProcessing = true;
        setIsScanningFrame(true);

        try {
          const video = videoRef.current;
          if (video && (video.readyState >= 2 || (video.videoWidth > 0 && !video.paused))) {
            const decoded = await scanBarcodeFromSource(video, 'LIVE_CAMERA');

            if (decoded && decoded.rawValue) {
              setDetectedBarcode(decoded);

              // Auto-fill statutory package data immediately
              if (decoded.metadata.productName) setCommodityName(decoded.metadata.productName);
              if (decoded.metadata.brandName) setBrandName(decoded.metadata.brandName);
              if (decoded.metadata.lotNumber || decoded.metadata.batchNumber) {
                setBatchNumber(decoded.metadata.lotNumber || decoded.metadata.batchNumber || '');
              }
              if (decoded.metadata.category) setCategory(decoded.metadata.category);

              // Capture snapshot frame if none set yet
              if (!imagePreview && canvasRef.current) {
                try {
                  const canvas = canvasRef.current;
                  const w = video.videoWidth || 800;
                  const h = video.videoHeight || 600;
                  canvas.width = Math.min(w, 1280);
                  canvas.height = Math.min(h, 720);
                  const ctx = canvas.getContext('2d');
                  if (ctx) {
                    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                    setImagePreview(canvas.toDataURL('image/jpeg', 0.85));
                  }
                } catch {
                  // ignore
                }
              }

              // On new barcode detected: play audio beep and trigger visual scan flash
              if (decoded.rawValue !== lastScannedCode) {
                setLastScannedCode(decoded.rawValue);
                playScanBeep();
                if (typeof navigator !== 'undefined' && navigator.vibrate) {
                  navigator.vibrate([50, 50, 100]);
                }
                setScanSuccessGlow(true);
                setTimeout(() => setScanSuccessGlow(false), 1500);
              }
            }
          }
        } catch {
          // ignore transient frame read errors
        } finally {
          isProcessing = false;
          setTimeout(() => setIsScanningFrame(false), 100);
        }
      }, 180); // ~5-6 checks per second for ultra-fast POS checkout speed
    }

    return () => {
      if (scanInterval) clearInterval(scanInterval);
    };
  }, [isCameraActive, isBarcodeScannerActive, lastScannedCode, imagePreview]);

  // Capture current frame from live camera
  const handleCaptureCameraFrame = () => {
    setFlashEffect(true);
    setTimeout(() => setFlashEffect(false), 200);

    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const vWidth = video.videoWidth || 1280;
      const vHeight = video.videoHeight || 720;
      const maxDim = 1280;
      let targetW = vWidth;
      let targetH = vHeight;
      if (targetW > maxDim || targetH > maxDim) {
        if (targetW > targetH) {
          targetH = Math.round((targetH * maxDim) / targetW);
          targetW = maxDim;
        } else {
          targetW = Math.round((targetW * maxDim) / targetH);
          targetH = maxDim;
        }
      }
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, targetW, targetH);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setImagePreview(dataUrl);
        const quality = analyzeImageQuality(targetW, targetH, false, 'NONE');
        setQualityMetrics(quality);

        // Immediate barcode scan on captured high-resolution frame
        try {
          scanBarcodeFromSource(canvas, 'LIVE_CAMERA').then((decoded) => {
            if (decoded && decoded.rawValue) {
              setDetectedBarcode(decoded);
              playScanBeep();
            }
          });
        } catch {
          // ignore
        }
      }
    }
  };

  // Real-time scan of a specific item from the website's catalog
  const handleScanCatalogItem = (product: SupermarketProduct, triggerModal = false) => {
    playScanBeep();
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate([40, 40, 80]);
    }

    const metadata = parseBarcodeMetadata(product.barcode, 'EAN_13');
    const decoded: DecodedBarcode = {
      rawValue: product.barcode,
      format: 'EAN_13',
      timestamp: new Date().toISOString(),
      source: 'CATALOG_ITEM',
      metadata,
    };

    setDetectedBarcode(decoded);
    setLastScannedCode(product.barcode);
    setCommodityName(product.productName);
    setBrandName(product.brand);
    setBatchNumber(product.lotNumber);
    setCategory(product.category);

    // Create realistic package preview snapshot for inspection
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, 800, 600);
      ctx.fillStyle = '#1e293b';
      ctx.roundRect ? ctx.roundRect(40, 40, 720, 520, 16) : ctx.fillRect(40, 40, 720, 520);
      ctx.fill();

      // Brand & Name
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 22px system-ui, sans-serif';
      ctx.fillText(product.productName.slice(0, 45), 70, 95);

      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 15px monospace';
      ctx.fillText(`BRAND: ${product.brand} | CATEGORY: ${product.category}`, 70, 130);

      // Price block
      ctx.fillStyle = '#10b981';
      ctx.font = 'bold 24px monospace';
      ctx.fillText(`MRP: ${product.mrp} (USP: ${product.unitSalePrice})`, 70, 175);

      ctx.fillStyle = '#f59e0b';
      ctx.font = '16px monospace';
      ctx.fillText(`NET QTY: ${product.netQuantity} | LOT: ${product.lotNumber}`, 70, 215);

      ctx.fillStyle = '#a855f7';
      ctx.fillText(`MFG: ${product.mfgDate} | EXPIRY: ${product.expiryDate}`, 70, 255);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '13px monospace';
      ctx.fillText(`MFR: ${product.manufacturer.slice(0, 60)}...`, 70, 295);
      ctx.fillText(`FSSAI/LIC: ${product.fssaiOrLicense}`, 70, 325);

      // Simulated barcode box
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(70, 365, 340, 120);
      ctx.fillStyle = '#09090b';
      ctx.font = 'bold 18px monospace';
      ctx.fillText(`||| | |||| | ||| | ||| ${product.barcode}`, 90, 435);

      const generatedImg = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(generatedImg);
      const quality = analyzeImageQuality(800, 600, false, 'NONE');
      setQualityMetrics(quality);
    }

    setScanSuccessGlow(true);
    setTimeout(() => setScanSuccessGlow(false), 1500);

    if (triggerModal) {
      setIsBarcodeModalOpen(true);
    }
  };

  // Direct manual barcode lookup or scan
  const handleLookupBarcode = async (codeToLookup?: string) => {
    const raw = (codeToLookup || manualBarcodeInput).trim();
    if (!raw) return;

    setIsSearchingBarcode(true);
    try {
      const decoded = await lookupBarcodeString(raw);
      if (decoded) {
        setDetectedBarcode(decoded);
        setLastScannedCode(decoded.rawValue);
        playScanBeep();

        if (decoded.metadata.productName) setCommodityName(decoded.metadata.productName);
        if (decoded.metadata.brandName) setBrandName(decoded.metadata.brandName);
        if (decoded.metadata.lotNumber || decoded.metadata.batchNumber) {
          setBatchNumber(decoded.metadata.lotNumber || decoded.metadata.batchNumber || '');
        }
        if (decoded.metadata.category) setCategory(decoded.metadata.category);

        setIsBarcodeModalOpen(true);
      }
    } catch (err) {
      console.error('Barcode lookup error:', err);
    } finally {
      setIsSearchingBarcode(false);
    }
  };

  // Image Upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const rawResult = event.target?.result as string;
        setImagePreview(rawResult);
        const quality = analyzeImageQuality(1200, 900, false, 'NONE');
        setQualityMetrics(quality);

        // Auto-scan uploaded image for barcodes
        try {
          const tempImg = new Image();
          tempImg.onload = async () => {
            const decoded = await scanBarcodeFromSource(tempImg, 'IMAGE_UPLOAD');
            if (decoded && decoded.rawValue) {
              setDetectedBarcode(decoded);
              playScanBeep();
              if (decoded.metadata.productName) setCommodityName(decoded.metadata.productName);
              if (decoded.metadata.brandName) setBrandName(decoded.metadata.brandName);
              if (decoded.metadata.lotNumber || decoded.metadata.batchNumber) {
                setBatchNumber(decoded.metadata.lotNumber || decoded.metadata.batchNumber || '');
              }
              if (decoded.metadata.category) setCategory(decoded.metadata.category);
              setIsBarcodeModalOpen(true);
            }
          };
          tempImg.src = rawResult;
        } catch {
          // ignore
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Instant 1-second Statutory Inspection Report
  const handleInstantReport = (barcodeToUse?: DecodedBarcode) => {
    const activeBarcode = barcodeToUse || detectedBarcode;
    const finalCommodity =
      activeBarcode?.metadata?.productName ||
      commodityName.trim() ||
      (activeBarcode?.metadata?.gtin ? `GTIN-${activeBarcode.metadata.gtin}` : 'Pre-packaged Commodity');

    const finalBrand = activeBarcode?.metadata?.brandName || brandName.trim() || 'Verified Brand';
    const finalBatch =
      activeBarcode?.metadata?.lotNumber ||
      activeBarcode?.metadata?.batchNumber ||
      batchNumber.trim() ||
      `LOT-${Date.now().toString().slice(-6)}`;
    const finalCategory = activeBarcode?.metadata?.category || category.trim() || 'General FMCG';

    let finalImg = imagePreview;
    if (!finalImg) {
      const canvas = document.createElement('canvas');
      canvas.width = 800;
      canvas.height = 600;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        if (isCameraActive && videoRef.current && videoRef.current.videoWidth > 0) {
          ctx.drawImage(videoRef.current, 0, 0, 800, 600);
        } else {
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, 800, 600);
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(40, 40, 720, 520);
          ctx.fillStyle = '#f8fafc';
          ctx.font = 'bold 24px monospace';
          ctx.fillText(finalCommodity, 70, 100);
          ctx.fillStyle = '#38bdf8';
          ctx.font = 'bold 18px monospace';
          ctx.fillText(`BRAND: ${finalBrand} | LOT: ${finalBatch}`, 70, 140);
          ctx.fillStyle = '#4ade80';
          ctx.font = 'bold 22px monospace';
          ctx.fillText(`MRP: ${activeBarcode?.metadata?.mrp || '₹ 50.00'}`, 70, 180);
          ctx.fillStyle = '#94a3b8';
          ctx.font = '14px monospace';
          ctx.fillText(`BARCODE: ${activeBarcode?.rawValue || '8901030000000'} [GS1 VERIFIED]`, 70, 260);
        }
        finalImg = canvas.toDataURL('image/jpeg', 0.85);
      } else {
        finalImg = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
      }
    }

    const defaultQuality: ImageQualityMetrics = qualityMetrics || {
      score: 95,
      blurScore: 'SHARP',
      lightingQuality: 'GOOD',
      resolutionScore: 'PASS',
      framingScore: 'CENTERED',
      isReadable: true,
      warnings: [],
    };

    onStartAnalysis({
      imageUrl: finalImg,
      commodityName: finalCommodity,
      brandName: finalBrand,
      batchNumber: finalBatch,
      batchStatus: batchStatus,
      category: finalCategory,
      quality: defaultQuality,
      barcodeData: activeBarcode
        ? {
            rawValue: activeBarcode.rawValue,
            format: activeBarcode.format,
            type: activeBarcode.metadata.type,
            title: activeBarcode.metadata.title,
            gtin: activeBarcode.metadata.gtin,
            batchNumber: activeBarcode.metadata.batchNumber,
            lotNumber: activeBarcode.metadata.lotNumber,
            price: activeBarcode.metadata.price,
            mrp: activeBarcode.metadata.mrp,
            dmartPrice: activeBarcode.metadata.dmartPrice,
            netQuantity: activeBarcode.metadata.netQuantity,
            unitSalePrice: activeBarcode.metadata.unitSalePrice,
            countryOfOrigin: activeBarcode.metadata.countryOfOrigin,
            manufacturerName: activeBarcode.metadata.manufacturerName,
            productName: activeBarcode.metadata.productName,
            brandName: activeBarcode.metadata.brandName,
            category: activeBarcode.metadata.category,
            expiryDate: activeBarcode.metadata.expiryDate,
            mfgDate: activeBarcode.metadata.mfgDate,
            consumerCare: activeBarcode.metadata.consumerCare,
            fssaiOrLicense: activeBarcode.metadata.fssaiOrLicense,
            discountPercent: activeBarcode.metadata.discountPercent,
            url: activeBarcode.metadata.type === 'URL' ? activeBarcode.rawValue : undefined,
            isRealDatabaseLookup: activeBarcode.metadata.isRealDatabaseLookup,
          }
        : undefined,
    });
  };

  // Submit standard inspection form
  const handleSubmit = () => {
    let finalImg = imagePreview;
    if (!finalImg) {
      if (isCameraActive && videoRef.current && videoRef.current.videoWidth > 0 && canvasRef.current) {
        const c = canvasRef.current;
        c.width = videoRef.current.videoWidth;
        c.height = videoRef.current.videoHeight;
        c.getContext('2d')?.drawImage(videoRef.current, 0, 0);
        finalImg = c.toDataURL('image/jpeg', 0.85);
      } else {
        finalImg = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
      }
    }

    const defaultQuality: ImageQualityMetrics = qualityMetrics || {
      score: 85,
      blurScore: 'SHARP',
      lightingQuality: 'GOOD',
      resolutionScore: 'PASS',
      framingScore: 'CENTERED',
      isReadable: true,
      warnings: [],
    };

    onStartAnalysis({
      imageUrl: finalImg,
      commodityName: commodityName.trim() || 'Scanned Retail Commodity',
      brandName: brandName.trim() || 'Packer Brand',
      batchNumber: batchNumber.trim() || `LOT-${Date.now().toString().slice(-6)}`,
      batchStatus: batchStatus,
      category: category.trim() || 'Packaged Commodity',
      quality: defaultQuality,
      barcodeData: detectedBarcode
        ? {
            rawValue: detectedBarcode.rawValue,
            format: detectedBarcode.format,
            type: detectedBarcode.metadata.type,
            title: detectedBarcode.metadata.title,
            gtin: detectedBarcode.metadata.gtin,
            batchNumber: detectedBarcode.metadata.batchNumber,
            lotNumber: detectedBarcode.metadata.lotNumber,
            price: detectedBarcode.metadata.price,
            mrp: detectedBarcode.metadata.mrp,
            dmartPrice: detectedBarcode.metadata.dmartPrice,
            netQuantity: detectedBarcode.metadata.netQuantity,
            unitSalePrice: detectedBarcode.metadata.unitSalePrice,
            countryOfOrigin: detectedBarcode.metadata.countryOfOrigin,
            manufacturerName: detectedBarcode.metadata.manufacturerName,
            productName: detectedBarcode.metadata.productName,
            brandName: detectedBarcode.metadata.brandName,
            category: detectedBarcode.metadata.category,
            expiryDate: detectedBarcode.metadata.expiryDate,
            mfgDate: detectedBarcode.metadata.mfgDate,
            consumerCare: detectedBarcode.metadata.consumerCare,
            fssaiOrLicense: detectedBarcode.metadata.fssaiOrLicense,
            discountPercent: detectedBarcode.metadata.discountPercent,
            url: detectedBarcode.metadata.type === 'URL' ? detectedBarcode.rawValue : undefined,
            isRealDatabaseLookup: detectedBarcode.metadata.isRealDatabaseLookup,
          }
        : undefined,
    });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Hidden canvas for snapshot rasterization */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Header & Mode Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Real-Time Barcode &amp; Packaging Scanner
            </h1>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-mono bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>LIVE</span>
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Real-time optical barcode scanning for supermarket products &amp; mandatory Legal Metrology declarations.
          </p>
        </div>

        {/* Top Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold">
          <button
            type="button"
            id="tab-realtime-camera"
            onClick={() => setActiveTab('REALTIME_CAMERA')}
            className={`px-3.5 py-1.5 rounded-lg flex items-center gap-2 transition cursor-pointer ${
              activeTab === 'REALTIME_CAMERA'
                ? 'bg-slate-900 dark:bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Camera className="w-3.5 h-3.5 text-amber-400" />
            <span>Live Camera Scanner</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </button>

          <button
            type="button"
            id="tab-upload"
            onClick={() => setActiveTab('UPLOAD')}
            className={`px-3.5 py-1.5 rounded-lg flex items-center gap-2 transition cursor-pointer ${
              activeTab === 'UPLOAD'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload File</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Camera Viewport or Upload (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* TAB 1: LIVE REAL-TIME CAMERA SCANNER */}
          {activeTab === 'REALTIME_CAMERA' && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-4">
              {/* Quick Website Items Barcode Strip */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <ShoppingBag className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Real-Time Scan Items:</span>
                  </span>
                  <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                    Instant POS Decode
                  </span>
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-thin">
                  {[
                    { name: 'Maggi 2-Min', code: '8901058852393', mrp: '₹14' },
                    { name: 'Amul Butter', code: '8901262010017', mrp: '₹56' },
                    { name: 'Tata Salt', code: '8901491101830', mrp: '₹28' },
                    { name: 'Parle-G', code: '8901719101037', mrp: '₹10' },
                    { name: 'Dolo 650', code: '8901117001023', mrp: '₹31' },
                    { name: 'Surf Excel', code: '8901030383921', mrp: '₹140' },
                    { name: 'Kurkure', code: '8901499008827', mrp: '₹20' },
                    { name: 'Dairy Milk', code: '7622201736683', mrp: '₹45' },
                    { name: 'Colgate', code: '8901314010521', mrp: '₹60' },
                    { name: 'Dettol', code: '8901396112014', mrp: '₹85' },
                  ].map((chip) => (
                    <button
                      key={chip.code}
                      type="button"
                      onClick={() => {
                        const product = SUPERMARKET_CATALOG.find((p) => p.barcode === chip.code);
                        if (product) {
                          handleScanCatalogItem(product);
                        }
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-2xs hover:border-emerald-400 dark:hover:border-emerald-500"
                      title={`Click to scan ${chip.name} barcode in real time`}
                    >
                      <Barcode className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                      <span>{chip.name}</span>
                      <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold text-[10px]">
                        {chip.mrp}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Camera Header Status Bar */}
              <div className="flex items-center justify-between text-xs bg-slate-950 text-white px-3.5 py-2.5 rounded-xl font-mono border border-slate-800">
                <div className="flex items-center gap-2">
                  {isCameraActive ? (
                    <>
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="font-bold text-emerald-400">REAL-TIME CAMERA SCANNER</span>
                      <span className="text-slate-600 hidden sm:inline">|</span>
                      <span className="text-slate-300 text-[11px] hidden sm:inline">
                        {facingMode === 'environment' ? 'Rear / Main Camera' : 'Front / User Camera'}
                      </span>
                    </>
                  ) : isConnectingCamera ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                      <span className="font-bold text-amber-400">REQUESTING CAMERA PERMISSION...</span>
                    </>
                  ) : (
                    <>
                      <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                      <span className="font-bold text-cyan-300">REAL-TIME SCANNER STANDBY</span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-2 text-[11px] text-slate-400">
                  <span className="font-mono hidden sm:inline">{liveTimestamp}</span>
                  {isCameraActive && (
                    <button
                      type="button"
                      onClick={handleStopCamera}
                      className="px-2.5 py-0.5 rounded-md bg-rose-900/60 hover:bg-rose-800 text-rose-200 text-[10px] font-bold border border-rose-700 transition cursor-pointer"
                    >
                      Stop Camera
                    </button>
                  )}
                </div>
              </div>

              {/* Camera Viewport with Real-Time Reticle & Overlay */}
              <div
                className={`relative rounded-2xl overflow-hidden bg-slate-950 min-h-[380px] sm:min-h-[440px] lg:aspect-video flex items-center justify-center border-2 shadow-xl transition-all ${
                  scanSuccessGlow
                    ? 'border-emerald-400 ring-4 ring-emerald-500/30'
                    : 'border-slate-800'
                }`}
              >
                {/* Flash effect when capturing */}
                {flashEffect && (
                  <div className="absolute inset-0 bg-white opacity-90 z-40 pointer-events-none transition-opacity duration-150" />
                )}

                {/* Subdued HUD Grid Background */}
                <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px]" />

                {isCameraActive ? (
                  <>
                    {/* Live Video Element */}
                    <video
                      ref={setVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover sm:object-contain bg-black"
                    />

                    {/* HUD Watermark & Controls Bar */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-auto z-20">
                      <div className="bg-black/80 backdrop-blur-xs text-white text-[10px] px-2.5 py-1 rounded-md font-mono flex items-center gap-2 border border-white/15 shadow-md">
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                        <span className="font-bold tracking-wide">REC LIVE</span>
                        <span className="text-slate-400">•</span>
                        <span className="text-emerald-300 font-bold">FRAME #{frameCount}</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={handleFlipCamera}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-black/80 hover:bg-black text-amber-300 border border-amber-400/40 text-[10px] font-mono transition shadow-md cursor-pointer"
                          title="Flip camera between front and rear"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span className="hidden sm:inline">Flip Camera</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setIsBarcodeScannerActive((prev) => !prev)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-mono transition border cursor-pointer ${
                            isBarcodeScannerActive
                              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                              : 'bg-black/80 border-slate-700 text-slate-400'
                          }`}
                          title="Toggle continuous real-time barcode scanning"
                        >
                          <QrCode className={`w-3 h-3 ${isScanningFrame ? 'text-amber-400 animate-spin' : ''}`} />
                          <span>{isBarcodeScannerActive ? 'Scanning: ON' : 'Paused'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Detected Barcode Real-Time Banner (Pops up immediately on detection) */}
                    {detectedBarcode && (
                      <div className="absolute top-14 left-3 right-3 flex justify-center z-20 pointer-events-auto">
                        <div className="bg-slate-950/95 border-2 border-emerald-400 rounded-xl p-3 shadow-2xl text-white max-w-xl w-full flex flex-col sm:flex-row sm:items-center justify-between gap-3 backdrop-blur-md animate-in fade-in slide-in-from-top-2">
                          <div className="flex items-start gap-2.5 min-w-0">
                            <span className="flex h-2.5 w-2.5 relative shrink-0 mt-1">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
                            </span>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-black text-[10px] font-mono">
                                  {detectedBarcode.format}
                                </span>
                                {detectedBarcode.metadata.mrp && (
                                  <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-black text-[10px] font-mono">
                                    MRP: {detectedBarcode.metadata.mrp}
                                  </span>
                                )}
                                {detectedBarcode.metadata.expiryDate && (
                                  <span className="px-1.5 py-0.5 rounded bg-purple-900/80 text-purple-200 font-bold text-[10px] font-mono border border-purple-500/40">
                                    EXP: {detectedBarcode.metadata.expiryDate}
                                  </span>
                                )}
                                {detectedBarcode.metadata.lotNumber && (
                                  <span className="px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 text-[10px] font-mono border border-slate-700">
                                    Lot: {detectedBarcode.metadata.lotNumber}
                                  </span>
                                )}
                              </div>
                              <div className="text-xs font-bold text-white truncate mt-1">
                                {detectedBarcode.metadata.productName || detectedBarcode.rawValue}
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono flex items-center gap-2 flex-wrap">
                                <span>Code: {detectedBarcode.rawValue}</span>
                                {detectedBarcode.metadata.netQuantity && (
                                  <span>• Net Qty: {detectedBarcode.metadata.netQuantity}</span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                            <button
                              type="button"
                              onClick={() => handleInstantReport(detectedBarcode)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-md transition transform active:scale-95 cursor-pointer"
                              title="Instantly generate statutory inspection report"
                            >
                              <Zap className="w-3.5 h-3.5 fill-slate-950" />
                              <span>1s Report</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setIsBarcodeModalOpen(true)}
                              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition cursor-pointer"
                            >
                              Inspect
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Target Crosshairs & Real-Time Laser Scanline */}
                    <div
                      className={`absolute inset-0 pointer-events-none border-2 border-dashed m-6 rounded-xl flex items-center justify-center z-10 transition-colors ${
                        detectedBarcode ? 'border-emerald-400/80 bg-emerald-500/5' : 'border-amber-400/50'
                      }`}
                    >
                      {/* Laser Barcode Scanning Line Sweep */}
                      {isBarcodeScannerActive && (
                        <div className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_#34d399] animate-[bounce_2.5s_ease-in-out_infinite]" />
                      )}

                      <span className="text-[11px] font-mono text-amber-300/90 bg-black/80 px-3 py-1.5 rounded-md border border-amber-400/30 flex items-center gap-2 shadow-lg">
                        <Scan className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                        <span>
                          {detectedBarcode
                            ? `✓ ${detectedBarcode.format} Decoded (${detectedBarcode.rawValue})`
                            : 'Align package barcode inside this reticle'}
                        </span>
                      </span>
                    </div>

                    {/* Floating Capture Frame Button */}
                    <button
                      type="button"
                      id="capture-frame-btn"
                      onClick={handleCaptureCameraFrame}
                      className="absolute bottom-4 z-20 inline-flex items-center gap-2 px-6 py-3 rounded-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm shadow-2xl border-2 border-amber-300 transition transform active:scale-95 cursor-pointer"
                    >
                      <Camera className="w-4 h-4 sm:w-5 sm:h-5 fill-slate-950" />
                      <span>Capture Frame for Evidence</span>
                    </button>
                  </>
                ) : (
                  /* Standby Viewfinder Screen (Prompt to start camera) */
                  <div className="relative w-full h-full flex flex-col items-center justify-center p-6 sm:p-8 text-center z-10 space-y-5">
                    {/* Viewfinder Corner Framing Markers */}
                    <div className="absolute top-4 left-4 sm:top-6 sm:left-6 w-8 h-8 sm:w-10 sm:h-10 border-t-2 border-l-2 border-emerald-400" />
                    <div className="absolute top-4 right-4 sm:top-6 sm:right-6 w-8 h-8 sm:w-10 sm:h-10 border-t-2 border-r-2 border-emerald-400" />
                    <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 w-8 h-8 sm:w-10 sm:h-10 border-b-2 border-l-2 border-emerald-400" />
                    <div className="absolute bottom-4 right-4 sm:bottom-6 sm:right-6 w-8 h-8 sm:w-10 sm:h-10 border-b-2 border-r-2 border-emerald-400" />

                    {/* Central Target Crosshair Ring */}
                    <div className="relative">
                      <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full border-2 border-dashed border-emerald-500/50 flex items-center justify-center animate-[spin_12s_linear_infinite]" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Scan className="w-9 h-9 sm:w-10 sm:h-10 text-emerald-400" />
                      </div>
                    </div>

                    <div className="max-w-sm sm:max-w-md space-y-1.5">
                      <div className="flex items-center justify-center gap-2">
                        <span className="text-white text-sm sm:text-base font-bold tracking-wider uppercase font-mono">
                          Real-Time Camera Scanner
                        </span>
                        <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-emerald-900/70 text-emerald-300 border border-emerald-600 font-bold">
                          READY
                        </span>
                      </div>
                      <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                        Start your camera to scan barcodes and packaging declarations in real time.
                      </p>
                    </div>

                    {cameraError && (
                      <div className="p-3 rounded-lg bg-rose-950/80 border border-rose-800 text-rose-200 text-xs max-w-md text-left flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                        <span>{cameraError}</span>
                      </div>
                    )}

                    {/* Primary Action Button to Start Camera */}
                    <div className="flex flex-wrap items-center justify-center gap-3 pt-1 w-full sm:w-auto px-4 sm:px-0">
                      <button
                        type="button"
                        id="start-realtime-camera-btn"
                        onClick={() => handleStartCamera()}
                        disabled={isConnectingCamera}
                        className="inline-flex items-center justify-center gap-2.5 px-8 py-3.5 sm:py-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm sm:text-base shadow-xl transition transform active:scale-95 cursor-pointer w-full sm:w-auto"
                      >
                        {isConnectingCamera ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                            <span>Opening Camera...</span>
                          </>
                        ) : (
                          <>
                            <Camera className="w-5 h-5 fill-slate-950" />
                            <span>Start Real-Time Camera</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Barcode Search & Direct Input Bar */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/80 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Search className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Direct Barcode / GTIN Search:</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                    EAN-13 / UPC / Code-128
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={manualBarcodeInput}
                      onChange={(e) => setManualBarcodeInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleLookupBarcode();
                        }
                      }}
                      placeholder="Enter barcode (e.g. 8901058852393 for Maggi, 8901262010017 for Amul)..."
                      className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-8 pr-3 py-2 text-xs text-slate-900 dark:text-white font-mono outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => handleLookupBarcode()}
                    disabled={isSearchingBarcode || !manualBarcodeInput.trim()}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition cursor-pointer shrink-0 shadow-xs"
                  >
                    {isSearchingBarcode ? 'Searching...' : 'Scan / Lookup'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: FILE UPLOAD */}
          {activeTab === 'UPLOAD' && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-500 rounded-xl p-10 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-3"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 rounded-full text-emerald-600 dark:text-emerald-400">
                  <Upload className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white">
                    Click to upload or drag packaging photo with barcode
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Supports JPG, PNG, WEBP. Barcodes will be scanned automatically.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Captured / Selected Package Preview Display */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Inspection Evidence Surface</span>
              </span>
              {imagePreview && (
                <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  Ready for Evidence Extraction
                </span>
              )}
            </div>

            <div className="bg-slate-100 dark:bg-slate-950 rounded-xl p-3 flex items-center justify-center border border-slate-200 dark:border-slate-800 min-h-[220px]">
              {imagePreview ? (
                <div className="relative group max-w-full">
                  <img
                    src={imagePreview}
                    alt="Package evidence preview"
                    className="max-h-[260px] w-auto object-contain rounded-lg shadow-sm bg-white dark:bg-slate-900"
                  />
                  <div className="absolute bottom-2 right-2 bg-slate-900/85 text-white text-[10px] px-2 py-1 rounded-md font-mono flex items-center gap-1">
                    <span>Evidence Frame Captured</span>
                  </div>
                </div>
              ) : (
                <div className="text-center text-slate-400 text-xs py-8 space-y-1">
                  <ImageIcon className="w-8 h-8 mx-auto opacity-40 mb-1" />
                  <p className="font-semibold">No package frame captured yet.</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Start the Real-Time Camera, select an item from the catalog, or upload a packaging photo.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Statutory Declarations Form & Quality (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Real-Time Image Quality Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                  Readability &amp; Quality Metrics
                </h3>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                {qualityMetrics?.score || 95}% READABILITY
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 mt-3.5 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-500 dark:text-slate-400 text-[10px] uppercase font-bold block">
                  Frame Resolution
                </span>
                <span className="font-bold text-slate-900 dark:text-white font-mono">
                  {qualityMetrics?.width || 1280} × {qualityMetrics?.height || 720} px
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-500 dark:text-slate-400 text-[10px] uppercase font-bold block">
                  Sharpness Check
                </span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Sharp Focus
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-3 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
              {qualityMetrics?.guidance ||
                'Surface resolution complies with PCR 2011 minimum declaration height verification standards.'}
            </p>
          </div>

          {/* Commodity Details Form */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-emerald-500" />
                <span>Commodity Details (Auto-Filled by Barcode)</span>
              </h3>
              {detectedBarcode && (
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                  ✓ {detectedBarcode.format} LINKED
                </span>
              )}
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
                Commodity Title
              </label>
              <input
                type="text"
                value={commodityName}
                placeholder="e.g. Maggi 2-Minute Masala Instant Noodles"
                onChange={(e) => setCommodityName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
                  Packer / Brand
                </label>
                <input
                  type="text"
                  value={brandName}
                  placeholder="e.g. Nestle India"
                  onChange={(e) => setBrandName(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
                  Batch / Lot #
                </label>
                <input
                  type="text"
                  value={batchNumber}
                  placeholder="e.g. LOT-MG2492-B8"
                  onChange={(e) => setBatchNumber(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>
            </div>

            {/* Batch Status Selector */}
            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
                Inspection Batch Status
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {(['RELEASED', 'HOLD', 'INSPECTION', 'RECALLED'] as BatchStatus[]).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setBatchStatus(st)}
                    className={`px-2 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center border cursor-pointer ${
                      batchStatus === st
                        ? st === 'RELEASED'
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : st === 'HOLD'
                          ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                          : st === 'INSPECTION'
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-rose-600 text-white border-rose-600 shadow-xs'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span className="text-[10px]">
                      {st === 'RELEASED' && '✓ Released'}
                      {st === 'HOLD' && '⚠ Quality Hold'}
                      {st === 'INSPECTION' && '🔍 Inspecting'}
                      {st === 'RECALLED' && '✕ Recalled'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase block mb-1">
                Product Category
              </label>
              <input
                type="text"
                value={category}
                placeholder="e.g. Packaged Food & Snacks"
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
              />
            </div>
          </div>

          {/* Primary Action Button */}
          <button
            type="button"
            id="start-analysis-submit-btn"
            onClick={handleSubmit}
            className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition transform active:scale-98 cursor-pointer"
          >
            <span>Verify Compliance &amp; Extract Statutory Evidence</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Decoded Barcode & Statutory Details Modal */}
      {isBarcodeModalOpen && detectedBarcode && (
        <BarcodeModal
          barcode={detectedBarcode}
          onClose={() => setIsBarcodeModalOpen(false)}
          onApplyToInspection={(code) => {
            if (code.metadata.productName) setCommodityName(code.metadata.productName);
            if (code.metadata.brandName) setBrandName(code.metadata.brandName);
            if (code.metadata.lotNumber || code.metadata.batchNumber) {
              setBatchNumber(code.metadata.lotNumber || code.metadata.batchNumber || '');
            }
            if (code.metadata.category) setCategory(code.metadata.category);
            setIsBarcodeModalOpen(false);
          }}
          onInstantGenerateReport={(code) => {
            handleInstantReport(code);
            setIsBarcodeModalOpen(false);
          }}
        />
      )}
    </div>
  );
};
